const LANG_DICT = {
    "id": {
        // SIDEBAR
        "sb_brand": "MAPS MONITORING WIFI",
        "sb_unlicensed": "UNLICENSED (DEMO)",
        "sb_h_main": "UTAMA",
        "sb_dash": "DASHBOARD",
        "sb_map": "LIVE MAPS",
        "sb_client": "CLIENT",
        "sb_hotspot": "HOTSPOT",
        "sb_broadcast": "WA BROADCAST",
        "sb_pppoe": "PPPoE",
        "sb_infra": "INFRASTRUKTUR",
        "sb_inv": "INVENTARIS",
        "sb_bill": "BILLING & TAGIHAN",
        "sb_fin": "LAPORAN KEUANGAN",
        "sb_h_mon": "MONITORING",
        "sb_traffic": "TRAFFIC MONITOR",
        "sb_logs": "LOG GANGGUAN",
        "sb_about": "TENTANG",
        "lbl_donate_lynk": "DONASI VIA LYNK.ID",
        "sb_set": "PENGATURAN",
        "sb_logout": "KELUAR",
        "sb_h_admin": "ADMINISTRASI",
        "lbl_lang_prefix": "LANG: ",
        "lbl_traffic_mon": "Traffic Monitor",
        "lbl_mon_logs": "MONITORING & LOGS",


        // DASHBOARD HEADER & CARDS
        "dash_title": "DASHBOARD",
        "card_stat_client": "STATISTIK CLIENT",
        "lbl_total": "TOTAL",
        "lbl_total_port": "TOTAL PORT",
        "lbl_online": "ONLINE",
        "lbl_offline": "OFFLINE",
        "lbl_offline_since": "Offline Sejak",
        "lbl_mikrotik": "MIKROTIK",
        "lbl_olt": "OLT (PON)",
        "lbl_odp": "ODP",
        "lbl_tiang": "TIANG",
        "lbl_client_htb": "CLIENT HTB/SWITCH",
        "lbl_client_olt": "CLIENT OLT",
        "lbl_htb": "HTB",
        "lbl_ont": "ROUTER/ONT",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "lbl_isolir_pill": "ISOLIR",
        "lbl_km": "KM",
        "lbl_temp_unit": "°C",
        "lbl_days_short": "h",
        "lbl_hours_short": "j",
        "lbl_minutes_short": "m",
        "msg_checking_ver": "Mengecek Versi...",
        "msg_ver_offline": "Offline",
        "msg_ver_unknown": "Tidak Diketahui",
        "lbl_main_server": "Server Utama",
        "lbl_choose_server": "-- Pilih Server --",
        "lbl_choose_server_first": "-- Pilih Server Dulu --",
        "alert_pro_locked": "Fitur ini hanya tersedia di versi PRO (Lunas). Silakan lakukan aktivasi lisensi.",

        // CUSTOM CARDS
        "card_inv": "INVENTARIS",
        "lbl_total_kabel": "TOTAL KABEL",
        "lbl_client_count_donut": "CLIENT",
        "lbl_kabel": "KABEL",
        "card_port": "STATISTIK PORT",
        "lbl_used": "TERPAKAI",
        "lbl_rem": "SISA",
        "lbl_odp_critical": "ODP KRITIS (SISA 0-1)",
        "lbl_no_critical_odp": "Tidak ada ODP kritis",
        "lbl_port_unit": "Port",
        "card_server": "STATUS SERVER",
        "lbl_cpu": "BEBAN CPU",
        "lbl_ram": "PENGGUNAAN RAM",
        "lbl_disk": "PENYIMPANAN",
        "lbl_temp": "SUHU",
        "lbl_uptime_server": "UPTIME SERVER",
        "card_fin": "KEUANGAN",
        "bdg_month": "BULAN INI",
        "lbl_month": "BULAN",
        "lbl_profit": "PROFIT",
        "lbl_in": "MASUK",
        "lbl_out": "KELUAR",
        "lbl_ratio": "RASIO PROFIT",
        "card_act": "LOG GANGGUAN",
        "card_mikrotik": "STATUS MIKROTIK",
        "card_traffic_history": "GRAFIK TRAFFIC MIKROTIK",
        "lbl_chart_update_interval": "* data di update 5 menit sekali",
        "th_identity": "IDENTITY",
        "th_status": "STATUS",
        "th_traffic": "TRAFFIC (IN/OUT)",
        "th_ping": "PING",
        "th_host": "HOST",
        "th_uptime": "UPTIME",

        // CLIENT PAGE
        "pg_client_search": "Cari Nama / IP / Koordinat...",
        "btn_dl_excel": "DOWNLOAD EXCEL",
        "btn_import_bulk": "IMPORT BULK",
        "th_name": "Nama Client",
        "th_paket": "Paket",
        "th_ip": "IP Address",
        "th_parent": "Induk",
        "th_wa": "No. WA",
        "th_paid_until": "Masa Aktif",
        "th_action": "Aksi",
        "th_join_date": "Tgl Join",
        "lbl_join_date": "Tanggal Bergabung",
        "pg_client_title": "MANAJEMEN KLIEN",
        "lbl_total_clients": "Total Pelanggan",
        "lbl_active_clients": "Online / Aktif",
        "lbl_offline_clients": "Offline / Terputus",
        "lbl_isolir_clients": "Isolir / Suspend",
        "lbl_total_clients_desc": "Terdaftar di database",
        "lbl_active_clients_desc": "Koneksi aktif saat ini",
        "lbl_offline_clients_desc": "Tidak terkoneksi",
        "lbl_isolir_clients_desc": "Klien isolir billing",
        "lbl_quota_today": "Hari Ini",
        "lbl_quota_week": "Minggu Ini",
        "lbl_quota_month": "Bulan Ini",
        "lbl_saving": "MENYIMPAN...",
        "lbl_loading": "MEMUAT...",
        "lbl_no_users": "Belum ada yang pakai",
        "lbl_no_photo": "Tidak Ada Foto",
        "lbl_home_photo": "FOTO RUMAH",
        "lbl_photo_loc": "FOTO LOKASI / TIANG ODP",
        "lbl_compressing": "Mengompres...",
        "lbl_uploading": "Mengunggah...",
        "lbl_upload_fail": "Unggah Gagal",
        "lbl_center": "(PUSAT)",
        "lbl_branch": "(CABANG)",
        "msg_no_logs": "Belum ada data log.",
        "msg_load_log_fail": "Gagal memuat log.",
        "msg_save_error": "Gagal menyimpan: ",
        "msg_save_fail": "Tanggapan server gagal.",
        "msg_conn_err": "Gagal Koneksi",
        "msg_tele_success": "Backup berhasil dikirim ke Telegram!",
        "msg_tele_skipped": "Backup dilewati (tidak ada perubahan atau fitur dimatikan).",
        "msg_tele_fail": "Gagal mengirim backup: ",
        "hint_ctrl_multi": "Tahan CTRL untuk memilih banyak port.",
        "alert_guest_dash": "Anda masuk sebagai Tamu/Viewer. Anda tidak dapat mengakses Dashboard Utama.",
        "alert_save_first": "Silakan simpan data dulu sebelum mengedit jalur.",
        "conf_send_telegram": "Apakah Anda yakin ingin mengirim backup ke Telegram sekarang?",
        "conf_del_photo": "Hapus foto ini?",
        "msg_del_fail": "Gagal menghapus: ",
        "msg_del_err": "Gagal koneksi saat menghapus.",
        "msg_upload_err": "Gagal koneksi saat mengunggah.",
        "lbl_mode_static": "IP STATIK (MANUAL)",
        "lbl_mode_pppoe": "PPPoE (MIKROTIK)",
        "lbl_mode_radius": "PPPoE (RADIUS)",
        "lbl_locked": "Locked (Terkunci)",
        "lbl_unlocked": "Unlocked (Bisa Geser)",
        "lbl_type_htb": "HTB / Switch (Estafet/Converter)",
        "lbl_type_olt": "Passive Splitter (ODP Tiang)",
        "lbl_type_jb": "Joint Box / Distribusi (Multi-Core)",
        "ph_parent_manual": "Ketik sumber manual...",
        "lbl_multi_uplink_conf": "Konfigurasi Multi-Uplink:",
        "lbl_manual_packet": "Nama Paket (Manual / Radius Override)",
        "ph_manual_packet": "Isi nama paket jika tidak terdeteksi...",
        "lbl_wa_format": "No. WhatsApp (Format: 628xxx)",
        "lbl_router_user": "ROUTER USER",
        "lbl_import_dependency": "⚠️ Untuk bulk upload pastikan sudah install openpyxl. Caranya buka terminal Putty perintahkan:",
        "lbl_import_folder_hint": "cd /root/monitoring-wifi (atau sesuaikan folder install)",
        "lbl_import_venv": "source venv/bin/activate",
        "lbl_import_pip": "pip install openpyxl",
        "lbl_import_deactivate": "deactivate",
        "lbl_pay_history_last3": "3 Riwayat Pembayaran Terakhir",
        "lbl_tanggal": "tanggal",
        "lbl_sebesar": "sebesar",
        "lbl_isolir": "ISOLIR",
        "lbl_isolir_status": "(ISOLIR)",
        "prompt_edit_expiry": "Masukkan Tanggal Masa Aktif Baru (Format: DD-MM-YYYY):",
        "prompt_edit_expiry_fixed_full": "Ganti Masa Aktif (Mode Fixed).\nMasukkan Tanggal Lengkap (Format: DD-MM-YYYY).\n\nNOTE: Tanggal (DD) yang Anda masukkan akan menjadi 'Jatuh Tempo' bulanan klien ini.",
        "err_date_format": "Format tanggal salah! Gunakan DD-MM-YYYY (Contoh: 28-04-2026)",
        "conf_edit_expiry": "Ubah masa aktif {name} menjadi {date}?",
        "msg_expiry_updated": "Masa aktif diperbarui!",
        "conf_del_tx": "Batalkan/hapus transaksi ini?",
        "msg_tx_deleted": "Transaksi dihapus!",
        "lbl_month_list": ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
        "lbl_router_pass": "ROUTER PASS",
        "msg_no_data": "Tidak ada data.",
        "lbl_none_direct": "Kosong / Langsung",
        "lbl_none": "Tidak ada",
        "lbl_no_data": "Tidak Ada Data",
        "msg_no_mk_connected": "Tidak ada router mikrotik yang terhubung.",
        "msg_invalid_choice": "Pilihan tidak valid.",
        "msg_import_failed": "Gagal import",
        "msg_failed_fetch_payment": "Gagal mengambil data riwayat pembayaran.",
        "msg_coord_format_err": "Format koordinat salah! Harus berupa 'latitude, longitude' (Contoh: -7.68, 110.50)",
        "msg_coord_nan_err": "Nilai koordinat harus berupa angka! (Contoh: -7.68, 110.50)",
        "msg_bank_added": "Rekening berhasil ditambahkan ke daftar!",
        "conf_delete_bank": "Apakah Anda yakin ingin menghapus rekening ini dari daftar?",
        "msg_bank_deleted": "Rekening berhasil dihapus!",
        "msg_user_deleted": "User berhasil dihapus!",
        "msg_user_added": "User berhasil ditambahkan!",
        "msg_user_updated": "User berhasil diperbarui!",
        "lbl_pass_through": "Pass Through",
        "tt_note": "Catatan",
        "tt_model": "Model",
        "tt_cpu": "CPU",
        "tt_uptime": "Uptime",
        "tt_internet": "Internet",
        "tt_traffic_wan": "Traffic WAN",
        "tt_type": "Tipe",
        "tt_cable": "Kabel",
        "tt_cap": "Kapasitas",
        "tt_no_packet": "Tanpa Paket",
        "tt_waiting": "Menunggu...",
        "tt_loading_traffic": "Memuat Traffic...",
        "tt_online_olt": "OLT ACTIVE",
        "tt_connected": "Connected",
        "tt_conn_arp": "Connected (ARP)",
        "tt_conn_netwatch": "Connected (Netwatch)",
        "msg_wait": "Tunggu...",
        "msg_confirm_kick": "Keluarkan user ini? (Bisa masuk lagi otomatis)",
        "msg_success": "Berhasil",
        "msg_error": "Kesalahan",
        "msg_sel_prof": "Pilih profil dulu!",
        "msg_confirm_prof": "Ganti profil user {user} ke {prof}?",
        "msg_prof_changed": "Profil berhasil diubah & user di-disconnect agar re-login.",
        "msg_failed": "Gagal",
        "opt_select_prof": "-- Pilih Profil --",
        "prof_current": "(Profil Saat Ini)",
        "opt_change_prof": "-- Ganti ke Profil --",
        "lbl_id_pelanggan": "ID PELANGGAN",
        "lbl_billing_active": "Billing Aktif (Auto Isolir)",
        "lbl_billing_hint": "*PENTING: Jika fitur Auto-Isolir diaktifkan di menu Billing & Tagihan, klien baru tanpa riwayat bayar akan langsung terisolir jika ini aktif. Matikan dulu, klik 'Bayar' di menu Billing/Client, lalu aktifkan kembali.",
        "lbl_srv_loc": "LOKASI SERVER",
        "pg_client_subtitle": "Kelola data pelanggan, isolir, dan pembayaran.",
        "info_isolate_title": "INFO ISOLIR (PPPoE & Statik IP):",
        "info_isolate_desc": "Status ISOLIR memutus internet sementara. PPPoE akan berganti profil, sedangkan Statik IP / Radius masuk ke Address List 'ISOLIR'. Profil asli tetap aman tersimpan.",
        "info_isolate_req": "Syarat: Nama profil & Address List MikroTik harus bernama ISOLIR.",
        "info_isolate_cmd": "KHUSUS IP STATIK & RADIUS: Wajib pasang perintah ini di Terminal MikroTik agar isolir berfungsi:\n/ip firewall filter add chain=forward action=drop src-address-list=ISOLIR comment=\"ISOLIR IP STATIK atau PPPOE RADIUS by nms peycell\" place-before=0",
        "btn_sync": "SINKRON DATA",
        "btn_dl_template": "UNDUH TEMPLATE EXCEL",
        "modal_import_title": "Import Client dari Excel (.xlsx)",
        "lbl_select_xlsx": "Pilih File Excel",
        "btn_start_import": "PROSES IMPORT",
        "modal_pay_title": "Bayar Tagihan Client",
        "lbl_client_name": "Nama Client",
        "lbl_router_src": "Sumber MikroTik",
        "lbl_prof_packet": "Profil Paket",
        "lbl_pay_amount": "Nominal Pembayaran (Rp)",
        "lbl_duration": "Durasi (Bulan)",
        "lbl_pay_total": "Total",
        "lbl_pay_note": "Catatan (Opsional)",
        "hint_prof_suggest": "(Ketik atau pilih dari suggestions)",
        "hint_pay_duration": "Bayar berapa bulan sekaligus?",
        "hint_pay_no_change_month": "Tidak perlu ubah bulan dan nunggak, cukup isi jumlah nominal pembayaran agar tidak terjadi kesalahpahaman saat bayar.",
        "msg_wa_greeting": "Halo Kak",
        "hint_edit_expiry_no_pay": "Mau perbarui Masa Aktif tanpa bayar? Klik ikon pensil di atas, tekan OK saat konfirmasi, lalu klik X jika sudah selesai.",
        "msg_pay_wifi_suffix": "Pembayaran Wifi",
        "btn_save_pay": "SIMPAN PEMBAYARAN",
        "btn_billing_enable_all": "AKTIFKAN SEMUA BILLING",
        "btn_billing_disable_all": "NONAKTIFKAN SEMUA BILLING",
        "conf_bulk_billing": "Kirim perubahan status billing ke SEMUA CLIENT?",
        "msg_selesai": "Selesai",
        "err_wa_not_found": "Nomor HP/WA tidak ditemukan untuk client: {name}",
        "conf_wa_reminder": "Kirim pengingat tagihan {bill} ke {name} ({phone})?",
        "msg_processing": "Pesan diproses.",
        "msg_pay_success": "Pembayaran berhasil disimpan.",
        "msg_pay_fail": "Gagal menyimpan pembayaran",
        "err_wa_empty": "Nomor WA tidak valid atau kosong!",
        "tt_bypass_on": "Matikan Bypass Billing",
        "tt_bypass_off": "Aktifkan Bypass Billing",
        "btn_free": "FREE",
        "btn_billing_disable": "Nonaktifkan Billing",
        "btn_billing_enable": "Aktifkan Billing",
        "lbl_page": "Halaman",
        "ph_pay_note_default": "Pembayaran masa aktif wifi {name}",
        "ph_wa_bill_tpl_default": "Halo Kak {name}, tagihan internet bulan ini sudah terbit.",
        "lbl_month_list": ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],

        // INFRA PAGE
        "pg_infra_routers": "ROUTERS",
        "lbl_tele_tpl_isolir": "Template Pesan Client Isolir",
        "lbl_tele_tpl_reactivate": "Template Pesan Client Reaktivasi",
        "lbl_cl_isolir": "Client Isolir",
        "lbl_cl_reactivate": "Client Reaktivasi",
        "hint_tele_tpl": "<b>Format Variabel Dinamis Telegram:</b><br>🔹 <b>PPPoE Client:</b> <code>{name}</code>, <code>{ip}</code>, <code>{status}</code>, <code>{mode}</code>, <code>{date}</code>, <code>{time}</code>, <code>{total_online}</code>, <code>{total_offline}</code>, <code>{total_isolir}</code>, <code>{packet}</code><br>🔸 <b>Hotspot Voucher:</b> <code>{name}</code>, <code>{ip}</code>, <code>{mac}</code>, <code>{host_name}</code>, <code>{server}</code>, <code>{profile}</code>, <code>{uptime}</code>, <code>{bytes_out}</code>, <code>{router_name}</code>, <code>{date}</code>, <code>{time}</code><br>🔺 <b>Distribusi ODP:</b> <code>{name}</code>, <code>{parent_name}</code>, <code>{offline_count}</code>, <code>{online_count}</code>, <code>{total_count}</code>, <code>{dependent_desc}</code>, <code>{duration_desc}</code>, <code>{rca_info}</code>, <code>{date}</code>, <code>{time}</code>",
        "pg_infra_odp": "ODP & JALUR",
        "pg_infra_search": "Ketik Nama ODP / Router...",
        "ph_infra_search": "Ketik Nama ODP / Router...",
        "pg_infra_title": "INFRASTRUKTUR",
        "pg_infra_subtitle": "Monitor status Router, ODP, dan perangkat jaringan aktif secara real-time.",

        // INVENTORY PAGE
        "pg_inv_title": "MANAJEMEN INVENTARIS",
        "pg_inv_subtitle": "Kelola stok barang gudang, perangkat terpasang, dan aset jaringan.",
        "tab_installed": "TERPASANG",
        "tab_stock": "BELUM TERPASANG (GUDANG)",
        "lbl_item_name_manual": "Nama Barang (Manual)",
        "ph_item_manual": "Contoh: Switch Hub 8 Port",
        "lbl_qty": "Jumlah",
        "btn_add": "TAMBAH",
        "th_item": "Nama Barang",
        "hint_inv_save": "Data otomatis disimpan saat tombol simpan ditekan.",
        "btn_save_change": "SIMPAN PERUBAHAN",
        "lbl_item_stock": "Nama Barang (Stok)",
        "ph_item_stock": "Contoh: Kabel Dropcore 1 Roll",
        "btn_add_stock": "TAMBAH KE GUDANG",
        "th_item_warehouse": "Nama Barang (Gudang)",
        "hint_stock_save": "Data Gudang otomatis tersimpan.",
        "desc_inv_installed": "Daftar perangkat yang saat ini aktif digunakan di lapangan (ODP, Router, Kabel, dll). Jumlah ini dihitung otomatis dari Topologi Jaringan.",
        "desc_inv_stock": "Daftar stok barang cadangan di gudang (Sparepart) yang belum terpasang. Perbarui jumlah secara manual saat ada penambahan atau pengurangan stok.",

        // SETTINGS PAGE
        "tab_disp": "TAMPILAN",
        "tab_payment": "REKENING & QRIS",
        "tab_wa": "WHATSAPP",
        "tab_auto": "AUTOMASI",

        "tab_sec": "SECURITY",
        "tab_upd": "UPDATE & RESTORE",
        "set_page_title": "PENGATURAN SISTEM",

        // SETTINGS - DISPLAY
        "lbl_lang": "Bahasa / Language",
        "hint_lang": "Pilih bahasa antarmuka.",
        "lbl_web_title": "Nama Aplikasi / Web Title",
        "hint_web_title": "Muncul di Sidebar kiri dan Tab Browser.",
        "lbl_show_clock": "Tampilkan Jam di Dashboard",
        "hint_show_clock": "Aktifkan untuk memunculkan jam live di header dashboard.",
        "lbl_show_news": "Tampilkan Running Text INFO",
        "hint_show_news": "Aktifkan untuk menampilkan teks berjalan (INFO) di header dashboard.",
        "lbl_timezone": "Zona Waktu Dashboard",
        "opt_wib": "WIB (UTC+7)",
        "opt_wita": "WITA (UTC+8)",
        "opt_wit": "WIT (UTC+9)",
        "lbl_zone_wib": "WIB",
        "lbl_zone_wita": "Wita",
        "lbl_zone_wit": "Wit",
        "lbl_refresh": "Kecepatan Auto-Refresh",
        "hint_refresh": "Interval refresh halaman. Peringatan: Disarankan minimal 10-15 detik. Semakin kecil nilainya akan semakin realtime, namun akan membebani CPU Server dan MikroTik secara drastis.",
        "opt_sec": "Detik",
        "lbl_anim": "Animasi Kabel Default",
        "hint_anim": "Dipakai oleh halaman maps.",
        "lbl_favicon": "Favicon",
        "hint_favicon": "Perubahan terlihat setelah simpan lalu tekan CTRL + F5.",
        "lbl_changelog": "Riwayat Perubahan (Changelog)",
        "lbl_current_version": "Versi Saat Ini",
        "btn_upload": "UPLOAD",

        // SETTINGS - WA
        "lbl_tpl_bill": "Template Pesan Tagihan (Manual)",
        "lbl_tpl_bill_auto": "Template Pesan Otomatis (Sistem)",
        "lbl_tpl_pay": "Template Pesan Pembayaran (Sukses)",
        "lbl_enable_pay_wa": "Aktifkan Notifikasi Pembayaran WA",
        "lbl_enable_auto_wa": "Aktifkan Notifikasi Otomatis (H-3/EOM)",
        "lbl_enable_isolir_wa": "Aktifkan Notifikasi Isolir WA",
        "lbl_enable_reactivate_wa": "Aktifkan Notifikasi Reaktivasi WA",
        "lbl_print_info_title": "PANDUAN METODE CETAK",
        "lbl_print_method_browser_desc": "Gunakan mode ini jika Anda mencetak dari Browser PC (Laptop/Komputer) menggunakan printer standar (Epson, Canon, dll).",
        "lbl_print_method_rawbt_desc": "Gunakan mode ini jika Anda mencetak dari HP Android menggunakan printer Bluetooth Thermal.",
        "lbl_print_method_share_desc": "Di smartphone harus terinstall aplikasi service printer thermal seperti RawBT, Bluetooth Thermal Printer, atau aplikasi pencetak lainnya.",
        "lbl_enable_manual_wa": "Aktifkan Fitur Kirim WA Manual",
        "lbl_include_qris": "Sertakan Gambar QRIS Pembayaran",
        "hint_tpl_pay": "Keterangan Variabel:",
        "hint_tpl_bill": "Gunakan {id}, {name}, {month}, {price}, {amount}, {expired}, {profile}, {time}, {status}, {x}, {rekening} untuk variabel dinamis.",
        "hint_tpl_bill_auto": "Gunakan {id}, {name}, {month}, {price}, {amount}, {expired}, {profile}, {time}, {status}, {x}, {rekening} untuk variabel dinamis.",
        "btn_save_tpl": "SIMPAN PERUBAHAN",
        "lbl_wa_vars_title": "PANDUAN VARIABEL PESAN",
        "lbl_var_id_desc": "ID Pelanggan (Angka)",
        "lbl_var_name_desc": "Nama Lengkap Pelanggan",
        "lbl_var_month_desc": "Bulan Tagihan saat ini",
        "lbl_var_price_desc": "Harga Paket (Master)",
        "lbl_var_amount_desc": "Total yang dibayar",
        "lbl_var_bill_desc": "Total Tagihan (Paket + Tunggakan)",
        "lbl_var_expired_desc": "Tanggal Jatuh Tempo",
        "lbl_var_profile_desc": "Nama Paket Layanan",
        "lbl_var_time_desc": "Jam Pengiriman Pesan",
        "lbl_var_status_desc": "Status Pembayaran (Lunas/Kurang/Lebih)",
        "lbl_var_x_desc": "Jumlah hari pengingat (H-x)",
        "lbl_var_rekening_desc": "Daftar Rekening Bank (Multi-rekening)",
        "lbl_active_tele": "Aktifkan Bot Telegram",
        "lbl_bot_token": "Bot Token",
        "lbl_chat_id": "Chat ID",
        "lbl_tele_trigger": "Pemicu Notifikasi (Triggers)",
        "lbl_cl_offline": "Client Offline",
        "lbl_cl_online": "Client Online",
        "lbl_bk_report": "Laporan Backup",
        "lbl_sys_startup": "Sistem Mulai (Startup)",
        "lbl_odp_down": "ODP Mati Massal (Outage)",
        "lbl_tele_tpl_up": "Template Pesan Client Online",
        "lbl_tele_tpl_down": "Template Pesan Client Offline",
        "lbl_tele_tpl_odp_down": "Template Pesan ODP Down",
        "lbl_tele_tpl_odp_up": "Template Pesan ODP Up",
        "hint_tele_tpl": "<b>Format Variabel Dinamis Telegram:</b><br>🔹 <b>PPPoE Client:</b> <code>{name}</code>, <code>{ip}</code>, <code>{status}</code>, <code>{mode}</code>, <code>{date}</code>, <code>{time}</code>, <code>{total_online}</code>, <code>{total_offline}</code>, <code>{total_isolir}</code>, <code>{packet}</code><br>🔸 <b>Hotspot Voucher:</b> <code>{name}</code>, <code>{ip}</code>, <code>{mac}</code>, <code>{host_name}</code>, <code>{server}</code>, <code>{profile}</code>, <code>{uptime}</code>, <code>{bytes_out}</code>, <code>{router_name}</code>, <code>{date}</code>, <code>{time}</code><br>🔺 <b>Distribusi ODP:</b> <code>{name}</code>, <code>{parent_name}</code>, <code>{offline_count}</code>, <code>{online_count}</code>, <code>{total_count}</code>, <code>{dependent_desc}</code>, <code>{duration_desc}</code>, <code>{rca_info}</code>, <code>{date}</code>, <code>{time}</code>",
        "lbl_tele_alert": "Notifikasi Telegram memerlukan Bot Token dan Chat ID yang valid.",
        "hint_tele_chat": "Dapatkan Chat ID dari @userinfobot atau bot serupa di Telegram.",
        "wa_inst_title": "PANDUAN AKTIVASI WHATSAPP (LINUX)",
        "wa_inst_ssh": "Pastikan Anda sudah login ke SSH Server (Putty/Termius). Jalankan perintah berikut satu per satu:",
        "wa_inst_1": "1. <b>Update Package:</b> <code>sudo apt update</code>",
        "wa_inst_2": "2. <b>Install Node.js & NPM:</b> <code>sudo apt install nodejs npm -y</code>",
        "wa_inst_3": "3. <b>Install Dependencies:</b> <code>cd /root/monitoring-wifi && npm install</code>",
        "wa_inst_4": "4. <b>Install PDF Engine (Opsional):</b><br>Jalankan perintah ini jika ingin mengaktifkan notifikasi pembayaran atau tagihan via PDF:<br><div style=\"background: rgba(0,0,0,0.35); padding: 8px 12px; border-radius: 6px; font-family: monospace; font-size: 10px; color: #34d399; margin-top: 4px; display: flex; align-items: flex-start; justify-content: space-between; border: 1px solid rgba(255,255,255,0.03); line-height: 1.4;\"><span style=\"white-space: pre-line; user-select: all; text-align: left; display: block;\">cd /root/monitoring-wifi\npython3 -m venv venv\nsource venv/bin/activate\npip install reportlab\ndeactivate</span><button onclick=\"navigator.clipboard.writeText('cd /root/monitoring-wifi\\npython3 -m venv venv\\nsource venv/bin/activate\\npip install reportlab\\ndeactivate'); showToast('Perintah disalin!', 'success');\" style=\"background: rgba(255,255,255,0.08); border: none; color: #9ca3af; padding: 2px 6px; border-radius: 4px; font-size: 9px; cursor: pointer; display: flex; align-items: center; gap: 4px; margin-left: 8px; margin-top: 2px;\"><i class=\"fas fa-copy\"></i></button></div>",
        "wa_inst_4_note": "*Catatan: Sesuaikan nama folder jika folder project Anda berada di lokasi selain /root/monitoring-wifi",
        "wa_warn_title": "PERINGATAN",
        "wa_warn_server": "Fitur ini menambah beban CPU/RAM server.",
        "wa_warn_banned": "Rawan BANNED. Gunakan nomor cadangan atau WA Business.",
        "wa_usage_title": "KEAMANAN",
        "wa_usage_delay": "Delay 30 detik/pesan (Anti-Spam).",
        "wa_usage_mass": "Menghubungkan banyak klien secara serentak beresiko pada keamanan nomor Anda.",
        "wa_think_twice": "Mohon dipikirkan ulang sebelum mengaktifkan fitur ini.",
        "wa_safe_tips": "TIPS AGAR LEBIH AMAN:",
        "wa_tip_business": "Gunakan nomor WhatsApp Business (lebih tangguh).",
        "wa_tip_save": "Pastikan nomormu di-save oleh klien agar tidak dianggap asisten robot/spam.",
        "wa_header": "WhatsApp Gateway",
        "wa_sub_header": "Hubungkan nomor Anda untuk mengirim notifikasi otomatis.",
        "btn_wa_connect": "HUBUNGKAN / WAKE UP",
        "btn_wa_reset": "RESET SESI",
        "wa_reset_sub": "Anda perlu melakukan scan QR Code ulang nanti.",
        "conf_wa_reset": "Apakah Anda yakin ingin mereset sesi WhatsApp? Ini akan menghapus sesi yang tersimpan.",
        "conf_wa_clear_log": "Apakah Anda yakin ingin menghapus semua log aktivitas WhatsApp?",
        "lbl_wa_test": "Tes Kirim WhatsApp",
        "ph_wa_test": "Contoh: 08123456789",
        "btn_wa_test_manual": "TES TAGIHAN MANUAL",
        "btn_wa_test_auto": "TES TAGIHAN AUTO",
        "lbl_wa_log": "WHATSAPP ACTIVITY LOG",
        "btn_wa_clear_log": "CLEAR LOG",
        "msg_wa_log_waiting": "Menunggu aktivitas...",
        "hint_tpl_pay_desc": "Gunakan <b>{id}</b>, <b>{name}</b>, <b>{amount}</b>, <b>{date}</b>, <b>{expired}</b>, <b>{profile}</b>, <b>{time}</b>, <b>{status}</b>",
        "hint_tpl_pay_fmt": "Format: <b>*Tebal*</b>, <i>_Miring_</i>, <span style='text-decoration:line-through'>~Coret~</span>, <code>```Monospace```</code>",
        "wa_tip_test": "Anda bisa tes template manual atau otomatis.",
        "lbl_tpl_isolir": "Template Pesan Isolir (Otomatis)",
        "hint_tpl_isolir": "Terkirim saat klien diisolir. Gunakan {id}, {name}, {price}, {amount}, {expired}, {profile}, {time}, {status}.",
        "lbl_tpl_reactivate": "Template Pesan Reaktivasi (Lunas)",
        "lbl_print_method": "Metode Cetak (Printer)",
        "lbl_method_browser": "Browser Print (PC/Laptop)",
        "lbl_method_rawbt": "RawBT Thermal Print (Android - HTML)",
        "lbl_method_rawbt_text": "RawBT Text Only (Android - Ringan)",
        "hint_rawbt_html": "<b>Mode RawBT Text:</b> Lebih ringan, hemat kertas, format sederhana (Text-Only). Pastikan aplikasi RawBT terinstall.",
        "hint_tpl_reactivate": "Terkirim saat layanan aktif kembali setelah bayar. Gunakan {id}, {name}, {amount}, {price}, {date}, {expired}, {profile}, {time}, {status}.",

        // PRINT LABELS
        "tab_print": "CETAK",
        "lbl_print_header": "Header Struk (Atas)",
        "lbl_print_footer": "Footer Struk (Bawah)",
        "lbl_print_paper": "Ukuran Kertas",
        "lbl_print_auto": "Otomatis Cetak setelah Bayar",
        "lbl_print_show_logo": "Tampilkan Logo di Struk",
        "lbl_print_store_name": "Nama Toko (Header Struk)",
        "lbl_print_template": "Template Isi Struk",
        "lbl_print_format": "Format Template Struk",
        "hint_print_format": "Pilih 'Teks Biasa' agar pembeli mudah mengedit teks struk tanpa menulis kode HTML.",
        "lbl_format_text": "Teks Biasa / Plain Text (Monospace - Mudah)",
        "lbl_format_html": "Kode HTML / Custom HTML (Lanjutan)",
        "btn_reset_default": "Reset Default",
        "hint_print_template": "Gunakan placeholder: {id}, {name}, {date}, {amount}, {packet}, {expired}, {header}, {footer}, {store_name}",
        "btn_reprint": "Cetak Ulang Struk",
        "lbl_print_receipt": "Cetak Struk",
        "lbl_valid_until": "Berlaku hingga",
        "lbl_receipt_title": "STRUK PEMBAYARAN",
        "lbl_backup": "Backup Data",
        "btn_to_tg": "KE TELEGRAM",
        "hint_backup": "File berisi database SQLite (topology.db).",
        "lbl_restore": "Restore Data",
        "btn_restore": "RESTORE",
        "warn_restore": "PERINGATAN: Data akan ditimpa total.",
        "lbl_clean_log": "Bersihkan Log System",
        "btn_reset_log": "RESET LOG",
        "btn_bk_now": "BACKUP SEKARANG (DOWNLOAD)",
        "lbl_bk_hist": "Riwayat Backup Server",
        "btn_refresh_bk": "REFRESH",
        "lbl_bk_time": "Waktu Backup Otomatis",
        "lbl_bk_days": "Simpan Selama (Hari)",
        "lbl_bk_include": "File yang di-backup:",
        "lbl_inc_db": "Database & Config (Topology, Settings, Finance, Config, License)",
        "lbl_inc_web": "Interface Web (Templates HTML & Bahasa/Lang Dict)",
        "tab_bk": "BACKUP",
        "tab_tele": "TELEGRAM",
        "lbl_auto_backup": "Aktifkan Auto Backup",
        "lbl_backup_time": "Waktu Backup",
        "lbl_keep_days": "Simpan (File)",
        "hint_bk_keep": "Jumlah file backup tersimpan (Max: 20).",
        "lbl_inc_files": "File yang Disertakan:",
        "hint_bk_safe": "Data backup disimpan di folder /backups secara berkala.",
        "conf_backup_now": "Backup Sekarang?",
        "msg_creating_zip": "Mengingat data/Membuat file backup...",
        "msg_req_error": "Gagal mengirim permintaan ke server.",
        "msg_tele_empty": "Token Bot & Chat ID tidak boleh kosong!",
        "msg_wa_del_err": "Gagal menghapus file backup.",

        // SETTINGS - SECURITY
        "lbl_pass_admin": "Password Administrator",
        "lbl_pass_view": "Password Viewer",
        "ph_pass_new": "Password Baru",
        "lbl_svc_name": "Service Name (Systemd)",
        "hint_svc": "Contoh: peycell-nms atau monitoring-wifi (tanpa .service)",
        "lbl_port": "App Port",
        "hint_port": "Port aplikasi (Wajib restart manual jika diubah).",
        "warn_sec": "Setelah disimpan, login menggunakan password baru. Service/Port butuh restart.",
        "btn_upd_sec": "UPDATE KEAMANAN",
        "lbl_login_activity": "Riwayat Login",
        "hint_login_activity": "Proteksi brute-force aktif. IP diblokir otomatis setelah 5x gagal login.",
        "lbl_active_sessions": "sesi aktif sekarang",
        "lbl_blocked_ips": "IP yang Diblokir",
        "lbl_min_remaining": "menit tersisa",
        "th_login_time": "Waktu",
        "th_login_ip": "Alamat IP",
        "th_login_device": "Perangkat",
        "th_login_role": "Role",
        "th_login_status": "Status",
        "lbl_login_success": "Berhasil",
        "lbl_login_failed": "Gagal",
        "lbl_login_blocked": "Diblokir",
        "msg_no_login_log": "Belum ada riwayat login.",
        "lbl_ota_drive": "UPDATE DARI CLOUD",
        "hint_ota_drive": "Klik tombol di bawah untuk memeriksa dan menginstal pembaruan sistem langsung dari server pusat (Cloud).",
        "btn_ota_drive": "UPDATE DARI CLOUD",
        "msg_update_avail": "🎉 PEMBARUAN TERSEDIA",
        "ph_bot_token": "123:AA...",
        "ph_chat_id": "-100...",
        "ph_wa_test": "Contoh: 08123456789",
        "btn_convert_now": "KONVERSI SEKARANG",
        "msg_mig_confirm": "Konversi database V2.9 (JSON) ke V3.0 (SQLite)?",
        "msg_mig_process": "Memproses migrasi...",
        "msg_ota_drive_confirm": "Update dari Cloud?",
        "msg_connecting_cloud": "Menghubungkan ke Cloud...",
        "lbl_smart_upd": "Smart Upload (Update / Restore)",
        "hint_smart_upd": "Unggah file .zip, .js, .html, .json, .py, .ico. Sistem akan mendeteksi target otomatis.",
        "lbl_mig_title": "ALAT MIGRASI V2.9 (JSON KE SQLITE)",
        "hint_mig_desc": "Gunakan alat ini jika Anda upgrade dari V2.9. Unggah file topology.json lama Anda untuk dikonversi otomatis ke database SQLite.",

        // SETTINGS - UPDATE
        "lbl_upd_file": "Update File (OTA)",
        "hint_upd": "Target yang didukung: app.py, dashboard.html, index.html, favicon.ico",
        "warn_upd": "Jika update app.py, service akan restart otomatis (Linux). Di Windows akan gagal (normal).",
        "lbl_restart": "Restart Service",
        "btn_restart": "RESTART",
        "hint_restart": "Restart diperlukan jika setelah simpan belum ada perubahan.",
        "msg_restart_wait": "OK! Mohon tunggu 5 detik sementara sistem memulai ulang...",

        // TRAFFIC
        "lbl_server_main": "Server Utama",
        "lbl_wan": "WAN:",
        "lbl_dl": "DOWNLOAD (Saat Ini)",
        "lbl_ul": "UPLOAD (Saat Ini)",
        "lbl_ping_ext": "Ping Eksternal",
        "lbl_target": "Target:",
        "hint_traffic": "Grafik menyimpan history lokal (browser) selama 30 menit.",
        "card_graph": "Grafik Traffic Langsung (30 Menit Terakhir)",
        "hint_graph_color": "Emas: Download | Oranye: Upload",

        // LOGS
        "th_time": "Jam",
        "th_device": "Nama Perangkat",
        "th_desc": "Keterangan",
        "th_status": "Status",
        "btn_clear_log": "BERSIHKAN LOG (RESET)",
        "ph_log_search": "Cari Log...",
        "lbl_showing": "Menampilkan",
        "lbl_of": "dari",
        "lbl_prev": "Sebelumnya",
        "lbl_next": "Berikutnya",
        "hs_u_gen": "GENERATOR",
        "hs_u_list": "DAFTAR USER",
        "hs_u_act": "SESI AKTIF",
        "hs_u_prof": "PROFIL",
        "pg_hotspot_title": "MANAJEMEN HOTSPOT",
        "pg_hotspot_subtitle": "Kelola voucher, pengguna aktif, dan profil kecepatan Hotspot MikroTik.",
        "hs_u_title_add": "TAMBAH HOTSPOT USER",
        "hs_u_title_edit": "EDIT HOTSPOT USER",
        "hs_addr_pool": "Address Pool",
        "hs_idle_timeout": "Idle Timeout",
        "hs_keepalive_timeout": "Keepalive Timeout",
        "hs_status_autorefresh": "Status Autorefresh",
        "hs_addr_list": "Address List",
        "hs_mac_cookie_timeout": "MAC Cookie Timeout",
        "hs_parent_queue": "Parent Queue",
        "hs_queue_type": "Queue Type",
        "hs_insert_before": "Insert Before",
        "hs_first": "First",
        "hs_last": "Last",
        "hs_desc_gen": "Generate new Hotspot vouchers (Random/Voucher).",
        "hs_desc_list": "Manajemen daftar pengguna Hotspot yang tersimpan.",
        "hs_desc_act": "Monitoring pengguna yang sedang terhubung saat ini.",
        "hs_desc_prof": "Manajemen profil kecepatan dan masa aktif Hotspot.",
        "hs_server": "Server",
        "hs_server_prof": "Hotspot Server",
        "hs_qty": "Jumlah",
        "hs_limit_uptime": "Limit Uptime",
        "hs_limit_data": "Limit Kuota",
        "hs_prefix": "Prefix Nama",
        "hs_theme": "Tema Cetak",
        "hs_theme_modern": "Modern Blue",
        "hs_theme_minimal": "Minimalis (Hemat)",
        "hs_theme_color": "Full Color",
        "hs_gen_mode": "Mode User",
        "hs_gen_mode_up": "User = Password",
        "hs_gen_mode_vc": "User & Password Beda",
        "hs_char_type": "Karakter",
        "hs_char_num": "Angka (123)",
        "hs_char_abc": "Huruf Kecil (abc)",
        "hs_char_ABC": "Huruf Besar (ABC)",
        "hs_char_mix": "Mix (abc123)",
        "hs_char_MIX": "Mix (ABC123abc)",
        "hs_char_len": "Panjang",
        "hs_comment": "Komentar",
        "hs_ph_time": "Contoh: 1h, 30m, 1d",
        "hs_ph_data": "Contoh: 500M, 1G (0=Tanpa Batas)",
        "hs_ph_prefix": "Contoh: VIP-, M-",
        "hs_ph_comment": "Label (generated-nms)",
        "hs_ph_login_url": "Contoh: wifi.login",
        "hs_btn_generate": "GENERATE VOUCHER ⚡",
        "hs_generated_title": "VOUCHER YANG BARU DIBUAT",
        "hs_btn_print_result": "CETAK HASIL",
        "hs_btn_print": "CETAK TERPILIH",
        "hs_confirm_del": "Hapus {count} voucher terpilih?",
        "hs_confirm_del_prof": "Hapus profil hotspot ini?",
        "hs_msg_success": "Berhasil membuat {count} voucher!",
        "hs_msg_del_success": "Berhasil menghapus {count} voucher!",
        "msg_vouchers_empty": "Tidak ada voucher terpilih untuk dicetak.",
        "th_username": "Username",
        "th_password": "Password",
        "th_profile": "Profil",
        "th_limit": "Limit",
        "th_address": "Alamat IP",
        "th_uptime": "Uptime",
        "th_bytes": "Total Traffic",
        "hs_confirm_kick": "Putuskan koneksi user ini?",
        "opt_select_prof": "-- Pilih Profil --",
        "opt_select_server": "-- Pilih Server --",
        "lbl_main": "(Utama)",
        "lbl_branch": "(Cabang)",
        "lbl_auto": "-- Otomatis --",
        "hs_err_req": "Profil dan Komentar wajib diisi!",
        "hs_confirm_gen": "Buat {qty} voucher sekarang?",
        "alert_name_required": "Nama wajib diisi!",
        "alert_saved": "Berhasil disimpan!",
        "ph_filter_batch": "Filter Komentar...",
        "hs_btn_print": "CETAK",
        "hs_btn_delete": "HAPUS",
        "msg_sel_vouchers": "Pilih voucher dulu!",

        // BILLING
        "card_bill_conf": "Konfigurasi Billing & Auto-Isolir",
        "lbl_last_check": "Billing Periksa Terakhir :",
        "btn_patrol_now": "JALANKAN PATROLI",
        "lbl_disabled": "DINONAKTIFKAN",
        "lbl_cooldown": "Sidak Berikutnya:",
        "msg_patrol_conf": "Mulai patroli billing sekarang?",
        "btn_confirm": "Ya, Jalankan",
        "msg_billing_check_done": "Patroli Billing selesai!",
        "lbl_due_date": "Tanggal Jatuh Tempo Default",
        "opt_date": "Tanggal",
        "hint_due_date": "Tanggal jatuh tempo tagihan bulanan global (Berlaku untuk client baru dan client lama yang belum diatur masa aktifnya). Jika tanggal tidak tersedia di bulan tersebut (misal tgl 30 Feb), akan otomatis menggunakan hari terakhir bulan itu.",
        "lbl_grace": "Grace Period (Hari)",
        "hint_grace": "Berapa hari setelah jatuh tempo sebelum auto-isolir.",
        "lbl_billing_system": "Sistem Penagihan",
        "opt_billing_monthly": "Siklus Bulanan (Global)",
        "opt_billing_cyclic": "Siklus 30 Hari (Adil)",
        "opt_billing_fixed": "Fixed Billing (Personal)",
        "hint_billing_system": "Pilih bagaimana sistem menghitung masa aktif pelanggan.",
        "lbl_days": "HARI",
        "lbl_isolir_prof": "Nama Profil Isolir MikroTik",
        "hint_isolir_prof": "Nama Profil/Address-list di router. Sistem akan otomatis membuatnya jika belum ada.",
        "lbl_enable_isolir": "Aktifkan Auto-Isolir",
        "lbl_coming_soon": "(AKTIF)",
        "hint_enable_isolir": "Centang untuk memfungsikan isolir otomatis setiap jam.",
        "lbl_wa_notif": "Aktifkan Notifikasi WhatsApp",
        "hint_wa_notif": "Kirim reminder otomatis. Jika diaktifkan, Tabel Jadwal Pengiriman akan muncul di bagian bawah halaman ini.",
        "btn_save_conf": "SIMPAN PENGATURAN",
        "tab_pricing": "MASTER HARGA",
        "tab_arrears": "LAPORAN TUNGGAKAN",
        "tab_config": "KONFIGURASI",
        "lbl_wa_rem_end_month": "Reminder Akhir Bulan (Manual Template)",
        "hint_wa_rem_end_month": "Kirim template manual ke klien yang belum bayar di setiap hari terakhir bulan berjalan. (Mendukung {price}, {expired}, dll)",
        "lbl_wa_rem_pre_isolir": "Reminder H-X Sebelum Isolir (Auto Template)",
        "hint_wa_rem_pre_isolir": "Kirim peringatan isolir beberapa hari sebelum pemutusan (Mendukung {price}, {expired}, dll).",
        "lbl_wa_notif_time": "Jam Pengiriman Otomatis",
        "hint_wa_notif_time": "Format HH:MM (Contoh 08:30). Notifikasi dikirim serentak pada jam ini.",
        "lbl_billing_interval": "Interval Pengecekan Otomatis",
        "hint_billing_interval": "Frekuensi sistem mengecek tunggakan dan mengisolir otomatis.",
        "lbl_manual_test": "Test Manual Isolir (Opsional)",
        "ph_pppoe_user": "Username PPPoE (Kosongkan = Semua)",
        "btn_test_isolir": "TES ISOLIR SEKARANG",
        "hint_conf_title": "⚙️ PANDUAN KONFIGURASI OTOMATIS:",
        "hint_conf_cycle_m": "Metode bulanan (sama semua) : semua klien jatuh temponya akan sama (ini cocok untuk yang memakai tagihan akhir bulan, karena notif akhir bulan akan dikirim di hari terakhir di bulan tersebut)",
        "hint_conf_cycle_c": "Metode 30 hari : jatuh tempo akan bertambah 30 hari dari hari terakhir jatuh tempo ( tanggal jatuh tempo bisa berubah ubah )",
        "hint_conf_cycle_f": "Metode fixed day : tiap klien bisa memiliki tanggal jatuh tempo sendiri sendiri",
        "hint_conf_grace": "Grace period : Masa toleransi atau bonus, jika di isi 3, isolir dilakukan pada hari ke 4 setelah jatuh tempo",
        "hint_conf_isolir_mk": "Profil isolir : Wajib sama persis namanya isolirnya, jika pakai pppoe nama profil isolir pppoe harus sama seperti yang di isi, kalau ip statik nama address list harus sama persis sama yang di isi.",
        "hint_conf_auto_isolir": "Aktifkan auto isolir : kalau mau memakai auto isolir bisa di aktifkan, support auto isolir pppoe, ip statik, radius",
        "hint_conf_wa_notif": "Kirim notifikasi WA :<br>&nbsp;&nbsp;&bull; Metode bulanan (sama semua) : akan di kirim di hari terakhir di bulan tersebut.<br>&nbsp;&nbsp;&bull; Metode 30 hari/fixed day : akan di kirim di hari terakhir masa aktifnya",
        "hint_conf_wa_h": "Peringatan H- : isi peringatan hari sebelum kena auto isolir",
        "hint_conf_wa_time": "Jam kirim notif : ini bertindak 2 fungsi, jam dia kirim notifikasi akhir bulan, sebelum isolir, dan isolir di jam tersebut.",
        "hint_conf_static_title": "KHUSUS IP STATIK & RADIUS:",
        "hint_conf_static_cmd": "Wajib pasang perintah ini di Terminal MikroTik agar isolir berfungsi:",
        "info_how_it_works": "Cara Kerja Auto-Isolir",
        "pg_bill_title": "BILLING & TAGIHAN",
        "pg_bill_subtitle": "Konfigurasi sistem penagihan otomatis dan isolir.",
        "tab_pricing": "Master Harga",
        "tab_arrears": "Laporan Tunggakan",
        "card_pricing_title": "Master Harga Paket",
        "card_pricing_subtitle": "Mapping harga",
        "hint_pricing_master": "Harga paket ini digunakan untuk menghitung estimasi pendapatan dan total tagihan pada Laporan Tunggakan.",
        "hint_pricing_title": "PENTING: Sinkronisasi Nama Paket",
        "hint_pricing_match": "Nama paket (profil) di sini harus sama persis dengan yang ada di menu Edit Client agar sistem bisa otomatis mendeteksi harganya.",
        "hint_pricing_mikrotik": "Untuk PPPoE MikroTik: Isikan sesuai nama 'Profile' di MikroTik.",
        "hint_pricing_static": "Untuk IP Statik & PPPoE Radius: Isikan sesuai nama 'Paket' yang Anda buat di Edit Client.",
        "lbl_hotspot_voucher_desc": "KHUSUS HOTSPOT VOUCHER",
        "btn_import_prof": "IMPORT PROFIL",
        "btn_add_manual": "TAMBAH MANUAL",
        "th_paket_name": "Nama Paket",
        "th_price": "Harga (Rp)",
        "lbl_enable_tax": "Aktifkan Pajak (PPN)",
        "lbl_tax_rate": "Persentase Pajak (%)",
        "th_tax": "Pajak",
        "th_total_price": "Total (Termasuk Pajak)",
        "msg_no_price": "Belum ada data harga.",
        "btn_save_price": "SIMPAN HARGA",
        "card_arrears_title": "Laporan Tunggakan",
        "card_arrears_subtitle": "Total tagihan dan tunggakan berjalan untuk klien yang belum bayar",
        "th_due_date": "Jatuh Tempo",
        "msg_no_arrears": "Tidak ada tunggakan.",
        "lbl_arrears_total_month": "Total Tunggakan Bulan",
        "msg_loading_data": "Memuat data...",
        "msg_import_mk_confirm": "Impor profil Mikrotik?",
        "msg_import_success": "profil baru diimpor dari Mikrotik.",
        "msg_err_fetch_prof": "Gagal ambil profil: ",
        "msg_err_conn": "Gagal konek: ",
        "msg_confirm_del_prof": "Hapus harga paket: ",
        "btn_prune_prof": "Bersihkan Paket Usang",
        "msg_prune_no_orphans": "Tidak ditemukan profil MikroTik yang usang.",
        "msg_prune_confirm": "Profil MikroTik berikut sudah tidak ada di router:\n\n{list}\n\n🚨 HATI-HATI: Profil ini mungkin digunakan untuk klien IP STATIK atau RADIUS.\nApakah Anda yakin ingin menghapus profil-profil ini dari Master Harga?",
        "msg_prune_success": " profil usang telah dihapus.",
        "msg_prompt_paket": "Masukkan Nama Paket (Harus persis dengan di Client):",
        "msg_prof_exists": "Profil sudah ada!",
        "msg_no_finance_data": "Data keuangan belum dimuat. Refresh halaman.",
        "msg_all_pd": "✅ Semua client tertib bayar! Tidak ada tunggakan.",
        "msg_open_client": "Buka Client",
        "msg_months": "Bulan",
        "msg_maintenance": "Fitur sedang dalam pemeliharaan",
        "msg_confirm_test_isolir": "Yakin ingin menjalankan tes isolir untuk ",
        "msg_all_clients": "semua client",
        "msg_billing_check_done": "Cek isolir selesai!",
        "lbl_paid_until_full": "LUNAS S/D (MASA AKTIF)",
        "hint_paid_until_full": "*Tanggal terakhir client lunas (jatuh tempo)",
        "lbl_arrears_warning": "NUNGGAK",
        "lbl_active_success": "MASIH AKTIF",
        "lbl_arrears_suffix": "Bulan",
        "lbl_paid_until_short": "Lunas s/d",
        "lbl_arrears_months": "Nunggak (Bln)",
        "lbl_manual_arrears": "Tunggakan Manual (Ajustmen)",
        "btn_add_manual_arrears": "TAMBAH TUNGGAKAN",
        "th_arrears_amount": "Nominal",
        "th_arrears_desc": "Keterangan",
        "lbl_choose_client": "Pilih Klien",
        "lbl_arrears_note": "Catatan / Keterangan",
        "ph_arrears_amount": "Contoh: 27000",
        "ph_arrears_desc": "Contoh: Sisa bulan lalu / Ganti kabel",
        "msg_confirm_del_arrears": "Hapus tunggakan manual untuk ",
        "hint_arrears_title": "INFO PERHITUNGAN TAGIHAN:",
        "hint_arrears_calc": "Angka Tagihan: (Harga Paket x Bln) + Ajustmen. Label bulan (Jan, Feb, dst) membantu identifikasi periode yang ditagih.",
        "hint_arrears_manual": "Ajustmen Manual: Tambah biaya lain-lain (denda/alat) atau aktifkan fitur 'Gratis Selamanya' untuk membebaskan klien dari tagihan.",
        "hint_arrears_sync": "Sinkronisasi: Data diperbarui otomatis saat pengecekan berkala (Isolir Check).",
        "hint_arrears_negative": "Tips: Gunakan angka <strong>Minus (-)</strong> untuk Saldo / Kelebihan Bayar.",
        "msg_loading_data": "Memuat data...",

        // Manual Arrears New Keys
        "modal_title_add_arrears": "Tambah Tunggakan",
        "modal_title_edit_arrears": "Edit Tunggakan",
        "msg_select_client_first": "Pilih klien terlebih dahulu!",
        "msg_nominal_required": "Nominal harus diisi!",

        // FINANCE
        "fin_title_page": "LAPORAN KEUANGAN & KAS",
        "fin_income_label": "PEMASUKAN (BULAN INI)",
        "fin_expense_label": "PENGELUARAN (BULAN INI)",
        "fin_balance_month_label": "SALDO BULAN INI",
        "fin_balance_total_label": "TOTAL SALDO KAS",
        "fin_month_heading": "Keuangan Bulan ",
        "lbl_filter_date": "FILTER TANGGAL",
        "fin_txt_loading": "Memuat data...",
        "fin_h_archive": "ARSIP LAPORAN BULANAN",
        "fin_txt_no_archive": "Belum ada riwayat laporan bulan lalu.",
        "modal_tx_title": "Catat Transaksi Baru",
        "modal_tx_edit_title": "Edit Transaksi",
        "lbl_tx_type": "Jenis Transaksi",
        "opt_income": "Pemasukan (+)",
        "opt_expense": "Pengeluaran (-)",
        "lbl_tx_client": "Nama Client (Auto Buka Isolir)",
        "hint_tx_client": "Otomatis buka isolir jika client dipilih. (Khusus Client PPPoE).",
        "lbl_tx_cat": "Kategori",
        "lbl_tx_amount": "Nominal (Rp)",
        "lbl_tx_note": "Catatan",
        "ph_tx_note": "Deskripsi transaksi...",
        "fin_alert_nominal": "Nominal harus diisi!",
        "fin_err_save": "Gagal simpan transaksi: ",
        "fin_confirm_del": "Hapus transaksi ini?",
        "fin_export_empty": "Data filter kosong. Tidak ada yang bisa di-eksport.",
        "fin_csv_header": "TANGGAL,TIPE,KATEGORI,CATATAN,NOMINAL,USER",
        "fin_no_data": "Tidak ada data transaksi.",
        "cat_wifi": "Pembayaran WiFi",
        "fin_report_btn": "Laporan",
        "opt_choose_client": "-- Pilih Client (Opsional) --",
        "lbl_hal": "Hal",
        "months": ["JAN", "FEB", "MAR", "APR", "MEI", "JUN", "JUL", "AGU", "SEP", "OKT", "NOV", "DES"],
        "fin_in_pill": "MASUK",
        "fin_out_pill": "KELUAR",
        "fin_income_title": "Pemasukan (Bulan Ini)",
        "fin_expense_title": "Pengeluaran (Bulan Ini)",
        "fin_balance_month_title": "Saldo Bulan Ini",
        "fin_balance_total_title": "Total Saldo Kas",
        "fin_th_date": "Tanggal",
        "fin_th_type": "Tipe",
        "fin_th_category": "Kategori",
        "fin_th_notes": "Keterangan",
        "fin_th_amount": "Nominal",
        "fin_th_user": "User",
        "fin_th_action": "Aksi",
        "fin_btn_filter": "FILTER",
        "fin_btn_reset": "RESET",
        "fin_btn_excel": "EXCEL (LOG)",
        "fin_btn_add_tx": "+ INPUT TRANSAKSI",
        "msg_no_mk_configured": "Belum ada MikroTik yang dikonfigurasi.",
        "lbl_detecting": "Mendeteksi...",
        "btn_login": "MASUK",
        "ph_password": "Password...",
        "ph_user_alphanumeric": "Username (alfanumerik)",
        "hs_time_hint": "Format: 1d (hari), 1h (jam), 30m (menit).",

        // MISC generic
        "msg_loading": "Memuat...",
        "msg_error": "Terjadi Kesalahan",
        "msg_saved": "Berhasil Disimpan",
        "alert_saved": "Tersimpan",
        "alert_admin_only": "Hanya admin.",
        "alert_save_failed": "Gagal simpan",
        "alert_conn_failed": "Gagal konek server",
        "alert_update_failed": "Gagal update",
        "alert_security_updated": "Keamanan & System Config diperbarui. Jika Port/Service berubah, restart diperlukan.",
        "msg_pwd_changed_logout": "Password berhasil diganti. Silakan login kembali.",
        "alert_select_file": "Pilih file database (.db, .json, .zip)",
        "confirm_restore_db": "Restore database?",
        "alert_restore_success": "Restore berhasil! Halaman akan reload...",
        "alert_restore_failed": "Gagal restore:",
        "alert_upload_failed": "Gagal upload:",
        "alert_restore_ok": "Restore sukses",
        "confirm_restart": "Restart service?",
        "alert_restart_ok": "Restart OK",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "msg_set_not_loaded": "Data settings belum dimuat.",
        "msg_saved_ok": "Berhasil disimpan!",
        "conf_logout": "Logout?",
        "btn_refresh": "REFRESH",
        "btn_delete": "HAPUS",
        "lbl_auto": "OTOMATIS",
        "lbl_cable_km": "KABEL (KM)",
        "msg_saving": "MENYIMPAN...",
        "msg_req_err": "Kesalahan Request",
        "msg_sending": "Mengirim...",
        "msg_no_backup_files": "Belum ada file backup di server.",
        "msg_fail_load_list": "Gagal memuat list.",
        "conf_del_item": "Hapus item ini?",
        "conf_del_stock": "Hapus item gudang?",
        "msg_pwd_wrong": "Password Salah!",
        "msg_all_pd": "Semua Lunas",
        "msg_billing_check_done": "Cek billing selesai.",
        "msg_confirm_test_isolir": "Jalankan cek billing untuk ",
        "msg_all_clients": "Semua Client",

        // PPPoE
        "sb_pppoe": "PPPoE",
        "pp_u_create": "TAMBAH USER",
        "pp_u_list": "DAFTAR SECRET",
        "pp_u_act": "SESI AKTIF",
        "pp_u_prof": "PROFIL",
        "pp_desc_create": "Tambah secret PPPoE baru ke MikroTik.",
        "pp_desc_list": "Manajemen daftar secret PPPoE yang tersimpan.",
        "pp_desc_act": "Monitoring pengguna PPPoE yang sedang terhubung.",
        "pp_desc_prof": "Daftar profil PPP yang tersedia di MikroTik.",
        "pp_user": "Username",
        "pp_pass": "Password",
        "pp_service": "Service",
        "pp_remote_addr": "Remote Address",
        "pp_caller_id": "Caller ID",
        "pp_btn_create": "BUAT USER PPPoE",
        "pp_confirm_del": "Hapus {count} secret PPPoE terpilih?",
        "pp_msg_create_success": "Berhasil membuat user PPPoE!",
        "pp_msg_del_success": "Berhasil menghapus {count} secret!",
        "pp_ph_user": "Username...",
        "pp_ph_pass": "Password...",
        "pp_ph_comment": "Komentar / Label",
        "pp_title_edit": "Edit User PPPoE",
        "pp_msg_update_success": "Berhasil memperbarui user!",
        "pp_btn_save": "SIMPAN PERUBAHAN",
        "pp_local_addr": "Alamat Lokal",
        "pp_last_logged_out": "Terakhir Logout",
        "pp_disc_reason": "Alasan Diskon",
        "pp_toggle_pass_hide": "Sembunyikan",
        "pp_toggle_pass_show": "Tampilkan Password",
        "pp_ph_select_server": "-- Pilih Server --",
        "pp_ph_select_profile": "-- Pilih Profil --",
        "pp_only_one": "Only One",
        "pp_ph_local_addr": "Contoh: 192.168.1.1 (Opsional)",
        "pp_ph_remote_addr": "Contoh: 192.168.1.0/24 (Opsional)",
        "pp_u_addprof": "TAMBAH PROFIL",
        "pp_addprof_desc": "Buat profil PPP baru di MikroTik.",
        "pp_addprof_name": "Nama Profil",
        "pp_addprof_dns": "DNS Server",
        "pp_addprof_rate": "Rate Limit",
        "pp_addprof_iq": "Insert Queue Before",
        "pp_addprof_pq": "Parent Queue",
        "pp_addprof_qtu": "Queue Type Upload",
        "pp_addprof_qtd": "Queue Type Download",
        "pp_addprof_ph_name": "Nama profil (wajib)...",
        "pp_addprof_ph_dns": "Contoh: 8.8.8.8,8.8.4.4 (Opsional)",
        "pp_addprof_ph_rate": "Contoh: 10M/5M (Opsional)",
        "pp_addprof_opt_def": "-- Default --",
        "pp_addprof_opt_none": "(none)",
        "pp_addprof_btn": "BUAT PROFIL",
        "pp_addprof_ok": "Profil berhasil dibuat!",
        "pp_addprof_err_name": "Nama profil wajib diisi.",
        "pp_delprof_confirm": "Hapus profil '{name}'? Peringatan: user yang memakai profil ini bisa terpengaruh!",
        "pp_delprof_ok": "Profil berhasil dihapus!",
        "pp_prof_title_edit": "Edit Profile PPPoE",
        "pp_msg_prof_update_success": "Berhasil memperbarui profil!",
        "pp_title_main": "MANAJEMEN PPPoE",
        "pp_subtitle_main": "Kelola pelanggan PPPoE, monitoring status, dan integrasi billing MikroTik.",
        "pp_stats_total": "TOTAL SECRET",
        "pp_stats_online": "ONLINE",
        "pp_stats_disabled": "NONAKTIF",
        "pp_stats_expired": "EXPIRED",
        "pp_btn_export": "EXPORT CSV",
        "pp_profile": "Profil PPPoE",
        "lbl_traffic_24h": "GRAFIK TRAFFIC 24 JAM TERAKHIR",
        "lbl_traffic_7d": "GRAFIK TRAFFIC 7 HARI TERAKHIR",
        "lbl_chart_update_daily": "* data di update 1 hari sekali",
        "pp_th_status": "STATUS",
        "pp_th_maps": "MAPS",
        "pp_th_billing": "BILLING",
        "pp_th_reason": "ALASAN",
        "pp_badge_mapped": "Sudah",
        "pp_badge_nomap": "Belum",
        "pp_badge_paid": "Lunas",
        "pp_badge_expired": "Isolir",
        "pp_toast_toggle": "User <b>{name}</b> {status}",
        "pp_toast_activated": "diaktifkan",
        "pp_toast_disabled": "dinonaktifkan",
        "pp_btn_check": "Cek",
        "pp_tt_check": "Cek Ketersediaan",
        "pp_tt_toggle_pass": "Lihat/Sembunyikan",
        "pp_tt_gen_pass": "Generate Password",

        // MAPS & MODALS
        "map_title_label": "Label (Sembunyikan/Tampilkan)",
        "map_title_autoref": "Auto Refresh",
        "lbl_parent_src": "Sumber Uplink (Parent)",
        "opt_sel_parent": "-- Pilih Induk --",
        "msg_sel_parent_first": "-- Pilih Induk Dulu --",
        "ph_port_man": "Ketik Port...",
        "lbl_from_port_short": "Dari Port",
        "fab_add_mk": "Tambah MikroTik (Cabang)",
        "fab_add_olt": "Tambah OLT (Active)",
        "fab_add_odp": "Tambah ODP",
        "fab_add_client": "Tambah Client",
        "modal_edit_title": "Edit Perangkat",
        "lbl_choose_mk": "PILIH MIKROTIK PENGELOLA",
        "lbl_mk_login_conf": "Konfigurasi Login MikroTik",
        "lbl_client_type": "JENIS KLIEN (KONEKSI)",
        "lbl_dev_name": "Nama Perangkat",
        "lbl_notes": "Catatan / Keterangan",
        "ph_notes": "Tulis catatan (teknisi, lokasi kunci, dll)...",
        "lbl_pos_status": "Status Posisi",
        "opt_locked": "Locked (Terkunci)",
        "opt_unlocked": "Unlocked (Bisa Geser)",
        "lbl_srv_lan": "Jumlah Port LAN (Auto / Manual)",
        "lbl_srv_sfp": "Jumlah Port SFP (Auto / Manual)",
        "lbl_man_wan": "MANUAL WAN INTERFACE",
        "lbl_ext_ping": "TARGET PING EXTERNAL",
        "lbl_det_status": "Status Deteksi Saat Ini",
        "btn_edit_path": "EDIT JALUR (GESER/TARIK)",
        "lbl_odp_type": "Tipe ODP",
        "lbl_lan_count": "Jumlah Port LAN",
        "lbl_fo_a": "Jml FO A",
        "lbl_fo_b": "Jml FO B",
        "lbl_tech": "Teknologi",
        "lbl_pon_out": "Jumlah Port PON (Output)",
        "lbl_uplink_in": "Jumlah Port Uplink (Input)",
        "lbl_slot_out": "Jumlah Output Slot (Drop)",
        "lbl_dist_mode": "Mode Distribusi:",
        "lbl_core_cap": "Kapasitas Core",
        "lbl_uplink_src": "KONEKSI SUMBER (UPLINK)",
        "lbl_parent": "Induk (Parent)",
        "lbl_from_port": "Dari Port Parent (Output)",
        "lbl_cable_color": "Warna Kabel / Tube",
        "lbl_input_port": "Masuk ke Port ODP",
        "chk_poe_in": "Input Bawa PoE?",
        "lbl_ip_man": "IP Address (Manual)",
        "lbl_mon_mode": "METODE MONITORING (IP STATIK)",
        "lbl_pppoe_user": "PILIH USER PPPoE (DARI MIKROTIK)",
        "lbl_client_detail": "RINCIAN KLIEN (AUTO)",
        "lbl_prof_now": "PROFIL SAAT INI",
        "lbl_change_prof": "GANTI PROFIL",
        "btn_update": "UPDATE",
        "btn_kick": "KICK USER",
        "chk_poe_src": "Client ini Sumber POE?",
        "lbl_wifi_data": "Data Login & WiFi",
        "lbl_wifi": "WiFi SSID",
        "lbl_photo_loc": "FOTO LOKASI / TIANG ODP",
        "btn_take_photo": "AMBIL / UPLOAD FOTO",
        "btn_del_dev": "HAPUS PERANGKAT",
        "btn_cancel": "BATAL",
        "btn_save": "SIMPAN",
        "btn_remote": "REMOTE ROUTER",
        "btn_chat_wa": "CHAT WHATSAPP",
        "btn_bill": "TAGIH PELANGGAN",
        "modal_log_title": "HISTORY LOG",
        "btn_close": "TUTUP",
        "lbl_cable_len": "PANJANG KABEL:",
        "btn_reset_straight": "RESET LURUS",
        "btn_cancel_draw": "BATAL",
        "btn_save_path": "SIMPAN JALUR",
        "map_lbl_client_list": "CLIENT LIST",
        "map_lbl_on": "ON:",
        "map_lbl_off": "OFF:",
        "map_title_show_offline": "Tampilkan Offline Saja",
        // LICENSE
        "pg_lic_title": "Aktivasi License - PEYCELL NMS",
        "lbl_lic_active": "License Aktif",
        "msg_lic_registered": "Aplikasi ini sudah terdaftar resmi.",
        "lbl_lic_type": "Tipe Lisensi",
        "lbl_lic_owner": "Pemilik Lisensi",
        "lbl_machine_id": "Machine ID",
        "btn_enter_dash": "MASUK KE DASHBOARD",
        "lbl_lic_activation": "Aktivasi License",
        "msg_lic_locked": "Aplikasi ini terkunci dan memerlukan lisensi aktif.",
        "lbl_your_mid": "Machine ID Anda",
        "lbl_name": "Nama Lengkap (Data Pembeli)",
        "ph_name": "Masukkan nama Anda...",
        "lbl_email": "Alamat Email",
        "ph_email": "contoh@email.com",
        "msg_copy_mid": "Salin Machine ID di atas, lalu kirim ke Administrator untuk mendapatkan Lisensi:",
        "lbl_input_lic": "Masukkan License Key",
        "ph_lic_key": "Tempel kode lisensi di sini...",
        "btn_activate": "AKTIFKAN SEKARANG",
        "footer_nms": "PEYCELL NETWORK MANAGEMENT SYSTEM",
        "err_empty_lic": "Isi license key dulu!",
        "msg_processing": "Memproses...",
        "msg_lic_success": "Lisensi Berhasil Diaktifkan! Mengalihkan...",
        "err_lic_fail": "Aktivasi gagal",
        "err_conn": "Error koneksi: ",
        // DYNAMIC JS
        "btn_remote_on": "REMOTE ROUTER (ON)",
        "btn_remote_off": "ROUTER OFFLINE",
        "opt_select_prof": "-- Pilih Profil --",
        "prof_current": "(Saat Ini)",
        "tt_model": "Model",
        "tt_cpu": "CPU",
        "tt_uptime": "Uptime",
        "tt_internet": "Internet",
        "tt_traffic_wan": "TRAFFIC WAN",
        "tt_note": "Catatan",
        "th_time": "Waktu",
        "th_message": "Pesan",
        "th_type": "Tipe",
        "th_name": "Nama",
        "th_name": "Nama",
        "msg_no_logs": "Tidak ada log.",
        // ALERTS & MESSAGES
        "msg_save_error": "Save Error: ",
        "msg_save_fail": "Gagal menyimpan (Server Error/Auth)",
        "conf_del_client": "Yakin ingin menghapus client ini?",
        "conf_del_router": "Yakin hapus Router Cabang ini? Data klien yang dikelola router ini akan dikembalikan ke Server Utama.",
        "conf_del_node": "Yakin hapus Node ini? PERINGATAN: Semua perangkat di bawahnya akan kehilangan induk!",
        "alert_server_del": "Server Utama TIDAK BOLEH dihapus!",
        "msg_restore_success": "RESTORE SUKSES! Database berhasil diperbarui.",
        "msg_restore_fail_auth": "GAGAL: Password Salah/Sesi Habis. Silakan Logout & Login ulang.",
        "msg_restore_fail_size": "GAGAL: File terlalu besar.",
        "msg_restore_fail_srv": "GAGAL: Server Error ",
        "msg_conn_fail": "Gagal koneksi: ",
        "msg_read_fail": "Gagal membaca file backup: ",
        "conf_send_telegram": "Kirim database terbaru ke Telegram sekarang?",
        "msg_tele_success": "Backup terkirim ke Telegram!",
        "msg_tele_skipped": "Token/ChatID belum diatur di app.py",
        "msg_tele_fail": "Gagal: ",
        "alert_save_first": "Simpan perangkat baru dulu sebelum edit jalur.",
        "alert_no_parent_coord": "Gagal mendeteksi koordinat induk! Pastikan induk sudah dipilih.",
        "conf_overwrite": "PERINGATAN: Ini akan menimpa seluruh data topologi dengan file backup! Lanjutkan?",
        "msg_restore_ok_reload": "Restore berhasil! Halaman akan dimuat ulang.",
        "msg_restore_fail_gen": "Gagal Restore: ",
        "msg_del_fail": "Gagal hapus: ",
        "msg_del_err": "Error deleting photo",
        "msg_upload_fail": "Gagal upload: ",
        "msg_upload_err": "Error upload",
        "conf_del_photo": "Hapus foto ini?",
        "alert_guest_dash": "Login teknisi tidak diijinkan masuk dashboard",
        "lbl_no_photo": "Belum ada foto",
        "lbl_compressing": "Mengompres...",
        "lbl_uploading": "Mengupload...",
        "lbl_upload_fail": "Gagal upload",
        "lbl_upload_err": "Error upload",
        "lbl_lic_active_badge": "LICENSE ACTIVE",
        "lbl_center": "(PUSAT)",
        "lbl_branch": "(CABANG)",
        "pg_mon_logs_title": "MONITORING & LOGS",
        "pg_mon_logs_subtitle": "Pantau traffic real-time dan riwayat gangguan client.",
        "card_traffic_graph": "Live Traffic Graph (S30 Menit Terakhir)",
        "hint_traffic_color": "Emas: Download | Oranye: Upload",
        "conf_clear_logs": "Bersihkan semua log gangguan?",
        "err_reset_logs": "Gagal membersihkan log.",
        "msg_waiting_data": "Menunggu data...",
        "msg_loading_logs": "Memuat log...",
        "lbl_ping_ext": "Ping Eksternal",
        "lbl_dl": "DOWNLOAD",
        "lbl_ul": "UPLOAD",
        "ph_log_search": "Cari nama client atau pesan...",
        "btn_clear_log": "BERSIHKAN LOG (RESET)",
        "card_traffic_graph": "Grafik Live Traffic (30 Menit Terakhir)",
        "msg_waiting_data": "Menunggu data...",
        "conf_clear_logs": "Bersihkan semua log gangguan?",
        "err_reset_logs": "Gagal membersihkan log.",
        "lbl_isolir_pill": "ISOLIR",
        "btn_download": "UNDUH",
        "lbl_empty": "Kosong",
        "lbl_ver_installed": "Versi Terinstall",
        "lbl_ver_latest": "Terbaru",
        "conf_backup_now": "Backup sekarang?",

        // NEW FINANCE
        "fin_rep_title": "📁 Laporan Bulanan (Download)",
        "fin_txt_no_data": "Belum ada laporan bulan sebelumnya tersedia (akan muncul otomatis bulan depan).",
        "lbl_page": "Halaman",
        "lbl_of": "dari",
        "lbl_clients": "Klien",

        // CLIENT ACTIONS
        "btn_activate": "✅ AKTIFKAN",
        "btn_isolate": "🔴 ISOLIR",
        "btn_pay": "BAYAR",
        "btn_paid": "LUNAS",
        "btn_free": "GRATIS",
        "tt_bypass_on": "Bypass ON (Bebas Tagihan)",
        "tt_bypass_off": "Aktifkan Bypass",
        "leg_action": "PANDUAN AKSI & STATUS BILLING:",
        "leg_billing_on": "BILLING ON",
        "leg_billing_on_desc": "Sistem Aktif (Mendeteksi tunggakan, mengirim notifikasi WA, dan isolir otomatis).",
        "leg_billing_off": "BILLING OFF",
        "leg_billing_off_desc": "Nonaktifkan Billing (Klien tidak akan ditagih dan tidak akan pernah terisolir).",
        "leg_free": "FREE / BYPASS",
        "leg_free_desc": "Tunda Isolir (Gunakan untuk klien yang janji bayar bulan depan agar tetap aktif).",
        "leg_isolir": "ISOLIR",
        "leg_isolir_hint": "(Koneksi Terputus)",
        "leg_pay": "BAYAR (Input Pembayaran)",
        "leg_pay_hint": "(Bisa bayar double untuk perpanjang masa aktif otomatis)",
        "leg_paid": "LUNAS (Bulan Berjalan)",
        "leg_wa_rem": "WHATSAPP",
        "leg_wa_rem_hint": "(Kirim Tagihan Manual)",
        "info_isolate_title": "🛡️ INFO ISOLIR (PPPoE & STATIK IP):",
        "info_isolate_desc": "Status ISOLIR memutus internet sementara. Profil PPPoE berganti, IP Statik / Radius masuk ke list 'ISOLIR'.",
        "leg_terminal_hint": "Salin & Tempel ke Terminal MikroTik",
        "info_isolate_req": "Syarat: Profil & Address List MikroTik harus bernama ISOLIR.",
        "info_isolate_cmd": "KHUSUS IP STATIK & RADIUS: Wajib pasang perintah ini di Terminal MikroTik agar isolir berfungsi:\n/ip firewall filter add chain=forward action=drop src-address-list=ISOLIR comment=\"ISOLIR IP STATIK atau PPPOE RADIUS by nms peycell\" place-before=0",
        "map_btn_dash": "KEMBALI KE DASHBOARD",
        "map_title_logout": "Keluar",
        "map_title_outage": "Riwayat Gangguan",
        "map_title_backup": "Backup ke Telegram",
        "map_title_anim": "Animasi Kabel",
        "map_type_dark": "GELAP",
        "map_type_hybrid": "HYBRID",
        "map_type_clean": "CLEAN",

        // MISSING KEYS (ADDED)
        "lbl_fav": "Favicon",
        "lbl_qris": "QRIS Pembayaran",
        "lbl_bank_name": "Nama Bank",
        "lbl_bank_acc_no": "Nomor Rekening",
        "lbl_bank_acc_name": "Atas Nama (Pemilik)",
        "hdr_bank_acc": "Rincian Rekening",
        "hint_qris": "Upload QRIS untuk pembayaran otomatis. Format: JPG/PNG.",
        "lbl_custom_logo": "Custom Login Logo",
        "hint_logo": "Logo ditampilkan di halaman login. Maks: 500KB. Format: PNG, JPG, GIF, SVG",
        "btn_remove": "HAPUS",
        "btn_upload": "UPLOAD",
        "coming_soon": "SEGERA HADIR",
        "btn_billing_enable": "Aktifkan Billing",
        "btn_billing_disable": "Matikan Billing",
        "btn_billing_enable_all": "AKTIFKAN SEMUA BILLING",
        "btn_billing_disable_all": "NONAKTIFKAN SEMUA BILLING",
        "msg_billing_repair": "⚠️ Fitur ini sedang dalam perbaikan. Untuk sementara fitur Auto-Isolir tidak tersedia. Gunakan isolir manual melalui edit client.",
        "ph_stock_name": "Contoh: Kabel Dropcore 1 Roll",
        "alert_stock_name": "Isi nama barang gudang",
        "alert_stock_qty": "Jumlah minimal 1",
        "alert_stock_saved": "Stok Gudang Tersimpan",
        "confirm_del_stock": "Hapus item gudang ini?",
        "btn_reset_auto": "Reset ke Otomatis",
        "lbl_auto": "OTOMATIS",
        "map_odp_used_by": "ODP ini dipakai oleh:",
        "map_odp_no_users": "ODP ini belum ada yang pakai",
        "fin_modal_title": "Input Transaksi Manual",
        "fin_label_type": "Jenis Transaksi",
        "fin_opt_expense": "Pengeluaran (Uang Keluar)",
        "fin_opt_income": "Pemasukan (Uang Masuk)",
        "fin_label_cat": "Kategori",
        "fin_label_amount": "Nominal (Rp)",
        "fin_label_note": "Keterangan",
        "fin_ph_note": "Contoh: Beli kabel 1 roll",
        "fin_btn_save": "SIMPAN TRANSAKSI",

        // KATEGORI KEUANGAN
        "cat_invest": "Investasi",
        "cat_grant": "Hibah",
        "cat_others": "Lain-lain",
        "cat_tools": "Belanja Alat",
        "cat_maint": "Maintenance",
        "cat_ops": "Operasional",
        "cat_salary": "Gaji",

        "cat_wifi": "Pembayaran WiFi",
        "cat_carryover": "Saldo Pindahan Bulan Lalu",
        "fin_no_data": "Data tidak ditemukan",
        "fin_confirm_del": "Hapus transaksi ini?",
        "fin_alert_nominal": "Nominal wajib diisi!",
        "fin_csv_header": "TANGGAL,TIPE,KATEGORI,CATATAN,NOMINAL,USER",
        "fin_report_btn": "Laporan ",
        "fin_export_empty": "Tidak ada data untuk diexport",
        "fin_txt_loading": "Memuat data...",
        "fin_err_save": "Gagal menyimpan: ",
        "fin_err_id": "ID Tidak Ditemukan",
        "lbl_schedule_today": "Jadwal Pengiriman Notifikasi & Isolir Hari Ini",
        "lbl_today": "Hari Ini",
        "th_date": "Tanggal",
        "th_purpose": "Tujuan",
        "th_status": "Status",
        "msg_loading_schedule": "Memuat jadwal...",
        "lbl_status_sent": "Terkirim",
        "lbl_status_isolated": "Terisolir",
        "lbl_status_waiting": "Menunggu",
        "lbl_status_done": "Selesai / Lunas",
        "btn_add_user": "TAMBAH USER",
        "btn_delete_selected": "HAPUS TERPILIH",
        "lbl_unit_schedule": "Jadwal",
        "lbl_tpl_auto": "Template: Auto",
        "lbl_tpl_manual": "Template: Manual",
        "msg_notify_start": "Proses dimulai.",
        "msg_notify_fail": "Terjadi kesalahan",
        "msg_confirm_notify": "Kirim notifikasi WhatsApp ke semua klien di jadwal hari ini?\nMode: ",
        "lbl_mode_auto": "Sesuai Jadwal (H-3/Isolir)",
        "lbl_mode_manual": "Pesan Tagihan (Manual)",
        "conf_del_qris": "Hapus QRIS?",
        "msg_qris_deleted": "QRIS berhasil dihapus",
        "msg_wa_pairing": "Pairing... (Scan QR)",
        "msg_wa_connected": "WhatsApp Terhubung!",
        "msg_wa_disconnected": "WhatsApp Terputus",
        "err_no_phone": "Nomor WhatsApp tidak ditemukan untuk {name}. Silakan lengkapi di data client.",
        "msg_no_arrears_rem": "Client {name} tidak memiliki tunggakan (mempunyai Saldo). Tidak perlu mengirim pengingat.",
        "conf_send_bill": "Kirim tagihan Rp {bill} ke {name}?",
        "lbl_reason_h3": "Tagihan H-3 (Reminder)",
        "lbl_reason_eom": "Jatuh Tempo / Akhir Bulan",
        "lbl_reason_pre_isolir": "Peringatan Isolir",
        "lbl_reason_isolir": "Isolir Otomatis",
        "lbl_reason_manual": "Isolir Manual",
        "conf_mass_wa_billing": "Kirim pengingat WhatsApp tagihan (Akhir Bulan) ke SEMUA klien yang belum bayar? (Tanpa Isolir)",
        "lbl_balance_badge": "(SALDO)",
        "btn_save_change": "SIMPAN PERUBAHAN",
        "btn_send_now": "KIRIM SEKARANG",
        "lbl_wa_log": "Log WhatsApp",
        "btn_wa_clear_log": "HAPUS LOG",
        "lbl_wa_pair_title": "Atau Tautkan via Nomor HP",
        "ph_wa_pair": "Contoh: 628123456789",
        "btn_wa_pair": "Dapatkan Kode",
        "msg_wa_log_waiting": "Menunggu data log...",
        "lbl_edit_arrears": "Edit Tunggakan",
        "th_wa": "WhatsApp",
        "msg_client_required": "Nama client harus diisi!",
        "btn_edit": "Edit",
        "btn_delete": "Hapus",
        "card_bill_conf": "Konfigurasi Penagihan",
        "lbl_billing_system": "Sistem Penagihan",
        "opt_billing_monthly": "Bulanan (Sama Semua)",
        "opt_billing_cyclic": "30 Hari (Personal)",
        "opt_billing_fixed": "Fixed Day (Hybrid)",
        "hint_billing_system": "Pilih metode perhitungan jatuh tempo.",
        "lbl_fixed_day": "Target Jatuh Tempo (Tgl)",
        "lbl_due_date": "Tanggal Jatuh Tempo",
        "hint_due_date": "Hari tagihan muncul setiap bulan. Jika tanggal tidak tersedia di bulan tersebut (misal tgl 30 Feb), akan otomatis menggunakan hari terakhir bulan itu.",
        "lbl_grace": "Masa Tenggang (Grace Period)",
        "hint_grace": "Tambahan hari sebelum isolir (0 = Langsung).",
        "lbl_isolir_prof": "Profil Isolir MikroTik",
        "hint_isolir_prof": "Nama Profil/Address-list di router. Sistem akan otomatis membuatnya jika belum ada.",
        "lbl_enable_isolir": "Aktifkan Auto Isolir",
        "hint_enable_isolir": "Jika ON, sistem otomatis memutus user yang nunggak.",
        "lbl_wa_notif": "Kirim Notifikasi WA",
        "hint_wa_notif": "Kirim pengingat otomatis ke WhatsApp client.",
        "opt_1h": "Tiap 1 Jam",
        "opt_3h": "Tiap 3 Jam",
        "opt_6h": "Tiap 6 Jam",
        "opt_12h": "Tiap 12 Jam",
        "opt_24h": "Tiap 24 Jam",
        "lbl_wa_rem_end_month": "Reminder Akhir Bulan",
        "hint_wa_rem_end_month": "Kirim notifikasi di akhir bulan untuk semua.",
        "lbl_wa_rem_pre_isolir": "Peringatan H-",
        "lbl_days": "Hari",
        "hint_wa_rem_pre_isolir": "Kirim peringatan X hari sebelum isolir.",
        "lbl_wa_notif_time": "Jam Kirim Notif",
        "hint_wa_notif_time": "Waktu sistem mengirim broadcast.",
        "msg_server_err": "Kesalahan Server",

        // HOTSPOT (ID)
        "hs_theme": "Tema Voucher",
        "hs_theme_modern": "Gelap Modern (Biru)",
        "hs_theme_minimal": "Minimalist (Hemat Tinta)",
        "hs_theme_color": "Berwarna (Cerah)",
        "hs_gen_mode": "Mode Voucher",
        "hs_gen_mode_up": "User & Password Sama",
        "hs_gen_mode_vc": "User & Password Beda",
        "hs_char_type": "Karakter",
        "hs_char_num": "Angka",
        "hs_char_abc": "Huruf Kecil",
        "hs_char_ABC": "Huruf Kapital",
        "hs_char_mix": "Campuran (abc + 123)",
        "hs_char_MIX": "Campuran (Abc + 123)",
        "hs_char_len": "Panjang",
        "hs_server_prof": "Server Hotspot",
        "hs_dns_detected": "URL Login:",
        "hs_login_url": "URL Halaman Login",
        "hs_login_url_ph": "Isi manual jika auto-detect gagal...",
        "hs_btn_print": "CETAK VOUCHER",
        "hs_btn_print_result": "CETAK HASIL GENERATE",
        "hs_generated_title": "Hasil Generate Voucher",
        "hs_limit_uptime": "Durasi (Time Limit)",
        "hs_limit_data": "Kuota (Data Limit)",
        "hs_comment": "Komentar / Batch",
        "hs_prefix": "Kode Prefix",
        "hs_qty": "Jumlah",
        "hs_profile": "User Profile",
        "hs_server": "Server Hotspot",
        "hs_u_list": "DAFTAR USER",
        "hs_u_gen": "GENERATOR",
        "hs_u_act": "SESI AKTIF",
        "hs_u_prof": "PROFIL",
        "hs_desc_gen": "Hasilkan banyak voucher hotspot sekaligus dengan konfigurasi kustom.",
        "hs_desc_list": "Lihat, cetak, atau hapus daftar voucher yang sudah tersimpan di router.",
        "hs_desc_act": "Monitoring pengguna yang sedang terhubung dan menggunakan internet.",
        "hs_desc_prof": "Atur profil kecepatan dan masa aktif untuk paket voucher hotspot.",
        "hs_copy_succ": "Username disalin!",
        "hs_print_confirm": "Cetak voucher terpilih?",
        "hs_btn_generate": "GENERATE VOUCHER",
        "hs_confirm_gen": "Generate {qty} voucher?",
        "hs_confirm_del": "Hapus {count} voucher terpilih?",
        "hs_msg_success": "Berhasil membuat {count} voucher!",
        "hs_msg_del_success": "Berhasil menghapus {count} voucher!",
        "hs_err_req": "Profil dan Komentar wajib diisi!",
        "hs_ph_time": "Contoh: 3h, 1d",
        "hs_ph_data": "cth: 1G, 500M",
        "hs_ph_prefix": "Contoh: VIP-",
        "hs_ph_comment": "Wajib (cth: Batch-01)",
        "hs_ph_login_url": "Isi manual jika auto-detect gagal...",
        "ph_filter_batch": "Filter Batch (Comment)...",
        "hs_u_act": "Sesi Aktif",
        "hs_u_prof": "Profil",
        "hs_u_proflist": "List Profil",
        "hs_u_profadd": "Tambah Profil",
        "hs_create_prof": "Buat Profil Baru",
        "hs_prof_name": "Nama Profil",
        "hs_rate_limit": "Rate Limit (Rx/Tx)",
        "hs_shared_users": "Shared Users",
        "hs_session_timeout": "Session Timeout",
        "hs_btn_create_prof": "BUAT PROFIL",
        "hs_existing_profs": "Profil Terdaftar",
        "th_rate_limit": "Rate Limit",
        "th_shared": "Shared",
        "hsp_ph_name": "Wajib (cth: 5Mbps)",
        "hsp_ph_rate": "cth: 5M/5M",
        "hsp_ph_timeout": "cth: 1d",
        "msg_sel_vouchers": "Pilih voucher!",
        "msg_wa_scan_qr": "Scan QR untuk menghubungkan WhatsApp:",
        "msg_wa_connected": "WhatsApp Terhubung!",
        "msg_wa_pairing": "Menunggu Scan QR...",
        "msg_wa_offline": "WhatsApp Terputus",
        "hs_confirm_kick": "Putuskan sesi user ini?",
        "alert_name_required": "Nama wajib diisi!",
        "msg_vouchers_empty": "Belum ada voucher untuk dicetak.",
        "opt_select_server": "-- Pilih Server --",
        "lbl_main_server": "Server Utama",
        "lbl_target_server": "Target Server:",
        "lbl_lang_prefix": "BAHASA: ",
        "th_bytes": "Data (In/Out)",
        "btn_add_profile": "BUAT PROFIL",
        "lbl_main": "(PUSAT)",
        "lbl_branch": "(CABANG)",

        "btn_add_arrears": "Tambah Tunggakan",
        "lbl_add_arrears": "Tambah Tunggakan Manual",
        "lbl_edit_arrears": "Edit Tunggakan",
        "msg_loading_log": "Memuat log...",
        "msg_loading_logs": "Memuat log...",
        "msg_loading_schedule": "Memuat jadwal...",
        "th_bill": "Tagihan",
        "th_months": "Bulan",
        "th_date": "Tanggal",
        "lbl_schedule_today": "Jadwal Notifikasi Hari Ini",
        "lbl_unit_client": "Klien",
        "lbl_unit_schedule": "Jadwal",
        "lbl_status_sent": "Terkirim",
        "lbl_status_isolated": "Terisolir",
        "lbl_status_waiting": "Menunggu",
        "lbl_status_done": "Selesai / Lunas",
        "lbl_reason_h3": "H-3 Jatuh Tempo",
        "lbl_reason_eom": "Akhir Bulan",
        "lbl_reason_pre_isolir": "H-X Jatuh Tempo",
        "lbl_reason_isolir": "Isolir",
        "msg_all_pd": "✅ Semua lunas!",
        "msg_confirm_test_isolir": "Jalankan pengecekan billing manual untuk ",
        "msg_auto_arrears_err": "Tunggakan otomatis tidak bisa dihapus manual. Silakan proses pembayaran client.",
        "fin_desc_page": "Catat dan pantau arus kas masuk/keluar operasional.",
        "opt_loading": "Memuat...",
        "fin_txt_no_data": "Belum ada data transaksi.",
        "fin_report_btn": "Laporan",
        "fin_csv_header": "TANGGAL,TIPE,KATEGORI,CATATAN,NOMINAL,USER",
        "fin_csv_report_header": "NO,TANGGAL,DESKRIPSI,MASUK,KELUAR,SALDO",
        "lbl_total": "TOTAL",
        "sb_balance": "Saldo",
        "ph_item_manual": "Contoh: Switch Hub 8 Port",
        "ph_item_stock": "Contoh: Kabel Dropcore 1 Roll",
        "msg_sync_data": "⏳ Sinkronisasi data...",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "months": ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
        "cat_wifi": "Pembayaran WiFi",
        "cat_invest": "Investasi",
        "cat_grant": "Hibah / Lainnya",
        "cat_others": "Lain-lain",
        "cat_tools": "Alat & Bahan",
        "cat_maint": "Pemeliharaan",
        "cat_ops": "Operasional",
        "cat_salary": "Gaji / Fee",
        "cat_carryover": "Saldo Pindahan",
        "lbl_balance_badge": "SALDO",
        "lbl_arrears_warning": "Tunggakan Terdeteksi",
        "lbl_arrears_suffix": "Bulan",
        "lbl_paid_until_short": "Lunas s/d",
        "lbl_active_success": "Status Aktif",
        "fin_alert_nominal": "Nominal harus lebih dari 0",
        "fin_err_save": "Gagal menyimpan:",
        "fin_confirm_del": "Hapus transaksi ini?",
        "fin_export_empty": "Tidak ada data untuk diekspor",
        "conf_del_item": "Hapus barang ini dari daftar terpasang?",
        "conf_del_stock": "Hapus barang ini dari gudang?",
        "msg_set_not_loaded": "Pengaturan belum dimuat.",
        "alert_save_failed": "Simpan Gagal",
        "msg_saved_ok": "Berhasil disimpan",
        "lbl_auto": "OTOMATIS",
        "btn_reset_auto": "Reset ke Otomatis",
        "msg_saving": "Menyimpan...",
        "alert_saved": "Pengaturan Disimpan",
        "msg_server_err": "Server Error atau Koneksi Terputus",
        "msg_all_clients": "semua klien",
        "conf_mass_wa_billing": "Jalankan notifikasi WhatsApp massal untuk seluruh klien yang menunggak?",
        "msg_processing": "Sedang diproses...",
        "err_no_phone": "Klien {name} tidak memiliki nomor WA.",
        "msg_no_arrears_rem": "Klien {name} tidak memiliki tunggakan.",
        "conf_send_bill": "Kirim pengingat tagihan Rp {bill} ke {name}?",
        "lbl_hal": "Halaman",
        "fin_in_pill": "MASUK",
        "fin_out_pill": "KELUAR",
        "fin_no_data": "Tidak ada data.",
        "lbl_today": "Hari Ini",
        "hs_no_active": "Tidak ada sesi aktif.",
        "hs_no_profiles": "Tidak ada profil hotspot.",
        "hs_prof_btn_create": "BUAT PROFIL",
        "hs_prof_btn_save": "SIMPAN PERUBAHAN",
        "hs_prof_title_edit": "Edit Profil Hotspot",
        "hs_prof_tab_gen": "Umum",
        "hs_prof_tab_queue": "Antrean",
        "hs_u_title_add": "Tambah User Hotspot",
        "hs_u_title_edit": "Edit User Hotspot",
        "hs_addr_pool": "Address Pool",
        "hs_idle_timeout": "Idle Timeout",
        "hs_keepalive_timeout": "Keepalive Timeout",
        "hs_status_autorefresh": "Status Autorefresh",
        "hs_addr_list": "Address List",
        "hs_mac_cookie_timeout": "MAC Cookie Timeout",
        "hs_parent_queue": "Parent Queue",
        "hs_queue_type": "Tipe Antrean",
        "hs_insert_before": "Sisipkan Sebelum",
        "hs_first": "Pertama",
        "hs_last": "Terakhir",
        "msg_notify_start": "Proses notifikasi dimulai.",
        "msg_notify_fail": "Gagal memulai notifikasi.",
        "msg_no_logs": "Belum ada log.",
        "msg_loading_logs": "Memuat log...",
        "lbl_mode_auto": "Otomatis",
        "lbl_mode_manual": "Manual",
        "msg_confirm_notify": "Kirim notifikasi untuk jadwal hari ini? Mode: ",
        "alert_conn_failed": "Gagal menghubungi server.",
        "lbl_tpl_auto": "Template: Otomatis",
        "lbl_tpl_manual": "Template: Manual",

        // AUTOMATION KEYS (ID)
        "sb_auto": "AUTOMASI",
        "tab_backup": "AUTO BACKUP",
        "tab_tele": "TELEGRAM BOT",
        "lbl_auto_backup": "Aktifkan Auto Backup",
        "lbl_backup_time": "Waktu Backup (WIB)",
        "lbl_keep_days": "Simpan Backup (Hari)",
        "lbl_inc_files": "Pilih File Backup",
        "lbl_bot_token": "Bot Token",
        "lbl_chat_id": "Chat ID",
        "btn_test_bot": "TEST KONEKSI",
        "lbl_notif_trigger": "Pemicu Notifikasi",
        "chk_offline": "Client OFFLINE",
        "chk_online": "Client ONLINE",
        "chk_daily": "Laporan Harian",
        "chk_backup": "Laporan Backup",
        "chk_startup": "System Startup",
        "lbl_trig_desc": "Pilih kejadian yang akan dikirim ke Telegram.",
        "msg_test_sent": "Pesan Test Terkirim! Cek Telegram Anda.",
        "alert_bk_trig": "Backup berjalan di background",
        "btn_bk_now": "BACKUP SEKARANG",
        "lbl_target_server": "Target Server:",
        "th_username": "Username",
        "th_password": "Password",
        "th_profile": "Profile",
        "th_limit": "Limit",
        "hs_no_users": "Belum ada user hotspot.",
        "hs_no_profiles": "Profil tidak ditemukan.",
        "hs_confirm_kick": "Kick user aktif ini?",
        "tab_upd": "UPDATE & RESTORE",
        "lbl_on": "AKTIF",
        "lbl_off": "MATI",
        "tab_bk": "BACKUP",
        "tab_tele": "TELEGRAM",
        "lbl_inc_files": "File yang Disertakan:",
        "lbl_inc_db": "Database & Config (Topology, Settings, Finance, Config, License)",
        "lbl_inc_web": "Interface Web (Templates HTML & Bahasa/Lang Dict)",
        "hint_bk_safe": "Backup termasuk file config.json, settings.json, finance.json dan license.key (Full Data Aman).",
        "lbl_bk_hist": "Riwayat Backup Server",
        "btn_refresh_bk": "Refresh",
        "hint_tg_desc": "Bot ini mengirim notifikasi saat status client berubah atau backup selesai.",
        "lbl_tg_enable": "Aktifkan Telegram Bot",
        "lbl_tg_token": "Bot Token",
        "lbl_tg_chatid": "Chat ID",
        "lbl_tg_trig": "Pemicu Notifikasi",
        "tab_tg_assist": "TELEGRAM ASSISTANT",
        "lbl_tg_assist_enabled": "Aktifkan Bot Telegram Assist",
        "lbl_tg_assist_bots": "Daftar Bot & Chat ID (token:chatid)",
        "hint_tg_assist_format": "Masukkan bot_token:chat_id per baris (unlimited). Contoh: 7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:377554040",
        "lbl_enable_cek": "Aktifkan Command /cek",
        "lbl_enable_status": "Aktifkan Command /status",
        "lbl_enable_bayar": "Aktifkan Command /bayar",
        "lbl_tg_assist_desc": "Telegram Assistant adalah bot interaktif dua arah. Anda/staf dapat mengirim chat perintah ke Bot Telegram (seperti /cek, /status, atau /bayar) untuk mengelola NMS secara jarak jauh.",
        "lbl_tga_guide_title": "Panduan Cepat Telegram Assistant",
        "lbl_tga_guide_intro": "Fitur ini mempermudah admin dan staf lapangan memantau serta mengecek data pelanggan NMS langsung dari aplikasi Telegram.",
        "lbl_tga_multi_acc_title": "Dukungan Banyak Petugas (Multi-Staff)",
        "lbl_tga_multi_acc_desc": "Satu bot Telegram dapat diakses oleh beberapa staf (Teknisi, Admin Billing, dll). Cukup daftarkan token bot yang sama namun dengan Chat ID Telegram yang berbeda per baris.",
        "lbl_tga_format_title": "Format Input Pengaturan",
        "lbl_tga_format_desc": "Masukkan data dengan format <code>token_bot:chat_id_staf</code> per baris.",
        "lbl_tga_example_title": "Contoh Format (1 Bot digunakan 3 Staf):",
        "lbl_tga_example_desc": "<code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628111222</code> (Staf 1)<br><code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628333444</code> (Staf 2)<br><code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628555666</code> (Staf 3)",
        "lbl_tga_warn_title": "💡 Tips Keamanan & Kecepatan Respon",
        "lbl_tga_warn_desc": "Gunakan <b>Bot Telegram baru</b> yang dibuat khusus untuk asisten ini. Hindari memakai token bot yang sama dengan bot notifikasi (On/Off) atau backup agar respon bot tetap instan dan tidak bentrok.",
        "lbl_tga_activate_title": "Cara Menjalankan",
        "lbl_tga_activate_desc": "1. Simpan pengaturan.<br>2. Cari username bot Anda di Telegram.<br>3. Kirim perintah <code>/start</code> untuk memulai.",
        "lbl_opt_ind": "Indonesia",
        "lbl_opt_eng": "English (US)",
        "msg_cloud_connecting": "Menghubungkan ke Cloud...",
        "msg_fail": "Gagal",
        "msg_cloud_fail": "Gagal download dari Cloud",
        "msg_backend_fail": "Gagal koneksi backend",
        "msg_pro_locked_menu": "🔒 FITUR PRO\n\nMenu ini hanya tersedia di versi Berlisensi.\nSilahkan upgrade lisensi Anda.",
        "msg_wait": "Mohon tunggu...",
        "conf_irrevocable": "Tindakan ini tidak dapat dibatalkan.",
        "conf_del_data": "Data yang dihapus tidak dapat dikembalikan.",
        "conf_system_restart": "Sistem akan berhenti sejenak untuk memulai ulang.",
        "tt_online_olt": "OLT (AKTIF)",
        "tt_ping_local": "Ping Lokal",
        "ph_amount": "Contoh: 25000",
        "ph_test_user": "Username PPPoE",
        "ph_date_range": "Tanggal (1-31)",
        "ph_zero": "Contoh: 0",
        "ph_isolir_prof": "Contoh: ISOLIR",
        "ph_web_title": "MAPS MONITORING WIFI",
        "ph_svc_name": "monitoring-wifi.service",
        "ph_port": "5002",
        "ph_bot_token": "123456:ABC...",
        "ph_chat_id": "-100123456789",
        "msg_no_data": "Tidak ada data.",
        "msg_wa_check": "Mengecek status...",
        "lbl_wa_status_offline": "TERPUTUS",
        "lbl_tpl_vars": "Gunakan {name}, {amount}, {month}, {expired}, {x} untuk variabel dinamis.",
        "hs_ip_address": "Alamat IP",
        "th_user": "User",
        "msg_confirm_kick": "Peringatan: User akan diputus koneksinya (KICK). User akan otomatis reconnect jika router disetting auto-dial. Lanjutkan?",
        "msg_confirm_prof": "Ubah profil user {user} menjadi {prof}?",
        "msg_failed": "Gagal",
        "lbl_input_core": "Masuk ke Core (Input):",
        "lbl_parent_src": "Sumber Induk",
        "lbl_from_port_short": "Dari Port",
        "ph_port_man": "Ketik Port Manual (Cth: LAN 1)...",
        "opt_sel_core": "-- Pilih Core --",
        "msg_sel_parent_first": "-- Pilih Induk Dulu --",
        "msg_loading": "Memuat...",
        "opt_change_prof": "-- Ganti Profil --",
        "map_btn_dash": "Kembali ke Dashboard",
        "map_title_logout": "Logout",
        "map_title_outage": "Riwayat Gangguan",
        "map_title_backup": "Backup ke Telegram",
        "map_title_autoref": "Auto Refresh",
        "map_title_anim": "Animasi Kabel",
        "map_type_dark": "GELAP",
        "map_type_hybrid": "HYBRID",
        "map_type_clean": "CLEAN",
        "map_lbl_client_list": "DAFTAR CLIENT",
        "map_lbl_on": "AKTIF:",
        "map_lbl_off": "OFFLINE:",
        "map_lbl_isolir": "ISOLIR:",
        "map_ph_search": "Cari Nama/IP...",
        "map_title_show_offline": "Tampilkan Offline Saja",
        "lbl_db_tools": "ALAT DATABASE",
        "btn_backup_top": "Backup Topologi",
        "btn_restore_top": "Restore Topologi",
        "map_title_label": "Label",
        "fab_add_mk": "Tambah MikroTik (Cabang)",
        "fab_add_olt": "Tambah OLT (Active)",
        "fab_add_odp": "Tambah ODP",
        "fab_add_client": "Tambah Client",
        "modal_edit_title": "Edit Perangkat",
        "lbl_choose_mk": "PILIH MIKROTIK PENGELOLA",
        "lbl_mk_login_conf": "Konfigurasi Login MikroTik",
        "lbl_client_type": "JENIS KLIEN (KONEKSI)",
        "lbl_dev_name": "Nama Perangkat",
        "lbl_coords": "Koordinat (Lat, Lng)",
        "lbl_pos_status": "Status Posisi",
        "lbl_srv_lan": "Jumlah Port LAN",
        "lbl_srv_sfp": "Jumlah Port SFP",
        "lbl_man_wan": "MANUAL WAN INTERFACE",
        "lbl_ext_ping": "TARGET PING EXTERNAL",
        "lbl_det_status": "Status Deteksi Saat Ini",
        "btn_edit_path": "EDIT JALUR (GESER/TARIK)",
        "lbl_odp_type": "Tipe ODP",
        "lbl_lan_count": "Jumlah Port LAN",
        "lbl_fo_a": "Jml FO A",
        "lbl_fo_b": "Jml FO B",
        "lbl_tech": "Teknologi",
        "lbl_pon_out": "Jumlah Port PON (Output)",
        "lbl_uplink_in": "Jumlah Port Uplink (Input)",
        "lbl_slot_out": "Jumlah Output Slot (Drop)",
        "lbl_dist_mode": "Mode Distribusi:",
        "lbl_core_cap": "Kapasitas Core",
        "lbl_uplink_src": "KONEKSI SUMBER (UPLINK)",
        "lbl_parent": "Induk (Parent)",
        "lbl_from_port": "Dari Port Parent (Output)",
        "lbl_cable_color": "Warna Kabel / Tube",
        "lbl_input_port": "Masuk ke Port ODP (Input)",
        "chk_poe_in": "Input Bawa PoE?",
        "lbl_ip_man": "IP Address (Manual)",
        "lbl_mon_mode": "METODE MONITORING",
        "lbl_pppoe_user": "PILIH USER PPPoE",
        "lbl_client_detail": "RINCIAN KLIEN (AUTO)",
        "lbl_prof_now": "PROFIL SAAT INI",
        "lbl_change_prof": "GANTI PROFIL",
        "btn_kick": "KICK USER",
        "chk_poe_src": "Client ini Sumber POE?",
        "lbl_wifi_data": "Data Login & WiFi",
        "btn_chat_wa": "CHAT WHATSAPP",
        "btn_remote": "REMOTE ROUTER",
        "lbl_photo_loc": "FOTO LOKASI / TIANG ODP",
        "btn_take_photo": "AMBIL / UPLOAD FOTO",
        "btn_del_dev": "HAPUS PERANGKAT",
        "modal_log_title": "HISTORY LOG",
        "lbl_cable_len": "PANJANG KABEL:",
        "btn_reset_straight": "RESET LURUS",
        "btn_cancel_draw": "BATAL",
        "btn_save_path": "SIMPAN JALUR",
        "opt_select_server": "-- Pilih Server --",
        "lbl_main_server": "SERVER PUSAT",
        "opt_sel_user": "-- Pilih User --",
        "ph_sel_user": "-- Pilih/Ketik User --",
        "msg_failed_save": "Gagal simpan",
        "msg_sec_upd_restart": "Keamanan diperbarui. Perlu restart.",
        "msg_failed_upd": "Gagal update",
        "msg_sel_file_first": "Pilih file dulu",
        "msg_upload_ok": "Upload Berhasil",
        "msg_error_upload": "Error saat upload",
        "msg_attach_file_first": "Hubungkan file dulu sebelum klik upload.",
        "msg_confirm_restore_smart": "File {name} terdeteksi.\n\nKlik OK untuk melakukan RESTORE DATABASE (Timpa data lama).\nKlik BATAL untuk UPDATE FILE BIASA (Hanya mengganti file saja).",
        "msg_confirm_update_smart": "Lanjutkan Update file {name} secara biasa?",
        "msg_confirm_upload_file": "Lanjutkan Update / Unggah file {name}?",
        "msg_conn_fail": "Koneksi Gagal/Timeout",
        "conf_del_logo": "Hapus logo?",
        "msg_logo_deleted": "Logo dihapus",
        "conf_reset_logs": "Reset logs?",
        "msg_logs_cleared": "Log dibersihkan",
        "msg_sending": "Mengirim...",
        "msg_backup_sent": "Backup terkirim!",
        "msg_creating_zip": "Menciptakan Zip...",
        "msg_backup_downloading": "Backup Dibuat & Mengunduh...",
        "msg_done": "Selesai",
        "msg_req_error": "Gagal Request",
        "msg_tele_empty": "Token/Chat ID Kosong",
        "lbl_active_tele": "Aktifkan Telegram Bot",
        "msg_backend_fail": "Gagal koneksi backend",
        "msg_load_log_fail": "Gagal memuat log.",
        "hint_manual_detect": "*Isi angka manual jika deteksi salah",
        "hint_multi_wan": "*Pisahkan koma jika Multi-WAN. Kosongkan untuk Auto.",
        "hint_ping_target": "*IP Public untuk cek koneksi internet.",
        "hint_auto_label": "*Label auto: FO A-1, B-1...",
        "hint_ctrl_multi": "*Tahan Ctrl untuk pilih banyak",
        "ph_search_name_ip": "Cari Nama / IP / Koordinat...",
        "ph_eg_wan": "Contoh: ether1,ether2,vlan10",
        "ph_eg_ip": "Contoh: 8.8.8.8",
        "lbl_dist_mode": "Distribution Mode:",
        "hint_multi_uplink": "Pilih port induk (Uplink) lebih dari satu (Multi-Select).",
        "confirm_logout": "Keluar dari sistem?",
        "msg_connecting_cloud": "Menghubungkan ke Cloud...",
        "msg_update_success": "Update Berhasil",
        "lbl_main": "(Utama)",
        "msg_vouchers_empty": "Belum ada data!",
        "hs_msg_creating": "⏳ Generating...",
        "hs_msg_success": "✅ Sukses Generate",
        "hs_msg_vouchers": "Voucher!",
        "hs_confirm_gen": "Generate voucher terpilih?",
        "hs_confirm_del": "Hapus {count} voucher terpilih?",
        "hs_confirm_del_user": "Hapus voucher {name}?",
        "hs_confirm_del_prof": "Hapus profil {name}?",
        "hs_msg_del_success": "✅ {count} voucher berhasil dihapus.",
        "hs_msg_del_success": "✅ {count} voucher berhasil dihapus.",
        "msg_sel_vouchers": "⚠️ Pilih voucher terlebih dahulu!",
        "alert_pro_locked": "🔒 FITUR PRO\n\nUpgrade ke versi Berlisensi untuk akses fitur ini.",
        "pg_lic_title": "Aktivasi License - PEYCELL NMS",
        "lbl_lic_active": "License Aktif",
        "msg_lic_registered": "Aplikasi ini sudah terdaftar resmi.",
        "lbl_lic_type": "Tipe Lisensi",
        "lbl_lic_owner": "Pemilik Lisensi",
        "lbl_machine_id": "Machine ID",
        "btn_enter_dash": "MASUK KE DASHBOARD",
        "lbl_lic_activation": "Aktivasi License",
        "msg_lic_locked": "Aplikasi ini terkunci dan memerlukan lisensi aktif.",
        "lbl_your_mid": "Machine ID Anda",
        "msg_copy_mid": "Salin Machine ID di atas, lalu kirim ke Administrator untuk mendapatkan Lisensi:",
        "lbl_input_lic": "Masukkan License Key",
        "ph_lic_key": "Tempel kode lisensi di sini...",
        "footer_nms": "PEYCELL NETWORK MANAGEMENT SYSTEM",
        "err_empty_lic": "Masukkan kode lisensi!",
        "msg_processing": "Memproses...",
        "msg_lic_success": "Lisensi Berhasil Diaktifkan!",
        "err_lic_fail": "Lisensi Tidak Valid!",
        "err_conn": "Gagal koneksi: ",

        // Settings Page Title
        "set_page_title": "PENGATURAN APLIKASI",
        "login_title": "MAPS MONITORING WIFI",
        "ph_pass": "Password...",
        "btn_login": "MASUK",
        "err_login": "Password Salah!",
        "conf_logout": "Keluar dari system?",
        "conf_isolate": "Isolir client ini? Internet akan dinonaktifkan.",
        "msg_isolate_success": "Client berhasil diisolir!",
        "err_session": "Sesi berakhir atau tidak sah",
        "err_bypass": "Gagal update bypass: ",
        "err_wa_empty": "Nomor WA belum diisi.",
        "csv_client_name": "Nama Client",
        "csv_id": "ID Pelanggan",
        "csv_packet": "Paket",
        "csv_ip": "IP",
        "csv_status": "Status",
        "csv_parent": "Induk",
        "csv_coords": "Koordinat",
        "csv_wa": "No WA",
        "csv_paid_until": "Masa Aktif",
        "lbl_var_store_name_desc": "Nama Toko / Usaha",
        "lbl_var_header_desc": "Teks Header Cetak",
        "lbl_var_footer_desc": "Teks Footer Cetak",
        "lbl_var_date_desc": "Tanggal Transaksi",

        "lbl_print_info_title": "PANDUAN METODE CETAK",
        "lbl_wa_vars_title": "PANDUAN VARIABEL PESAN",
        "lbl_online_pill": "ONLINE",
        "lbl_isolir_pill": "ISOLIR",
        "lbl_offline_pill": "OFFLINE",
        "msg_pay_success": "Pembayaran Berhasil! Masa aktif diperpanjang.",
        "msg_pay_fail": "Gagal simpan transaksi!",
        "msg_auto_activate": "Client otomatis diaktifkan kembali!",
        "err_mk_sync": "Gagal mengambil data Mikrotik",
        "err_invalid_nominal": "Nominal tidak valid!",
        "msg_sync_done": "Sync Selesai! {count} data diperbarui.",
        "err_sync": "Gagal Sync: ",
        "tt_type": "Tipe",
        "tt_cable": "Kabel",
        "tt_cap": "Kapasitas",
        "tt_no_packet": "Belum Ada Paket",
        "tt_waiting": "Wait...",
        "tt_conn_arp": "Terhubung (ARP)",
        "tt_conn_netwatch": "Terhubung (Netwatch)",
        "tt_connected": "Terhubung",
        "tt_loading_traffic": "Memuat Traffic...",
        "tt_ping_local": "Ping Lokal",
        "msg_no_data": "Tidak ada data.",
        "msg_sel_prof": "Pilih profil dulu",
        "msg_sel_user": "Pilih User PPPoE dulu!",
        "msg_invalid_file": "File tidak valid! Struktur data salah.",
        "ph_search_name_ip": "Cari Nama / IP / Koordinat...",
        "opt_sel_core": "-- Pilih Core --",
        "opt_sel_parent": "-- Pilih Induk --",
        "msg_no_parent": "-- TIDAK ADA INDUK YANG SESUAI --",
        "msg_sel_parent_first": "-- Pilih Induk Dulu --",
        "msg_ctrl_multi": "*Tahan Ctrl untuk pilih banyak",
        "lbl_bypass_billing": "Gratis Selamanya (Bypass Billing)",
        "ph_client_name": "Ketik nama klien...",
        "ph_arrears_note": "Contoh: Sisa bulan lalu / Ganti kabel",
        "th_purpose": "Keperluan",
        "th_status": "Status",
        "lbl_schedule_today": "Jadwal Notifikasi Hari Ini",
        "msg_loading_schedule": "Memuat jadwal...",
        "lbl_tpl_auto": "Template: Auto",
        "lbl_tpl_manual": "Template: Manual",
        "lbl_unit_client": "Klien",
        "map_ph_search": "Cari Nama/IP...",
        "map_title_show_offline": "Tampilkan Offline Saja",
        "msg_prof_changed": "Profil berhasil diubah! Silakan tekan tombol KICK agar user reconnect dengan profil baru.",
        "alert_name_required": "NAMA PERANGKAT WAJIB DIISI!",
        "msg_success": "Sukses",
        "lbl_host": "Host / IP Address",
        "lbl_api_user": "Username API",
        "lbl_api_pass": "Password API",
        "lbl_api_port": "Port API (Default: 8728)",
        "lbl_pkt_man": "Nama Paket (Manual)",
        "lbl_multi_uplink": "Konfigurasi Multi-Uplink:",
        "lbl_ip_addr": "IP ADDRESS",
        "lbl_wa_num": "No. WhatsApp (Format: 628xxx)",
        "lbl_wifi_ssid": "WIFI SSID",
        "lbl_wifi_pass": "WIFI PASS",
        "lbl_rtr_user": "ROUTER USER",
        "lbl_rtr_pass": "ROUTER PASS",
        "ph_notes": "Tulis catatan (teknisi, lokasi kunci, dll)...",
        "opt_locked": "Locked (Terkunci)",
        "opt_unlocked": "Unlocked (Bisa Geser)",
        "hint_manual_num": "*Isi angka manual jika deteksi salah",
        "hint_multi_wan": "*Pisahkan koma jika Multi-WAN. Kosongkan untuk Auto.",
        "hint_ext_ping": "*IP Public untuk cek koneksi internet.",
        "opt_odp_htb": "HTB / Switch (Estafet/Converter)",
        "opt_odp_olt": "Passive Splitter (ODP Tiang)",
        "opt_odp_jb": "Joint Box / Distribusi (Multi-Core)",
        "opt_stat_ip": "IP STATIK (MANUAL)",
        "opt_pppoe": "PPPoE (MIKROTIK)",
        "lbl_rx": "RX",
        "lbl_tx": "TX",
        "lbl_cpu": "CPU",
        "lbl_ping": "PING",
        "lbl_uptime": "Uptime",
        "lbl_used": "Terpakai",
        "lbl_cap": "Kapasitas",
        "lbl_perc": "Persen",
        "msg_sync_data": "Menunggu sinkronisasi data...",
        "tab_pricing": "Master Harga",
        "tab_arrears": "Laporan Tunggakan",
        "tab_set": "Konfigurasi",
        "th_paket_name": "Nama Paket",
        "th_price": "Harga (Rp)",
        "th_name": "Nama Client",
        "th_paket": "Paket",
        "th_due_date": "Jatuh Tempo",
        "th_status": "Status",
        "th_action": "Aksi",
        "msg_no_price": "Belum ada data harga.",
        "fin_title_page": "LAPORAN KEUANGAN & KAS",
        "fin_income_label": "PEMASUKAN (BULAN INI)",
        "fin_expense_label": "PENGELUARAN (BULAN INI)",
        "fin_balance_label": "SALDO BERSIH",
        "fin_btn_filter": "FILTER",
        "fin_btn_reset": "RESET",
        "fin_btn_add_tx": "CATAT TRANSAKSI",
        "fin_btn_excel": "EXPORT CSV",
        "fin_th_date": "TANGGAL",
        "fin_th_type": "TIPE",
        "fin_th_category": "KATEGORI",
        "fin_th_notes": "KETERANGAN",
        "fin_th_amount": "NOMINAL",
        "fin_th_action": "AKSI",
        "fin_txt_loading": "Memuat data...",
        "fin_h_archive": "ARSIP LAPORAN BULANAN",
        "fin_txt_no_archive": "Belum ada riwayat laporan bulan lalu.",
        "modal_tx_title": "Catat Transaksi Baru",
        "lbl_tx_type": "Jenis Transaksi",
        "opt_income": "Pemasukan (+)",
        "opt_expense": "Pengeluaran (-)",
        "lbl_tx_client": "Nama Client (Auto Buka Isolir)",
        "hint_tx_client": "Otomatis buka isolir jika client dipilih. (Khusus Client PPPoE).",
        "lbl_tx_cat": "Kategori",
        "lbl_tx_amount": "Nominal (Rp)",
        "lbl_tx_note": "Catatan",
        "ph_date_range": "Tgl (1-31)",
        "btn_cancel": "BATAL",
        "btn_save": "SIMPAN",
        "fin_alert_nominal": "Nominal harus lebih dari 0",
        "fin_err_save": "Gagal menyimpan transaksi:",
        "fin_in_pill": "MASUK",
        "fin_out_pill": "KELUAR",
        "fin_report_btn": "Laporan",
        "fin_csv_header": "TANGGAL,TIPE,KATEGORI,CATATAN,NOMINAL,USER",
        "fin_confirm_del": "Hapus transaksi ini?",
        "fin_export_empty": "Tidak ada data untuk dieksport",
        // ABOUT PAGE
        "pg_about_title": "TENTANG SISTEM",
        "lbl_sys_info": "INFORMASI SISTEM",
        "lbl_version": "Versi Aplikasi",
        "lbl_release_date": "Tanggal Rilis",
        "lbl_copyright": "Hak Cipta",
        "lbl_dev_support": "Developer Support",
        "lbl_dev_web": "Website",
        "lbl_license_to": "Kontak",
        "lbl_system_desc": "Platform ini dikembangkan khusus untuk mempermudah monitoring jaringan RT/RW Net. Dilengkapi dengan fitur peta live, manajemen keuangan dan billing, dan notifikasi gangguan real-time.",
        "lbl_donate_title": "DUKUNGAN & DONASI",
        "lbl_donate_desc": "Scan QRIS di bawah ini untuk donasi pengembangan atau pembayaran lisensi resmi.",
        "msg_integrity_error": "PERINGATAN KRITIS: Komponen original skrip (QRIS/Lisensi) telah diubah atau dihapus. Mohon kembalikan source code original untuk melanjutkan.",
        "lbl_smart_upd": "Smart Upload (Update / Restore)",
        "hint_smart_upd": "Unggah file .zip, .js, .html, .json, .py, .ico. Sistem akan mendeteksi target otomatis.",
        "lbl_sys_ctrl": "Kontrol Sistem",
        "lbl_ota_cloud": "UPDATE DARI CLOUD",
        "hint_ota_cloud": "Klik tombol di bawah untuk memeriksa dan menginstal pembaruan sistem langsung dari server pusat (Cloud).",
        "msg_upd_success": "UPDATE BERHASIL!",
        "msg_upd_latest": "Sistem NMS Anda sudah versi terbaru",
        "msg_upd_restart": "Aplikasi sedang restart, silakan tunggu 5-10 detik.",
        "msg_upd_fail": "Update Gagal: ",
        "msg_restore_success": "DATABASE BERHASIL DI-RESTORE!",
        "warn_title": "PENTING:",
        "warn_p1": "Setelah berhasil update melalui cloud diwajibkan untuk klik tombol restart.",
        "warn_p2": "Jika mengunggah file database (.db/.json/.zip), data lama akan langsung ditimpa. Pastikan format file benar sebelum klik Upload.",
        "warn_p3": "Selalu lakukan backup data secara berkala atau sebelum melakukan perubahan besar pada sistem.",
        "warn_p4": "Silakan hubungi saya langsung jika terjadi kendala atau masalah setelah melakukan update.",
        "btn_bk_now": "BACKUP SEKARANG (DOWNLOAD)",
        "lbl_method_share_print": "Kirim ke App Printer (Share - Tanpa Watermark)",
        // LOGS (ID)
        "log_wa_start": "START: Mode={mode}",
        "log_wa_shutdown": "SHUTDOWN: Service dimatikan (Code: {code})",
        "log_wa_info_start": "INFO: Service berhasil dibangunkan (PID: {pid})",
        "log_wa_timeout": "[STATUS] Timeout: Tidak ada aktivitas pairing selama 3 menit. Mematikan service...",
        "log_wa_qr_scan": "[QR] Silakan scan QR Code yang muncul di terminal atau UI.",
        "log_wa_conn_fail": "[STATUS] Koneksi terputus. Kodenya: {code}",
        "log_wa_session_out": "[STATUS] Sesi dihentikan (Logged Out).",
        "log_wa_connected": "[STATUS] Terhubung ke WhatsApp!",
        "log_wa_processing": "[STATUS] Memproses {count} antrean pesan...",
        "log_wa_waiting": "[WAIT] Menunggu 30 detik sebelum pesan berikutnya...",
        "log_wa_queue_fail": "[ERROR] Gagal memproses file antrean: {msg}",
        "log_wa_all_done": "[STATUS] Semua tugas selesai. Mematikan service...",
        "log_wa_empty_req": "[ERROR] Nomor tujuan atau konten pesan kosong.",
        "log_wa_sending": "[SEND] Mengirim ke {target}...",
        "log_wa_success_img": "[SUCCESS] Gambar + Pesan terkirim ke {target}",
        "log_wa_success_txt": "[SUCCESS] Pesan teks terkirim ke {target}",
        "log_wa_failed": "[FAILED] Gagal kirim ke {target}: {msg}",
        "log_wa_node_missing": "ERROR: Node.js tidak ditemukan di server. Pastikan Node.js sudah terinstal.",
        "log_wa_nm_missing": "ERROR: Folder 'node_modules' tidak ada. Jalankan 'npm install' di folder app.",
        "log_wa_critical": "CRITICAL: Script berhenti mendadak ({code}). Error: {msg}",
        "log_wa_exception": "EXCEPTION: {msg}",
        "lbl_pass_admin": "Password Administrator",
        "lbl_pass_view": "Password Viewer",
        "ph_pass_new": "Password Baru...",
        "lbl_svc_name": "Nama Service (Systemd)",
        "lbl_port": "Port Aplikasi",
        "hint_svc": "*Default: monitoring-wifi.service",
        "hint_port": "*Default: 5002. Perlu restart agar berefek.",
        "warn_sec": "Peringatan: Jika mengganti Port atau Service, server akan restart otomatis.",
        "btn_upd_sec": "UPDATE KEAMANAN & SISTEM",
        "lbl_login_activity": "Riwayat Login",
        "hint_login_activity": "Proteksi brute-force aktif. IP diblokir otomatis setelah 5x gagal login.",
        "lbl_active_sessions": "sesi aktif sekarang",
        "lbl_blocked_ips": "IP yang Diblokir",
        "lbl_min_remaining": "menit tersisa",
        "th_login_time": "Waktu",
        "th_login_ip": "Alamat IP",
        "th_login_device": "Perangkat",
        "th_login_role": "Role",
        "th_login_status": "Status",
        "lbl_login_success": "Berhasil",
        "lbl_login_failed": "Gagal",
        "lbl_login_blocked": "Diblokir",
        "msg_no_login_log": "Belum ada riwayat login.",
        "btn_ota_drive": "CEK UPDATE CLOUD",
        "lbl_mig_title": "Migrasi Data (V2.9 -> V3.0)",
        "hint_mig_desc": "Gunakan alat ini jika Anda upgrade dari V2.9. Unggah file topology.json lama Anda untuk dikonversi otomatis ke database SQLite.",
        "btn_convert_now": "START MIGRASI",
        "btn_restart": "RESTART SYSTEM",
        "hint_restart": "*Gunakan jika sistem terasa lambat atau Anda mengubah script .py.",
        "err_wa_wake": "Gagal membangunkan service WhatsApp.",
        "lbl_curr_ver": "Versi Saat Ini",
        "lbl_new_ver": "Versi Terbaru",
        "leg_billing_off_hint": "Billing dimatikan (Tidak ditagih)",
        "leg_billing_on_hint": "Billing aktif (Dipantau sistem)",
        "leg_free_hint": "Gratis / Bebas Tagihan",
        "msg_bk_del_conf": "Hapus file backup {file}?",
        "msg_bk_empty": "Belum ada file backup.",
        "msg_bk_load_err": "Gagal memuat riwayat backup.",
        "msg_bk_manual_start": "Proses backup dimulai di background...",
        "msg_sel_mig_file": "Pilih file topology.json untuk migrasi.",
        "tab_db": "DATABASE",
        "wa_log_err": "Kesalahan Log WA",
        "lbl_search_note": "Cari Keterangan",
        "lbl_tx_date": "Tanggal Transaksi",

        // BROADCAST
        "bc_title": "WHATSAPP BROADCAST",
        "bc_subtitle": "Informasikan pemeliharaan jaringan, perbaikan teknis, atau info penting lainnya secara massal kepada klien.",
        "bc_msg_label": "Isi Pesan",
        "bc_ph_msg": "Tulis pesan Anda di sini...",
        "bc_target_label": "Target Penerima",
        "bc_mode_all": "Semua Klien",
        "bc_mode_odp": "Berdasarkan ODP",
        "bc_mode_type": "Berdasarkan Jenis",
        "bc_mode_unpaid": "Belum Bayar (Nunggak)",
        "bc_mode_custom": "Input Kustom (Manual)",
        "bc_sel_odp": "Pilih ODP (Multi-select)",
        "bc_sel_type": "Pilih Jenis Layanan",
        "bc_custom_name": "Nama (Opsional)",
        "bc_custom_wa": "Nomor WhatsApp (628...)",
        "bc_btn_send": "MULAI BROADCAST 🚀",
        "bc_btn_stop": "HENTIKAN ANTREAN 🛑",
        "bc_btn_retry": "ULANGI PESAN GAGAL 🔄",
        "bc_label_est": "Estimasi Target:",
        "bc_label_prog": "Progres Pengiriman:",
        "bc_label_status": "Status Status",
        "bc_th_no": "No",
        "bc_th_name": "Nama Klien",
        "bc_th_wa": "No. WA",
        "bc_th_status": "Status",
        "bc_th_action": "Aksi",
        "bc_warn_title": "PERINGATAN:",
        "bc_warn_reload": "Jangan di-reload atau tutup halaman ini selama proses pengiriman berlangsung agar tidak terputus.",
        "bc_warn_banned": "Melakukan broadcast ke banyak nomor sekaligus berisiko menyebabkan nomor WhatsApp Anda diblokir (banned) oleh sistem WhatsApp.",
        "bc_warn_not_resp": "Kami tidak bertanggung jawab atas pemblokiran nomor yang terjadi akibat penggunaan fitur ini.",
        "bc_warn_safety": "Gunakan dengan bijak, sistem mengirim pesan dengan jeda (delay) 30 detik untuk setiap nomor selanjutnya demi keamanan akun WhatsApp Anda.",
        "bc_confirm_del": "Hapus penerima dari daftar?",
        "bc_status_wait": "Menunggu",
        "bc_status_proc": "Proses...",
        "bc_status_sent": "Terkirim",
        "bc_status_fail": "Gagal",
        "bc_log_title": "LOG AKTIVITAS BROADCAST",
        "bc_excel_tpl": "UNDUH TEMPLATE EXCEL",
        "bc_excel_upload": "UPLOAD EXCEL",
        "bc_img_label": "Lampiran Gambar (Opsional)",
        "bc_var_hint": "Klik untuk menyisipkan variabel:",
        "bc_conf_send": "Anda yakin ingin memulai broadcast ke {count} target? Jeda waktu 30 detik per pesan akan diterapkan.",
        "bc_conf_stop": "Hentikan sisa antrean broadcast?",
        "bc_msg_stopped": "Broadcast dihentikan.",
        "bc_msg_finished": "Broadcast selesai!",
        "bc_msg_no_target": "Tidak ada target yang ditemukan.",
        "bc_img_hint": "JPG/PNG Maks 2MB",
        "bc_btn_add_custom": "+ TAMBAH KE DAFTAR",
        "bc_btn_clear_list": "Bersihkan Daftar",
        "bc_log_ready": "[READY] Menunggu perintah...",
        "bc_no_odp": "Tidak ada ODP ditemukan.",
        "bc_no_target_data": "Tidak ada data target.",
        "bc_img_max_size": "Ukuran gambar maksimal 2MB!",
        "bc_err_no_target": "Tidak ada target penerima!",
        "bc_err_no_msg": "Pesan tidak boleh kosong!",
        "bc_conf_title": "Konfirmasi Broadcast",
        "bc_conf_send_text": "Kirim pesan ke {count} target? Jeda 30 detik antar pesan akan diterapkan.",
        "bc_btn_cancel": "Batal",
        "bc_btn_confirm": "Ya, Mulai!",
        "bc_log_start": "[START] Mengirim ke {count} target...",
        "bc_err_start_fail": "Gagal memulai broadcast",
        "bc_err_conn": "Gagal koneksi ke server.",
        "bc_conf_stop_title": "Hentikan Broadcast?",
        "bc_conf_stop_text": "Sisa antrean akan dihapus.",
        "bc_log_stopped": "[STOPPED] Broadcast dihentikan oleh pengguna.",
        "bc_conf_clear": "Bersihkan seluruh daftar penerima dan reset sesi?",
        "bc_log_cleared": "[READY] Daftar dan sesi dikosongkan...",
        "bc_msg_cleared": "Daftar dan sesi telah dibersihkan",
        "bc_err_server": "Gagal menghubungi server",
        "bc_lbl_success": "Berhasil",
        "bc_lbl_failed": "Gagal",
        "bc_lbl_error": "Error",
        "bc_wa_status_connected": "WA: TERHUBUNG",
        "bc_wa_status_pairing": "WA: PAIRING...",
        "bc_wa_status_disconnected": "WA: TERPUTUS",
        "bc_wa_status_checking": "WA: MEMERIKSA...",
        "bc_wa_modal_title": "WhatsApp Gateway",
        "bc_wa_modal_checking": "Memeriksa status WhatsApp...",
        "bc_wa_modal_hint_connected": "WhatsApp Anda aktif dan siap mengirim pesan.",
        "bc_wa_modal_hint_pairing": "Buka WhatsApp di HP Anda > Perangkat Tertaut > Tautkan Perangkat, lalu scan QR code di atas.",
        "bc_wa_modal_hint_disconnected": "Klik tombol \"Hubungkan\" di bawah untuk mengaktifkan gateway WhatsApp.",
        "bc_wa_btn_connect": "Hubungkan",
        "bc_wa_btn_retry": "Kirim Ulang Gagal",
        "bc_wa_retry_confirm_title": "Kirim Ulang Gagal?",
        "bc_wa_retry_confirm_text": "Sistem akan mengirim ulang pesan ke nomor-nomor yang gagal pada sesi ini saja.",
        "bc_wa_retry_success": "Pengiriman ulang dimulai",
        "bc_wa_retry_error": "Gagal memicu kirim ulang",
        "bc_wa_retry_conn_error": "Kesalahan koneksi saat memicu kirim ulang",
        "lbl_infra_stat_router": "TOTAL ROUTER",
        "lbl_infra_stat_odp": "TOTAL ODP",
        "lbl_infra_stat_port": "PORT TERPAKAI",
        "lbl_infra_stat_cable": "ESTIMASI KABEL",
        "msg_unknown_error": "Kesalahan Tidak Diketahui"
    },

    "en": {
        // SIDEBAR
        "sb_brand": "WIFI MONITORING MAPS",
        "sb_unlicensed": "UNLICENSED (DEMO)",
        "sb_h_main": "MAIN",
        "sb_dash": "DASHBOARD",
        "sb_map": "LIVE MAPS",
        "sb_client": "CLIENT",
        "sb_hotspot": "HOTSPOT",
        "sb_broadcast": "WHATSAPP BROADCAST",
        "sb_pppoe": "PPPoE",
        "sb_infra": "INFRASTRUCTURE",
        "sb_inv": "INVENTORY",
        "sb_bill": "BILLING & INVOICE",
        "sb_fin": "FINANCIAL REPORT",
        "sb_h_mon": "MONITORING",
        "sb_traffic": "TRAFFIC MONITOR",
        "sb_logs": "OUTAGE LOGS",
        "sb_about": "ABOUT",
        "sb_set": "SETTINGS",
        "sb_logout": "LOGOUT",
        "sb_h_admin": "ADMINISTRATION",
        "lbl_lang_prefix": "LANG: ",

        // DASHBOARD HEADER & CARDS
        "dash_title": "DASHBOARD",
        "card_stat_client": "CLIENT STATISTICS",
        "lbl_total": "TOTAL",
        "lbl_total_port": "TOTAL PORT",
        "lbl_online": "ONLINE",
        "lbl_offline": "OFFLINE",
        "lbl_offline_since": "Offline Since",
        "lbl_mikrotik": "MIKROTIK",
        "lbl_olt": "OLT (PON)",
        "lbl_odp": "ODP",
        "lbl_tiang": "POLE",
        "lbl_client_htb": "HTB/SWITCH CLIENT",
        "lbl_client_olt": "OLT CLIENT",
        "lbl_htb": "HTB",
        "lbl_ont": "ROUTER/ONT",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "lbl_isolir_pill": "ISOLATED",
        "lbl_km": "KM",
        "lbl_temp_unit": "°C",
        "lbl_days_short": "d",
        "lbl_hours_short": "h",
        "lbl_minutes_short": "m",
        "msg_checking_ver": "Checking Version...",
        "msg_ver_offline": "Offline",
        "msg_ver_unknown": "Unknown",
        "lbl_main_server": "Main Server",
        "lbl_choose_server": "-- Select Server --",
        "lbl_choose_server_first": "-- Select Server First --",
        "alert_pro_locked": "This feature is only available in the PRO version. Please activate your license.",
        // CUSTOM CARDS
        "card_inv": "INVENTORY",
        "lbl_total_kabel": "TOTAL CABLE",
        "lbl_client_count_donut": "CLIENT",
        "lbl_kabel": "CABLE",
        "card_port": "ODP PORTS",
        "lbl_used": "USED",
        "lbl_rem": "REMAINING",
        "card_server": "SERVER STATUS",
        "lbl_cpu": "CPU LOAD",
        "lbl_ram": "RAM USAGE",
        "lbl_disk": "STORAGE",
        "lbl_temp": "TEMP",
        "card_fin": "FINANCE",
        "bdg_month": "THIS MONTH",
        "lbl_month": "MONTH",
        "lbl_profit": "PROFIT",
        "lbl_in": "INCOME",
        "lbl_out": "EXPENSE",
        "lbl_ratio": "PROFIT RATIO",
        "card_act": "OUTAGE LOGS",
        "card_mikrotik": "MIKROTIK STATUS",
        "card_traffic_history": "MIKROTIK TRAFFIC CHART",
        "lbl_chart_update_interval": "* data updated every 5 minutes",
        "th_identity": "IDENTITY",
        "th_status": "STATUS",
        "th_traffic": "TRAFFIC (IN/OUT)",
        "th_ping": "PING",
        "th_host": "HOST",
        // CLIENT PAGE
        "pg_client_search": "Search Name / IP / Coordinates...",
        "btn_dl_excel": "DOWNLOAD EXCEL",
        "btn_import_bulk": "IMPORT BULK",
        "th_name": "Client Name",
        "th_paket": "Package",
        "th_ip": "IP Address",
        "th_parent": "Parent",
        "th_wa": "WhatsApp No.",
        "th_paid_until": "Paid Until",
        "th_action": "Action",
        "th_join_date": "Join Date",
        "lbl_join_date": "Join Date",
        "pg_client_title": "CLIENT MANAGEMENT",
        "lbl_total_clients": "Total Clients",
        "lbl_active_clients": "Online / Active",
        "lbl_offline_clients": "Offline / Disconnected",
        "lbl_isolir_clients": "Isolir / Suspended",
        "lbl_total_clients_desc": "Registered in database",
        "lbl_active_clients_desc": "Currently active connection",
        "lbl_offline_clients_desc": "Not connected",
        "lbl_isolir_clients_desc": "Suspended billing clients",
        "lbl_quota_today": "Today",
        "lbl_quota_week": "This Week",
        "lbl_quota_month": "This Month",
        "lbl_saving": "SAVING...",
        "lbl_loading": "LOADING...",
        "lbl_showing": "Showing",
        "lbl_of": "of",
        "lbl_prev": "Previous",
        "lbl_next": "Next",
        "hs_u_gen": "GENERATOR",
        "hs_u_list": "USER LIST",
        "hs_u_act": "ACTIVE SESSION",
        "hs_u_prof": "PROFILE",
        "pg_hotspot_title": "HOTSPOT MANAGEMENT",
        "pg_hotspot_subtitle": "Manage vouchers, active users, and MikroTik Hotspot speed profiles.",
        "hs_u_title_add": "ADD HOTSPOT USER",
        "hs_u_title_edit": "EDIT HOTSPOT USER",
        "hs_u_act": "Active Sessions",
        "hs_u_proflist": "Profile List",
        "hs_u_profadd": "Add Profile",
        "hs_create_prof": "Create New Profile",
        "hs_prof_btn_create": "CREATE PROFILE",
        "hs_prof_btn_save": "SAVE CHANGES",
        "hs_prof_title_edit": "Edit Hotspot Profile",
        "hs_prof_tab_gen": "General",
        "hs_prof_tab_queue": "Queue",
        "hs_no_active": "No active sessions.",
        "hs_no_profiles": "No hotspot profiles found.",
        "hs_desc_gen": "Generate new Hotspot vouchers (Random/Voucher).",
        "hs_desc_list": "Manage stored Hotspot user list.",
        "hs_desc_act": "Monitor currently connected users.",
        "hs_desc_prof": "Manage speed profiles and Hotspot uptime.",
        "hs_server": "Server",
        "hs_addr_pool": "Address Pool",
        "hs_idle_timeout": "Idle Timeout",
        "hs_keepalive_timeout": "Keepalive Timeout",
        "hs_status_autorefresh": "Status Autorefresh",
        "hs_addr_list": "Address List",
        "hs_mac_cookie_timeout": "MAC Cookie Timeout",
        "hs_parent_queue": "Parent Queue",
        "hs_queue_type": "Queue Type",
        "hs_insert_before": "Insert Before",
        "hs_first": "First",
        "hs_last": "Last",
        "hs_server_prof": "Hotspot Server",
        "hs_qty": "Quantity",
        "hs_limit_uptime": "Uptime Limit",
        "hs_limit_data": "Data Limit",
        "hs_prefix": "Name Prefix",
        "hs_theme": "Print Theme",
        "hs_theme_modern": "Modern Blue",
        "hs_theme_minimal": "Minimalist (Saves Paper)",
        "hs_theme_color": "Full Color",
        "hs_gen_mode": "User Mode",
        "hs_gen_mode_up": "User = Password",
        "hs_gen_mode_vc": "User & Password Different",
        "hs_char_type": "Characters",
        "hs_char_num": "Numbers (123)",
        "hs_char_abc": "Lowercase (abc)",
        "hs_char_ABC": "Uppercase (ABC)",
        "hs_char_mix": "Mix (abc123)",
        "hs_char_MIX": "Mix (ABC123abc)",
        "hs_char_len": "Length",
        "hs_comment": "Comment",
        "hs_ph_time": "Example: 1h, 30m, 1d",
        "hs_ph_data": "Example: 500M, 1G (0=Unlimited)",
        "hs_ph_prefix": "Example: VIP-, M-",
        "hs_ph_comment": "Label (generated-nms)",
        "hs_ph_login_url": "Example: wifi.id",
        "hs_btn_generate": "GENERATE VOUCHER ⚡",
        "hs_generated_title": "NEWLY GENERATED VOUCHERS",
        "hs_btn_print_result": "PRINT ALL",
        "hs_btn_print": "PRINT SELECTED",
        "hs_confirm_del": "Delete {count} selected vouchers?",
        "hs_confirm_del_prof": "Delete this hotspot profile?",
        "hs_msg_success": "Successfully generated {count} vouchers!",
        "hs_msg_del_success": "Successfully deleted {count} vouchers!",
        "msg_vouchers_empty": "No vouchers selected for printing.",
        "th_username": "Username",
        "th_password": "Password",
        "th_profile": "Profile",
        "th_limit": "Limit",
        "th_address": "IP Address",
        "th_uptime": "Uptime",
        "th_bytes": "Total Traffic",
        "hs_confirm_kick": "Kick this user?",
        "opt_select_prof": "-- Select Profile --",
        "opt_select_server": "-- Select Server --",
        "lbl_main": "(Main)",
        "lbl_branch": "(Branch)",
        "lbl_auto": "-- Auto --",
        "hs_err_req": "Profile and Comment are required!",
        "hs_confirm_gen": "Generate {qty} vouchers now?",
        "alert_name_required": "Name is required!",
        "alert_saved": "Saved successfully!",
        "ph_filter_batch": "Filter Comment...",
        "hs_btn_print": "PRINT",
        "hs_btn_delete": "DELETE",
        "msg_sel_vouchers": "Select vouchers first!",
        "lbl_no_users": "No users yet",
        "lbl_no_photo": "No Photo",
        "lbl_home_photo": "HOME PHOTO",
        "lbl_photo_loc": "INFRA / ODP PHOTO",
        "lbl_compressing": "Compressing...",
        "lbl_uploading": "Uploading...",
        "lbl_upload_fail": "Upload Failed",
        "lbl_center": "(CENTER)",
        "lbl_branch": "(BRANCH)",
        "msg_no_logs": "No log data yet.",
        "msg_load_log_fail": "Failed to load logs.",
        "msg_save_error": "Save failed: ",
        "msg_save_fail": "Server response failed.",
        "msg_conn_err": "Connection Error",
        "msg_tele_success": "Backup successfully sent to Telegram!",
        "msg_tele_skipped": "Backup skipped (no changes or feature disabled).",
        "msg_tele_fail": "Failed to send backup: ",
        "hint_ctrl_multi": "Hold CTRL to select multiple ports.",
        "alert_guest_dash": "You are logged in as Guest/Viewer. You cannot access the Main Dashboard.",
        "alert_save_first": "Please save data first before editing path.",
        "conf_send_telegram": "Are you sure you want to send backup to Telegram now?",
        "conf_del_photo": "Delete this photo?",
        "msg_del_fail": "Delete failed: ",
        "msg_del_err": "Connection error while deleting.",
        "msg_upload_err": "Connection error while uploading.",
        "lbl_mode_static": "STATIC IP (MANUAL)",
        "lbl_mode_pppoe": "PPPoE (MIKROTIK)",
        "lbl_mode_radius": "PPPoE (RADIUS)",
        "lbl_locked": "Locked",
        "lbl_unlocked": "Unlocked (Can Drag)",
        "lbl_type_htb": "HTB / Switch (Converter)",
        "lbl_type_olt": "Passive Splitter (ODP Pole)",
        "lbl_type_jb": "Joint Box / Distribution (Multi-Core)",
        "ph_parent_manual": "Type manual source...",
        "lbl_multi_uplink_conf": "Multi-Uplink Config:",
        "lbl_manual_packet": "Package Name (Manual / Radius Override)",
        "ph_manual_packet": "Fill package name if not detected...",
        "lbl_wa_format": "WhatsApp No. (Format: 628xxx)",
        "lbl_router_user": "ROUTER USER",
        "lbl_import_dependency": "⚠️ For bulk upload, ensure openpyxl is installed. Open Putty terminal and run:",
        "lbl_import_folder_hint": "cd /root/monitoring-wifi (or adjust install folder)",
        "lbl_import_venv": "source venv/bin/activate",
        "lbl_import_pip": "pip install openpyxl",
        "lbl_import_deactivate": "deactivate",
        "lbl_pay_history_last3": "Last 3 Payments History",
        "lbl_tanggal": "date",
        "lbl_sebesar": "amount",
        "prompt_edit_expiry": "Enter New Expiry Date (Format: DD-MM-YYYY):",
        "err_date_format": "Invalid date format! Use DD-MM-YYYY (Example: 28-04-2026)",
        "conf_edit_expiry": "Change expiry for {name} to {date}?",
        "msg_expiry_updated": "Expiry updated!",
        "conf_del_tx": "Cancel/delete this transaction?",
        "msg_tx_deleted": "Transaction deleted!",
        "lbl_month_list": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        "lbl_isolir": "ISOLATED",
        "lbl_isolir_status": "(ISOLATED)",
        "lbl_router_pass": "ROUTER PASS",
        "msg_no_data": "No data.",
        "lbl_none_direct": "None / Direct",
        "lbl_none": "None",
        "lbl_no_data": "No Data Found",
        "msg_no_mk_connected": "No MikroTik router connected.",
        "msg_invalid_choice": "Invalid choice.",
        "msg_import_failed": "Failed to import",
        "msg_failed_fetch_payment": "Failed to fetch payment history data.",
        "msg_coord_format_err": "Invalid coordinate format! Must be 'latitude, longitude' (Example: -7.68, 110.50)",
        "msg_coord_nan_err": "Coordinate values must be numeric! (Example: -7.68, 110.50)",
        "msg_bank_added": "Bank account successfully added to the list!",
        "conf_delete_bank": "Are you sure you want to delete this bank account from the list?",
        "msg_bank_deleted": "Bank account successfully deleted!",
        "msg_user_deleted": "User deleted successfully!",
        "msg_user_added": "User added successfully!",
        "msg_user_updated": "User updated successfully!",
        "lbl_pass_through": "Pass Through",
        "tt_note": "Note",
        "tt_model": "Model",
        "tt_cpu": "CPU",
        "tt_uptime": "Uptime",
        "tt_internet": "Internet",
        "tt_traffic_wan": "Traffic WAN",
        "tt_type": "Type",
        "tt_cable": "Cable",
        "tt_cap": "Capacity",
        "tt_no_packet": "No Package",
        "tt_waiting": "Waiting...",
        "tt_loading_traffic": "Loading Traffic...",
        "tt_online_olt": "OLT ACTIVE",
        "tt_connected": "Connected",
        "tt_conn_arp": "Connected (ARP)",
        "tt_conn_netwatch": "Connected (Netwatch)",
        "msg_wait": "Wait...",
        "msg_confirm_kick": "Kick this user? (Will auto reconnect)",
        "msg_success": "Success",
        "msg_error": "Error",
        "msg_sel_prof": "Select profile first!",
        "msg_confirm_prof": "Change user {user} profile to {prof}?",
        "msg_prof_changed": "Profile changed & user disconnected to re-login.",
        "msg_failed": "Failed",
        "opt_select_prof": "-- Select Profile --",
        "prof_current": "(Current Profile)",
        "opt_change_prof": "-- Change to Profile --",
        "pg_client_subtitle": "Manage customer data, isolation, and payments.",
        "lbl_id_pelanggan": "CUSTOMER ID",
        "lbl_billing_active": "Billing Active (Auto Isolate)",
        "lbl_billing_hint": "*IMPORTANT: If the Auto-Isolate feature is enabled in the Billing & Tagihan menu, new clients without payment history will be isolated immediately if this is active. Disable it first, click 'Pay' in the Billing/Client menu, then reactivate it.",
        "lbl_srv_loc": "SERVER LOCATIONS",
        "conf_del_qris": "Delete QRIS?",
        "msg_qris_deleted": "QRIS deleted successfully",
        "msg_wa_pairing": "Pairing... (Scan QR)",
        "msg_wa_connected": "WhatsApp Connected!",
        "msg_wa_disconnected": "WhatsApp Disconnected",
        "wa_header": "WhatsApp Gateway",
        "wa_sub_header": "Connect your number to send automated notifications.",
        "btn_wa_connect": "CONNECT / WAKE UP",
        "btn_wa_reset": "RESET SESSION",
        "btn_download": "DOWNLOAD",
        "conf_del_logo": "Delete Logo?",
        "msg_logo_deleted": "Logo deleted successfully",
        "info_isolate_title": "Isolate Info (PPPoE & Static IP):",
        "info_isolate_desc": "ISOLIR status temporarily disconnects internet. PPPoE changes profile, while Static IP enters 'ISOLIR' address-list. Original profile remains stored.",
        "info_isolate_req": "Requirements: MikroTik profile & Address List name must be ISOLIR.",
        "info_isolate_cmd": "MikroTik Terminal Command: /ip firewall filter add chain=forward action=drop src-address-list=ISOLIR comment=\"ISOLIR IP STATIK by nms peycell\" place-before=0",
        "btn_sync": "SYNC DATA",
        "btn_dl_template": "DOWNLOAD EXCEL TEMPLATE",
        "modal_import_title": "Import Client from Excel (.xlsx)",
        "lbl_select_xlsx": "Select Excel File",
        "btn_start_import": "PROCESS IMPORT",
        "modal_pay_title": "Pay Client Bill",
        "lbl_client_name": "Client Name",
        "lbl_router_src": "MikroTik Source",
        "lbl_prof_packet": "Package Profile",
        "lbl_pay_amount": "Payment Amount (Rp)",
        "lbl_duration": "Duration (Month)",
        "lbl_pay_total": "Total",
        "lbl_pay_note": "Note (Optional)",
        "hint_prof_suggest": "(Type or selection from suggestions)",
        "hint_pay_duration": "Pay how many months at once?",
        "hint_pay_no_change_month": "No need to change month and arrears, just fill in the payment amount to avoid misunderstandings during payment.",
        "msg_pay_wifi_suffix": "Wifi Payment",
        "btn_save_pay": "SAVE PAYMENT",
        "msg_wa_greeting": "Hello",
        "hint_edit_expiry_no_pay": "Update Expiry Date without payment? Click the pencil icon above, press OK to confirm, and click X once finished.",
        "btn_billing_enable_all": "ENABLE ALL BILLING",
        "btn_billing_disable_all": "DISABLE ALL BILLING",
        "conf_bulk_billing": "Send billing status change to ALL CLIENTS?",
        "msg_selesai": "Done",
        "err_wa_not_found": "WhatsApp number not found for client: {name}",
        "conf_wa_reminder": "Send billing reminder {bill} to {name} ({phone})?",
        "msg_processing": "Message is being processed.",
        "msg_pay_success": "Payment saved successfully.",
        "msg_pay_fail": "Failed to save payment",
        "err_wa_empty": "WhatsApp number invalid or empty!",
        "tt_bypass_on": "Turn off Billing Bypass",
        "tt_bypass_off": "Turn on Billing Bypass",
        "btn_free": "FREE",
        "btn_billing_disable": "Disable Billing",
        "btn_billing_enable": "Enable Billing",
        "lbl_page": "Page",
        "ph_pay_note_default": "Wifi active period payment for {name}",
        "ph_wa_bill_tpl_default": "Hello {name}, your internet bill for this month has been issued.",
        "lbl_month_list": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        "btn_save_pay": "SAVE PAYMENT",
        // INFRA PAGE
        "pg_infra_routers": "ROUTERS",
        "lbl_tele_tpl_isolir": "Telegram Template: Client Isolir",
        "lbl_tele_tpl_reactivate": "Telegram Template: Client Reactivate",
        "lbl_cl_isolir": "Client Isolir",
        "lbl_cl_reactivate": "Client Reactivate",
        "hint_tele_tpl": "<b>Telegram Dynamic Variable Formats:</b><br>🔹 <b>PPPoE Client:</b> <code>{name}</code>, <code>{ip}</code>, <code>{status}</code>, <code>{mode}</code>, <code>{date}</code>, <code>{time}</code>, <code>{total_online}</code>, <code>{total_offline}</code>, <code>{total_isolir}</code>, <code>{packet}</code><br>🔸 <b>Hotspot Voucher:</b> <code>{name}</code>, <code>{ip}</code>, <code>{mac}</code>, <code>{host_name}</code>, <code>{server}</code>, <code>{profile}</code>, <code>{uptime}</code>, <code>{bytes_out}</code>, <code>{router_name}</code>, <code>{date}</code>, <code>{time}</code><br>🔺 <b>ODP Distribution:</b> <code>{name}</code>, <code>{parent_name}</code>, <code>{offline_count}</code>, <code>{online_count}</code>, <code>{total_count}</code>, <code>{dependent_desc}</code>, <code>{duration_desc}</code>, <code>{rca_info}</code>, <code>{date}</code>, <code>{time}</code>",
        "pg_infra_odp": "ODP & PATHS",
        "pg_infra_title": "INFRASTRUCTURE & INVENTORY",
        "pg_infra_search": "Type ODP / Router Name...",
        "ph_infra_search": "Type ODP / Router Name...",
        "pg_infra_subtitle": "Manage routers, ODPs, and network inventory.",
        // INVENTORY PAGE
        "pg_inv_title": "INVENTORY MANAGEMENT",
        "pg_inv_subtitle": "Manage warehouse stock, installed devices, and network assets.",
        "tab_installed": "INSTALLED",
        "tab_stock": "NOT INSTALLED (STOCK / WAREHOUSE)",
        "lbl_item_name_manual": "Item Name (Manual)",
        "ph_item_manual": "Example: Switch Hub 8 Port",
        "lbl_qty": "Quantity",
        "btn_add": "ADD",
        "th_item": "Item Name",
        "hint_inv_save": "Data is automatically saved when the save button is pressed.",
        "btn_save_change": "SAVE CHANGES",
        "lbl_item_stock": "Item Name (Stock)",
        "ph_item_stock": "Example: Dropcore Cable 1 Roll",
        "btn_add_stock": "ADD TO WAREHOUSE",
        "th_item_warehouse": "Item Name (Warehouse)",
        "hint_stock_save": "Warehouse data is automatically saved.",
        "desc_inv_installed": "List of devices currently active in the field (ODP, Router, Cable, etc.). This quantity is automatically calculated from the Network Topology.",
        "desc_inv_stock": "List of spare parts in the warehouse that are not yet installed. Update quantities manually when adding or removing stock.",
        // SETTINGS PAGE
        "tab_disp": "DISPLAY",
        "tab_payment": "REKENING & QRIS",
        "tab_wa": "WHATSAPP",
        "tab_auto": "AUTOMATION",
        "tab_db": "DATABASE",
        "tab_sec": "SECURITY",
        "tab_upd": "UPDATE & RESTORE",
        "set_page_title": "SYSTEM SETTINGS",
        // SETTINGS - DISPLAY
        "lbl_lang": "Language / Bahasa",
        "hint_lang": "Select interface language.",
        "lbl_web_title": "App Name / Web Title",
        "hint_web_title": "Appears in left Sidebar and Browser Tab.",
        "lbl_show_clock": "Show Clock on Dashboard",
        "hint_show_clock": "Enable to show a live clock in the dashboard header.",
        "lbl_show_news": "Show Running Text INFO",
        "hint_show_news": "Enable to show the scrolling INFO text in the dashboard header.",
        "lbl_timezone": "Dashboard Timezone",
        "opt_wib": "WIB (UTC+7)",
        "opt_wita": "WITA (UTC+8)",
        "opt_wit": "WIT (UTC+9)",
        "lbl_zone_wib": "WIB",
        "lbl_zone_wita": "WITA",
        "lbl_zone_wit": "WIT",
        "lbl_refresh": "Auto-Refresh Speed",
        "hint_refresh": "Page refresh interval. Warning: Minimum of 10-15 seconds is highly recommended. Lower values look more realtime but will drastically overload the Server & MikroTik CPU.",
        "opt_sec": "Seconds",
        "lbl_anim": "Default Cable Animation",
        "hint_anim": "Used by maps page.",
        "lbl_qris": "Payment QRIS",
        "lbl_bank_name": "Bank Name",
        "lbl_bank_acc_no": "Account Number",
        "lbl_bank_acc_name": "Account Holder Name",
        "hdr_bank_acc": "Bank Account Details",
        "hint_qris": "Upload QRIS for automatic payment. Format: JPG/PNG.",
        "lbl_favicon": "Favicon",
        "hint_favicon": "Changes visible after saving, then press CTRL + F5.",
        "lbl_changelog": "Changelog / Version History",
        "lbl_current_version": "Current Version",
        "btn_upload": "UPLOAD",
        // SETTINGS - WA
        "lbl_tpl_bill": "Billing Message Template (Manual)",
        "lbl_tpl_bill_auto": "Automated Message Template (System)",
        "lbl_tpl_pay": "Payment Success Template",
        "lbl_enable_pay_wa": "Enable WhatsApp Payment Notification",
        "lbl_enable_auto_wa": "Enable Automated (H-3/EOM) Notifications",
        "lbl_enable_isolir_wa": "Enable Isolation Notifications",
        "lbl_enable_reactivate_wa": "Enable WA Reactivation Notification",
        "lbl_print_info_title": "PRINT METHOD GUIDE",
        "lbl_print_method_browser_desc": "Use this mode if you are printing from a PC Browser (Laptop/Computer) using a standard printer (Epson, Canon, etc.).",
        "lbl_print_method_rawbt_desc": "Use this mode if you are printing from an Android phone using a Bluetooth Thermal printer.",
        "lbl_print_method_share_desc": "The smartphone must have a thermal printer service application installed, such as RawBT, Bluetooth Thermal Printer, or others.",
        "lbl_enable_manual_wa": "Enable Manual WhatsApp Feature",
        "lbl_include_qris": "Include QRIS Payment Image",
        "hint_tpl_pay": "Variable Instructions:",
        "hint_tpl_pay_desc": "Use <b>{id}</b>, <b>{name}</b>, <b>{amount}</b>, <b>{date}</b>, <b>{expired}</b>, <b>{profile}</b>, <b>{time}</b>, <b>{status}</b>, <b>{total_isolir}</b>",
        "hint_tpl_bill": "Use {id}, {name}, {month}, {price}, {amount}, {expired}, {profile}, {time}, {status}, {total_isolir}, {x}, {rekening} for dynamic variables.",
        "hint_tpl_bill_auto": "Use {id}, {name}, {month}, {price}, {amount}, {expired}, {profile}, {time}, {status}, {total_isolir}, {x}, {rekening} for dynamic variables.",
        "btn_save_tpl": "SAVE CHANGES",
        "lbl_wa_vars_title": "MESSAGE VARIABLE GUIDE",
        "lbl_var_id_desc": "Customer ID",
        "lbl_var_name_desc": "Full Customer Name",
        "lbl_var_month_desc": "Current Billing Month",
        "lbl_var_price_desc": "Package Price (Master)",
        "lbl_var_amount_desc": "Total Amount Paid",
        "lbl_var_bill_desc": "Total Invoice (Package + Arrear)",
        "lbl_var_expired_desc": "Due Date / Expiry Date",
        "lbl_var_profile_desc": "Service Package Name",
        "lbl_var_time_desc": "Message Sending Time",
        "lbl_var_status_desc": "Payment Status (Paid/Under/Over)",
        "lbl_var_x_desc": "Reminder days (H-x)",
        "lbl_var_rekening_desc": "Bank Account List (Multi-account)",
        "lbl_active_tele": "Enable Telegram Bot",
        "lbl_bot_token": "Bot Token",
        "lbl_chat_id": "Chat ID",
        "lbl_tele_trigger": "Notification Triggers",
        "lbl_cl_offline": "Client Offline",
        "lbl_cl_online": "Client Online",
        "lbl_bk_report": "Backup Report",
        "lbl_sys_startup": "System Startup",
        "lbl_odp_down": "ODP Down (Outage)",
        "tab_tg_assist": "TELEGRAM ASSISTANT",
        "lbl_tg_assist_enabled": "Enable Telegram Assistant Bot",
        "lbl_tg_assist_bots": "Bot List & Chat ID (token:chatid)",
        "hint_tg_assist_format": "Enter bot_token:chat_id per line (unlimited). Example: 7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:377554040",
        "lbl_enable_cek": "Enable /cek Command",
        "lbl_enable_status": "Enable /status Command",
        "lbl_enable_bayar": "Enable /bayar Command",
        "lbl_tg_assist_desc": "Telegram Assistant works as a two-way bot assistant for admin operations.",
        "lbl_tga_guide_title": "Telegram Assistant Operational Guide",
        "lbl_tga_guide_intro": "This feature allows admins to manage the NMS remotely via a Telegram bot.",
        "lbl_tga_multi_acc_title": "Multi-Account Support",
        "lbl_tga_multi_acc_desc": "You can register one bot for multiple staff Telegram accounts simultaneously (e.g., Field Technicians, Billing Officers, or Stock Admins). Every registered account will have access to execute bot commands.",
        "lbl_tga_format_title": "Bot List Input Format",
        "lbl_tga_format_desc": "Enter <code>bot_token:staff_id (chatid)</code> per line. If the same bot is used for multiple staff members, use the same bot token but with different chat IDs.",
        "lbl_tga_example_title": "Configuration Example (1 Bot & 3 Accounts):",
        "lbl_tga_example_desc": "<code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628111222</code> (Staff 1)<br><code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628333444</code> (Staff 2)<br><code>7395810293:AAGfXyZtWvUtSrQpOnMlKjIhGfEdCbA1234:628555666</code> (Staff 3)",
        "lbl_tga_warn_title": "Security Recommendation",
        "lbl_tga_warn_desc": "It is highly recommended to create a <b>new Telegram Bot</b> specifically for this Assistant. Do not use the same token as the Client Notification (On/Off) or Backup bot to ensure responsiveness and avoid process conflicts.",
        "lbl_tga_activate_title": "How to Activate the Bot",
        "lbl_tga_activate_desc": "After the token is entered and saved, open the Bot in Telegram and send the <code>/start</code> command to begin interacting.",
        "lbl_tele_tpl_up": "Telegram Message Template (Online)",
        "lbl_tele_tpl_down": "Telegram Message Template (Offline)",
        "lbl_tele_tpl_odp_down": "Telegram Message Template (ODP Down)",
        "lbl_tele_tpl_odp_up": "Telegram Message Template (ODP Up)",
        "hint_tele_tpl": "<b>Telegram Dynamic Variable Formats:</b><br>🔹 <b>PPPoE Client:</b> <code>{name}</code>, <code>{ip}</code>, <code>{status}</code>, <code>{date}</code>, <code>{time}</code>, <code>{total_online}</code>, <code>{total_offline}</code>, <code>{packet}</code><br>🔸 <b>Hotspot Voucher:</b> <code>{name}</code>, <code>{ip}</code>, <code>{mac}</code>, <code>{host_name}</code>, <code>{server}</code>, <code>{profile}</code>, <code>{uptime}</code>, <code>{bytes_out}</code>, <code>{router_name}</code>, <code>{date}</code>, <code>{time}</code><br>🔺 <b>ODP Distribution:</b> <code>{name}</code>, <code>{parent_name}</code>, <code>{offline_count}</code>, <code>{online_count}</code>, <code>{total_count}</code>, <code>{dependent_desc}</code>, <code>{duration_desc}</code>, <code>{rca_info}</code>, <code>{date}</code>, <code>{time}</code>",
        "lbl_tele_alert": "Telegram notifications require a valid Bot Token and Chat ID.",
        "hint_tele_chat": "Get Chat ID from @userinfobot or similar bots on Telegram.",
        "wa_inst_title": "WHATSAPP ACTIVATION GUIDE (LINUX)",
        "wa_inst_ssh": "Make sure you are logged into the SSH Server. Run these commands one by one:",
        "wa_inst_1": "1. <b>Update Package:</b> <code>sudo apt update</code>",
        "wa_inst_2": "2. <b>Install Node.js & NPM:</b> <code>sudo apt install nodejs npm -y</code>",
        "wa_inst_3": "3. <b>Install Dependencies:</b> <code>cd /root/monitoring-wifi && npm install</code>",
        "wa_inst_4": "4. <b>Install PDF Engine (Optional):</b><br>Run this command if you want to enable payment or invoice notifications via PDF:<br><div style=\"background: rgba(0,0,0,0.35); padding: 8px 12px; border-radius: 6px; font-family: monospace; font-size: 10px; color: #34d399; margin-top: 4px; display: flex; align-items: flex-start; justify-content: space-between; border: 1px solid rgba(255,255,255,0.03); line-height: 1.4;\"><span style=\"white-space: pre-line; user-select: all; text-align: left; display: block;\">cd /root/monitoring-wifi\npython3 -m venv venv\nsource venv/bin/activate\npip install reportlab\ndeactivate</span><button onclick=\"navigator.clipboard.writeText('cd /root/monitoring-wifi\\npython3 -m venv venv\\nsource venv/bin/activate\\npip install reportlab\\ndeactivate'); showToast('Commands copied!', 'success');\" style=\"background: rgba(255,255,255,0.08); border: none; color: #9ca3af; padding: 2px 6px; border-radius: 4px; font-size: 9px; cursor: pointer; display: flex; align-items: center; gap: 4px; margin-left: 8px; margin-top: 2px;\"><i class=\"fas fa-copy\"></i></button></div>",
        "wa_inst_4_note": "*Note: Adjust folder name if your project folder is placed in a location other than /root/monitoring-wifi",
        "wa_warn_title": "WARNING",
        "wa_warn_server": "This feature increases server CPU/RAM load.",
        "wa_warn_banned": "Risk of BANNED. Use a secondary number or WA Business.",
        "wa_usage_title": "SECURITY",
        "wa_usage_delay": "30s delay per message (Anti-Spam).",
        "wa_usage_mass": "Messaging many clients simultaneously poses a risk to your number safety.",
        "wa_think_twice": "Please think carefully before enabling this feature.",
        "wa_safe_tips": "TIPS FOR BETTER SAFETY:",
        "wa_tip_business": "Use a WhatsApp Business number (more robust).",
        "wa_tip_save": "Make sure your number is saved by clients to avoid being seen as a bot/spam.",
        "lbl_tpl_isolir": "Isolation Message Template (Auto)",
        "hint_tpl_isolir": "Sent when client is isolated. Use {id}, {name}, {price}, {amount}, {expired}, {profile}, {time}, {status}.",
        "hint_tpl_reactivate": "Sent when service is back online after payment. Use {id}, {name}, {amount}, {price}, {date}, {expired}, {profile}, {time}, {status}.",
        "hint_tpl_pay_desc": "Use <b>{id}</b>, <b>{name}</b>, <b>{amount}</b>, <b>{date}</b>, <b>{expired}</b>, <b>{profile}</b>, <b>{time}</b>, <b>{status}</b>",

        // PRINT LABELS
        "tab_print": "PRINT",
        "lbl_print_method": "Print Method",
        "lbl_method_browser": "Browser Print (PC/Laptop)",
        "lbl_method_rawbt": "RawBT Thermal Print (Android - HTML)",
        "lbl_method_rawbt_text": "RawBT Text Only (Android - Lighter)",
        "lbl_method_share_print": "Share to Printer App (No Watermark)",
        "hint_rawbt_html": "<b>RawBT Text Mode:</b> Lighter, saves paper, simple format (Text-Only). Ensure RawBT app is installed.",
        "lbl_print_header": "Receipt Header (Top)",
        "lbl_print_footer": "Receipt Footer (Bottom)",
        "lbl_print_paper": "Paper Size",
        "lbl_print_auto": "Auto Print After Payment",
        "lbl_print_show_logo": "Show Logo on Receipt",
        "lbl_print_store_name": "Store Name on Receipt",
        "lbl_print_template": "Receipt Content Template",
        "lbl_print_format": "Receipt Template Format",
        "hint_print_format": "Select 'Plain Text' so users can easily edit receipt text without writing HTML code.",
        "lbl_format_text": "Plain Text (Monospace - Easy)",
        "lbl_format_html": "Custom HTML Code (Advanced)",
        "btn_reset_default": "Reset to Default",
        "hint_print_template": "Use placeholders: {id}, {name}, {date}, {amount}, {packet}, {expired}, {header}, {footer}",
        "lbl_print_receipt": "Print Receipt",
        "lbl_valid_until": "Valid Until",
        "lbl_receipt_title": "PAYMENT RECEIPT",
        "conf_wa_reset": "Are you sure you want to reset the WhatsApp session? This will delete the saved session.",
        "wa_reset_sub": "You will need to scan the QR Code again later.",
        "conf_wa_clear_log": "Are you sure you want to clear all WhatsApp activity logs?",
        "lbl_wa_test": "WhatsApp Send Test",
        "ph_wa_test": "Example: 08123456789",
        "btn_wa_test_manual": "TEST MANUAL BILLING",
        "btn_wa_test_auto": "TEST AUTO BILLING",
        "lbl_wa_log": "WHATSAPP ACTIVITY LOG",
        "btn_wa_clear_log": "CLEAR LOG",
        "wa_tip_test": "You can test manual or automatic templates.",
        // SETTINGS - DB
        "lbl_backup": "Backup Data",
        "btn_to_tg": "TO TELEGRAM",
        "hint_backup": "File contains SQLite database (topology.db).",
        "lbl_restore": "Restore Data",
        "btn_restore": "RESTORE",
        "warn_restore": "WARNING: Data will be explicitly overwritten.",
        "lbl_clean_log": "Clear System Logs",
        "btn_reset_log": "RESET LOGS",
        "lbl_bk_hist": "Backup History",
        "btn_refresh_bk": "REFRESH HISTORY",
        "msg_bk_manual_start": "Backup process started in background. Please wait...",
        "msg_bk_del_conf": "Delete backup file {file}?",
        "msg_bk_load_err": "Failed to load history.",
        "msg_server_err": "Failed to connect to server.",
        "btn_bk_now": "BACKUP NOW (DOWNLOAD)",
        "lbl_auto_backup": "Enable Auto Backup",
        "lbl_backup_time": "Backup Time",
        "lbl_keep_days": "Retention (Files)",
        "hint_bk_keep": "Number of saved backup files (Max: 20).",
        "lbl_inc_files": "Included Files:",
        "hint_bk_safe": "Backup data is stored in /backups folder periodically.",
        "lbl_bk_time": "Auto-Backup Time",
        "lbl_bk_days": "Retention (Days)",
        "lbl_bk_include": "Backup Files:",
        "lbl_inc_db": "Database & Config",
        "lbl_inc_web": "Web Interface",
        "tab_bk": "BACKUP",
        "tab_tele": "TELEGRAM",
        // SETTINGS - SECURITY
        "lbl_pass_admin": "Administrator Password",
        "lbl_pass_view": "Viewer Password",
        "ph_pass_new": "New Password",
        "lbl_svc_name": "Service Name (Systemd)",
        "hint_svc": "Example: peycell-nms or monitoring-wifi (without .service)",
        "lbl_port": "App Port",
        "hint_port": "App port (Requires manual restart if changed).",
        "warn_sec": "After saving, login using new password. Service/Port needs restart.",
        "btn_upd_sec": "UPDATE SECURITY",
        "lbl_login_activity": "Login Activity",
        "hint_login_activity": "Brute-force protection active. IP auto-blocked after 5 failed login attempts.",
        "lbl_active_sessions": "active sessions now",
        "lbl_blocked_ips": "Blocked IPs",
        "lbl_min_remaining": "min remaining",
        "th_login_time": "Time",
        "th_login_ip": "IP Address",
        "th_login_device": "Device",
        "th_login_role": "Role",
        "th_login_status": "Status",
        "lbl_login_success": "Success",
        "lbl_login_failed": "Failed",
        "lbl_login_blocked": "Blocked",
        "msg_no_login_log": "No login history yet.",
        "lbl_ota_drive": "Google Drive Cloud Update",
        "hint_ota_drive": "Paste Google Drive link (Public) for file update or database restore.",
        "btn_ota_drive": "PROCESS FROM DRIVE",
        "msg_update_avail": "🎉 UPDATE AVAILABLE",
        "lbl_curr_ver": "Current Version",
        "lbl_new_ver": "Latest Version",
        // SETTINGS - UPDATE
        "lbl_upd_file": "Update File (OTA)",
        "hint_upd": "Supported targets: app.py, dashboard.html, index.html, favicon.ico",
        "warn_upd": "If updating app.py, service will auto-restart (Linux). On Windows it will fail (normal).",
        "lbl_restart": "Restart Service",
        "btn_restart": "RESTART",
        "hint_restart": "Restart is required if there are no changes after saving.",
        "msg_restart_wait": "OK! Please wait 5 seconds while the system restarts...",
        // TRAFFIC
        "lbl_server_main": "Main Server",
        "lbl_wan": "WAN:",
        "lbl_dl": "DOWNLOAD (Current)",
        "lbl_ul": "UPLOAD (Current)",
        "lbl_ping_ext": "External Ping",
        "lbl_target": "Target:",
        "hint_traffic": "Graph stores local history (browser) for 30 minutes.",
        "card_graph": "Live Traffic Graph (Last 30 Minutes)",
        "hint_graph_color": "Gold: Download | Orange: Upload",
        // LOGS
        "th_time": "Time",
        "th_device": "Device Name",
        "th_desc": "Description",
        "th_status": "Status",
        "btn_clear_log": "CLEAR LOGS (RESET)",
        "ph_log_search": "Search Logs...",
        "lbl_showing": "Showing",
        // BILLING
        "card_bill_conf": "Billing & Auto-Isolate Config",
        "lbl_last_check": "Billing Last Check :",
        "btn_patrol_now": "RUN PATROL",
        "lbl_disabled": "DISABLED",
        "lbl_cooldown": "Next Patrol In:",
        "msg_patrol_conf": "Start billing patrol now?",
        "btn_confirm": "Yes, Run Now",
        "msg_billing_check_done": "Billing Patrol finished!",
        "lbl_due_date": "Default Due Date",
        "opt_date": "Date",
        "hint_due_date": "Global monthly due date (Applies to both new and old clients without a custom active period). If the date is not available in that month (e.g. Feb 30th), it will automatically use the last day of that month.",
        "lbl_grace": "Grace Period (Days)",
        "hint_grace": "Days after due date before auto-isolate.",
        "lbl_billing_system": "Billing System",
        "opt_billing_monthly": "Monthly Cycle (Global)",
        "opt_billing_cyclic": "30-Day Cycle (Fair)",
        "opt_billing_fixed": "Fixed Billing (Personal)",
        "hint_billing_system": "Choose how the system calculates customer active periods.",
        "lbl_days": "DAYS",
        "lbl_isolir_prof": "MikroTik Isolate Profile Name",
        "hint_isolir_prof": "Profile or Address-list name in the router. The system will automatically create it if it doesn't exist.",
        "lbl_enable_isolir": "Enable Auto-Isolate",
        "lbl_coming_soon": "(ACTIVE)",
        "hint_enable_isolir": "Check to enable hourly automated isolation.",
        "lbl_wa_notif": "Enable WhatsApp Notifications",
        "hint_wa_notif": "Send H-3 reminder and isolation notification via WhatsApp.",
        "lbl_billing_interval": "Automated Check Interval",
        "hint_billing_interval": "Frequency of automated arrears checking and isolation.",
        "btn_save_conf": "SAVE SETTINGS",
        "tab_pricing": "PRICING MASTER",
        "tab_arrears": "ARREARS REPORT",
        "tab_config": "CONFIGURATION",
        "lbl_manual_test": "Manual Isolate Test (Optional)",
        "ph_pppoe_user": "PPPoE Username (Empty = All)",
        "btn_test_isolir": "TEST ISOLATE NOW",
        "hint_conf_title": "⚙️ AUTOMATION CONFIGURATION GUIDE:",
        "hint_conf_cycle_m": "Monthly Cycle: Collective billing. All clients share the same due date (Global).",
        "hint_conf_cycle_c": "30-Day Cycle: Individual billing. Due date is 30 days after activation (Fairer).",
        "hint_conf_cycle_f": "Fixed Day Method: Each client can have their own specific due date.",
        "hint_conf_grace": "Grace Period: Tolerance days. If set to 3, isolation occurs on the 4th day after due date.",
        "hint_conf_isolir_mk": "Isolate Profile: Must match the 'Profile' name in MikroTik (Must have low rate-limit).",
        "hint_conf_wa_notif": "Send WA Notifications:<br>&nbsp;&nbsp;&bull; Monthly Method: sent on the last day of the month.<br>&nbsp;&nbsp;&bull; 30-day/Fixed day Method: sent on their last active day.",
        "hint_conf_wa_h": "Warning H-: Days before auto-isolation to send warning message.",
        "hint_conf_wa_time": "Notification Time: Time to send end of month warning, pre-isolation warning, and perform isolation.",
        "hint_conf_static_title": "FOR STATIC IP & RADIUS:",
        "hint_conf_static_cmd": "Must run this command in MikroTik Terminal for isolation to work:",
        "hint_conf_auto_isolir": "Auto-Isolate: If OFF, system only reports arrears without disconnecting.",
        "info_how_it_works": "How Auto-Isolate Works",
        "pg_bill_title": "BILLING & INVOICE",
        "pg_bill_subtitle": "Configuration for automated billing and isolation.",
        "tab_pricing": "Pricing Master",
        "tab_arrears": "Arrears Report",
        "card_pricing_title": "Package Price Master",
        "card_pricing_subtitle": "Price mapping",
        "hint_pricing_master": "This package price is used to calculate estimated revenue and total billing on the Arrears Report.",
        "hint_pricing_title": "IMPORTANT: Syncing Package Names",
        "hint_pricing_match": "The package name (profile) here must match exactly with the one in the Edit Client menu for the system to automatically detect its price.",
        "hint_pricing_mikrotik": "For PPPoE MikroTik: Fill in according to the 'Profile' name in MikroTik.",
        "hint_pricing_static": "For Static IP & PPPoE Radius: Fill in according to the 'Package' name you created in Edit Client.",
        "lbl_hotspot_voucher_desc": "HOTSPOT VOUCHER SPECIAL INSTRUCTIONS",
        "btn_import_prof": "IMPORT PROFILES",
        "btn_add_manual": "ADD MANUAL",
        "th_paket_name": "Package Name",
        "th_price": "Price (Rp)",
        "lbl_enable_tax": "Enable Tax (PPN)",
        "lbl_tax_rate": "Tax Rate (%)",
        "th_tax": "Tax",
        "th_total_price": "Total (Tax Included)",
        "msg_no_price": "No price data.",
        "btn_save_price": "SAVE PRICE",
        "card_arrears_title": "Arrears Report",
        "card_arrears_subtitle": "Total bills and outstanding arrears for unpaid clients",
        "th_due_date": "Due Date",
        "msg_no_arrears": "No arrears.",
        "lbl_arrears_total_month": "Total Arrears This Month",
        "msg_loading_data": "Loading data...",
        "msg_import_mk_confirm": "Import MikroTik profiles?",
        "msg_import_success": "new profiles imported from MikroTik.",
        "msg_err_fetch_prof": "Failed to fetch profiles: ",
        "msg_err_conn": "Connection failed: ",
        "msg_confirm_del_prof": "Delete package price: ",
        "msg_prompt_paket": "Enter Package Name (Must exactly match Client):",
        "msg_prof_exists": "Profile already exists!",
        "msg_no_finance_data": "Finance data not loaded. Refresh page.",
        "msg_all_pd": "✅ All clients have paid! No arrears.",
        "msg_open_client": "Open Client",
        "msg_months": "Months",
        "msg_maintenance": "Feature is under maintenance",
        "msg_confirm_test_isolir": "Are you sure you want to run isolate test for ",
        "msg_all_clients": "all clients",
        "msg_billing_check_done": "Isolate test completed!",
        // FINANCE
        "fin_title_page": "FINANCIAL REPORT & CASH",
        "fin_income_label": "INCOME (THIS MONTH)",
        "fin_expense_label": "EXPENSE (THIS MONTH)",
        "fin_balance_label": "NET BALANCE",
        "fin_balance_month_label": "BALANCE THIS MONTH",
        "fin_balance_total_label": "TOTAL CASH BALANCE",
        "fin_month_heading": "Finance for ",
        "lbl_filter_date": "FILTER DATE",
        "fin_txt_loading": "Loading data...",
        "fin_h_archive": "MONTHLY REPORT ARCHIVE",
        "fin_txt_no_archive": "No monthly report history found.",
        "modal_tx_title": "Record New Transaction",
        "lbl_tx_type": "Transaction Type",
        "opt_income": "Income (+)",
        "opt_expense": "Expense (-)",
        "lbl_tx_client": "Client Name (Auto-Active)",
        "hint_tx_client": "Automatically re-activate client if selected (PPPoE Only).",
        "lbl_tx_cat": "Category",
        "lbl_tx_amount": "Amount (Rp)",
        "lbl_tx_note": "Note",
        "ph_tx_note": "Transaction description...",
        "fin_alert_nominal": "Amount must be filled!",
        "fin_err_save": "Failed to save transaction: ",
        "fin_confirm_del": "Delete this transaction?",
        "fin_export_empty": "Filtered data is empty. Nothing to export.",
        "fin_csv_header": "DATE,TYPE,CATEGORY,NOTE,AMOUNT,USER",
        "fin_no_data": "No transaction data.",
        "cat_wifi": "WiFi Payment",
        "fin_report_btn": "Report",
        "fin_report_btn": "Report",
        "opt_choose_client": "-- Choose Client (Optional) --",
        "lbl_hal": "Page",
        "months": ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
        "fin_in_pill": "INCOME",
        "fin_out_pill": "EXPENSE",
        // MISC generic
        "msg_loading": "Loading...",
        "msg_error": "An Error Occurred",
        "msg_saved": "Saved Successfully",
        "alert_saved": "Saved",
        "alert_admin_only": "Admin only.",
        "alert_save_failed": "Failed to save",
        "alert_conn_failed": "Failed to connect to server",
        "alert_update_failed": "Failed to update",
        "alert_security_updated": "Security & System Config updated. If Port/Service changed, restart required.",
        "msg_pwd_changed_logout": "Password changed successfully. Please login again.",
        "alert_select_file": "Select database file (.db, .json, .zip)",
        "confirm_restore_db": "Restore database?",
        "alert_restore_success": "Restore successful! Page will reload...",
        "alert_restore_failed": "Restore failed:",
        "alert_upload_failed": "Upload failed:",
        "alert_restore_ok": "Restore successful",
        "confirm_restart": "Restart service?",
        "alert_restart_ok": "Restart OK",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "msg_set_not_loaded": "Settings data not loaded.",
        "msg_saved_ok": "Saved successfully!",
        "conf_logout": "Logout?",
        "btn_refresh": "REFRESH",
        "btn_delete": "DELETE",
        "lbl_auto": "AUTO",
        "lbl_cable_km": "CABLE (KM)",
        "msg_saving": "SAVING...",
        "wa_log_err": "WA Log Error",
        "lbl_search_note": "Search Description",
        "lbl_tx_date": "Transaction Date",
        "msg_req_err": "Request Error",
        "msg_sending": "Sending...",
        "msg_no_backup_files": "No backup files found on server.",
        "msg_fail_load_list": "Failed to load list.",
        "msg_all_pd": "No Arrears Found",
        "msg_billing_check_done": "Billing check complete.",
        "msg_confirm_test_isolir": "Run billing check for ",
        "msg_all_clients": "All Clients",
        "conf_del_item": "Delete this item?",
        "conf_del_stock": "Delete warehouse item?",
        "msg_pwd_wrong": "Incorrect Password!",
        "lbl_infra_stat_router": "TOTAL ROUTERS",
        "lbl_infra_stat_odp": "TOTAL ODP BOXES",
        "lbl_infra_stat_port": "USED ODP PORTS",
        "lbl_infra_stat_cable": "ESTIMATED CABLE",
        "msg_unknown_error": "Unknown Error",
        "btn_reset_auto": "Reset to Auto",

        // PPPoE
        "sb_pppoe": "PPPoE",
        "pp_u_create": "CREATE USER",
        "pp_u_list": "SECRET LIST",
        "pp_u_act": "ACTIVE SESSION",
        "pp_u_prof": "PROFILES",
        "pp_desc_create": "Add new PPPoE secret to MikroTik.",
        "pp_desc_list": "Manage stored PPPoE secrets.",
        "pp_desc_act": "Monitor currently connected PPPoE users.",
        "pp_desc_prof": "List of available PPP profiles on MikroTik.",
        "pp_user": "Username",
        "pp_pass": "Password",
        "pp_service": "Service",
        "pp_remote_addr": "Remote Address",
        "pp_caller_id": "Caller ID",
        "pp_btn_create": "CREATE PPPoE USER",
        "pp_confirm_del": "Delete {count} selected PPPoE secrets?",
        "pp_msg_create_success": "PPPoE user created successfully!",
        "pp_msg_del_success": "Deleted {count} secrets successfully!",
        "pp_ph_user": "Username...",
        "pp_ph_pass": "Password...",
        "pp_ph_comment": "Comment / Label",
        "pp_title_edit": "Edit PPPoE User",
        "pp_msg_update_success": "User updated successfully!",
        "pp_btn_save": "SAVE CHANGES",
        "pp_local_addr": "Local Address",
        "pp_last_logged_out": "Last Logged Out",
        "pp_disc_reason": "Disconnect Reason",
        "pp_toggle_pass_hide": "Hide",
        "pp_toggle_pass_show": "Show Password",
        "pp_ph_select_server": "-- Select Server --",
        "pp_ph_select_profile": "-- Select Profile --",
        "pp_only_one": "Only One",
        "pp_ph_local_addr": "e.g. 192.168.1.1 (Optional)",
        "pp_ph_remote_addr": "e.g. 192.168.1.0/24 (Optional)",
        "pp_u_addprof": "ADD PROFILE",
        "pp_addprof_desc": "Create a new PPP profile on MikroTik.",
        "pp_addprof_name": "Profile Name",
        "pp_addprof_dns": "DNS Server",
        "pp_addprof_rate": "Rate Limit",
        "pp_addprof_iq": "Insert Queue Before",
        "pp_addprof_pq": "Parent Queue",
        "pp_addprof_qtu": "Queue Type Upload",
        "pp_addprof_qtd": "Queue Type Download",
        "pp_addprof_ph_name": "Profile name (required)...",
        "pp_addprof_ph_dns": "e.g. 8.8.8.8,8.8.4.4 (Optional)",
        "pp_addprof_ph_rate": "e.g. 10M/5M (Optional)",
        "pp_addprof_opt_def": "-- Default --",
        "pp_addprof_opt_none": "(none)",
        "pp_addprof_btn": "CREATE PROFILE",
        "pp_addprof_ok": "Profile created successfully!",
        "pp_addprof_err_name": "Profile name is required.",
        "pp_delprof_confirm": "Delete profile '{name}'? Warning: users using this profile may be affected!",
        "pp_delprof_ok": "Profile deleted successfully!",
        "pp_prof_title_edit": "Edit PPPoE Profile",
        "pp_msg_prof_update_success": "Profile updated successfully!",
        "pp_title_main": "PPPoE MANAGEMENT",
        "pp_subtitle_main": "Manage PPPoE clients, monitor status, and MikroTik billing integration.",
        "pp_stats_total": "TOTAL SECRETS",
        "pp_stats_online": "ONLINE",
        "pp_stats_disabled": "DISABLED",
        "pp_btn_export": "EXPORT CSV",
        "pp_profile": "PPPoE Profile",
        "pp_th_status": "STATUS",
        "pp_th_maps": "MAPS",
        "pp_th_billing": "BILLING",
        "lbl_traffic_24h": "TRAFFIC CHART - LAST 24 HOURS",
        "lbl_traffic_7d": "TRAFFIC CHART - LAST 7 DAYS",
        "lbl_chart_update_daily": "* data updated once a day",
        "pp_btn_check": "Check",
        "pp_tt_check": "Check Availability",
        "pp_tt_toggle_pass": "Show/Hide",
        "pp_tt_gen_pass": "Generate Password",

        // MAPS & MODALS
        "map_title_label": "Labels (Show/Hide)",
        "map_title_autoref": "Auto Refresh",
        "fab_add_mk": "Add MikroTik (Branch)",
        "fab_add_olt": "Add OLT (Active)",
        "fab_add_odp": "Add ODP",
        "fab_add_client": "Add Client",
        "modal_edit_title": "Edit Device",
        "lbl_choose_mk": "CHOOSE MANAGED MIKROTIK",
        "lbl_mk_login_conf": "MikroTik Login Config",
        "lbl_client_type": "CLIENT TYPE (CONNECTION)",
        "lbl_dev_name": "Device Name",
        "lbl_coords": "Coordinates (Lat, Lng)",
        "lbl_notes": "Notes / Description",
        "ph_notes": "Write notes (technician, key location, etc)...",
        "pg_mon_logs_title": "MONITORING & LOGS",
        "pg_mon_logs_subtitle": "Monitor real-time traffic and client outage history.",
        "card_traffic_graph": "Live Traffic Graph (Last 30 Minutes)",
        "hint_traffic_color": "Gold: Download | Orange: Upload",
        "conf_clear_logs": "Clear all outage logs?",
        "err_reset_logs": "Failed to clear logs.",
        "msg_waiting_data": "Waiting for data...",
        "lbl_ping_ext": "External Ping",
        "lbl_dl": "DOWNLOAD",
        "lbl_ul": "UPLOAD",
        "ph_log_search": "Search client name or message...",
        "btn_clear_log": "CLEAR LOG (RESET)",
        "card_traffic_graph": "Live Traffic Graph (Last 30 Minutes)",
        "ph_log_search": "Search client name or message...",
        "msg_waiting_data": "Waiting for data...",
        "conf_clear_logs": "Clear all outage logs?",
        "err_reset_logs": "Failed to clear logs.",
        "lbl_isolir_pill": "ISOLATED",
        "btn_download": "DOWNLOAD",
        "lbl_empty": "Empty",
        "conf_backup_now": "Backup now?",
        "lbl_pos_status": "Position Status",
        "opt_locked": "Locked",
        "opt_unlocked": "Unlocked (Draggable)",
        "lbl_srv_lan": "LAN Ports (Auto / Manual)",
        "lbl_srv_sfp": "SFP Ports (Auto / Manual)",
        "lbl_man_wan": "MANUAL WAN INTERFACE",
        "lbl_ext_ping": "EXTERNAL PING TARGET",
        "lbl_det_status": "Current Detection Status",
        "btn_edit_path": "EDIT PATH (DRAG)",
        "lbl_odp_type": "ODP Type",
        "lbl_lan_count": "LAN Port Count",
        "lbl_fo_a": "FO A Count",
        "lbl_fo_b": "FO B Count",
        "lbl_tech": "Technology",
        "lbl_pon_out": "PON Ports (Output)",
        "lbl_uplink_in": "Uplink Ports (Input)",
        "lbl_slot_out": "Output Slots (Drop)",
        "lbl_dist_mode": "Distribution Mode:",
        "lbl_core_cap": "Core Capacity",
        "lbl_uplink_src": "SOURCE CONNECTION (UPLINK)",
        "lbl_parent": "Parent",
        "lbl_from_port": "From Parent Port (Output)",
        "lbl_cable_color": "Cable / Tube Color",
        "lbl_input_port": "Enter ODP Port",
        "chk_poe_in": "Input Carries PoE?",
        "lbl_ip_man": "IP Address (Manual)",
        "lbl_mon_mode": "MONITORING METHOD (STATIC IP)",
        "lbl_pppoe_user": "SELECT PPPoE USER (FROM MIKROTIK)",
        "lbl_client_detail": "CLIENT DETAILS (AUTO)",
        "lbl_prof_now": "CURRENT PROFILE",
        "lbl_change_prof": "CHANGE PROFILE",
        "btn_update": "UPDATE",
        "btn_kick": "KICK USER",
        "chk_poe_src": "Is Client POE Source?",
        "lbl_wifi_data": "Login & WiFi Data",
        "lbl_wifi": "WiFi SSID",
        "lbl_photo_loc": "LOCATION / ODP POLE PHOTO",
        "btn_take_photo": "TAKE / UPLOAD PHOTO",
        "btn_del_dev": "DELETE DEVICE",
        "btn_cancel": "CANCEL",
        "btn_save": "SAVE",
        "btn_remote": "REMOTE ROUTER",
        "btn_chat_wa": "CHAT WHATSAPP",
        "btn_bill": "BILL CUSTOMER",
        "modal_log_title": "LOG HISTORY",
        "btn_close": "CLOSE",
        "lbl_cable_len": "CABLE LENGTH:",
        "btn_reset_straight": "RESET STRAIGHT",
        "btn_cancel_draw": "CANCEL",
        "btn_save_path": "SAVE PATH",
        "map_lbl_client_list": "CLIENT LIST",
        "map_lbl_on": "ON:",
        "map_lbl_off": "OFF:",
        "map_lbl_isolir": "ISOLIR:",
        "map_title_show_offline": "Show Offline Only",
        // LICENSE
        "pg_lic_title": "License Activation - PEYCELL NMS",
        "lbl_lic_active": "License Active",
        "msg_lic_registered": "This application is officially registered.",
        "lbl_lic_type": "License Type",
        "lbl_lic_owner": "License Owner",
        "lbl_machine_id": "Machine ID",
        "btn_enter_dash": "ENTER DASHBOARD",
        "lbl_lic_activation": "License Activation",
        "msg_lic_locked": "This application is locked and requires an active license.",
        "lbl_your_mid": "Your Machine ID",
        "lbl_name": "Full Name (Buyer Data)",
        "ph_name": "Enter your name...",
        "lbl_email": "Email Address",
        "ph_email": "example@email.com",
        "msg_copy_mid": "Copy Model ID above, then send to Administrator to get License:",
        "lbl_input_lic": "Enter License Key",
        "ph_lic_key": "Paste license code here...",
        "btn_activate": "ACTIVATE NOW",
        "footer_nms": "PEYCELL NETWORK MANAGEMENT SYSTEM",
        "err_empty_lic": "Enter license key first!",
        "msg_processing": "Processing...",
        "msg_lic_success": "License Activated Successfully! Redirecting...",
        "err_lic_fail": "Activation failed",
        "err_conn": "Connection error: ",
        // DYNAMIC JS
        "btn_remote_on": "REMOTE ROUTER (ON)",
        "btn_remote_off": "ROUTER OFFLINE",
        "opt_select_prof": "-- Select Profile --",
        "prof_current": "(Current)",
        "tt_model": "Model",
        "tt_cpu": "CPU",
        "tt_uptime": "Uptime",
        "tt_internet": "Internet",
        "tt_traffic_wan": "TRAFFIC WAN",
        "tt_note": "Note",
        "th_time": "Time",
        "th_message": "Message",
        "th_type": "Type",
        "th_name": "Name",
        "th_name": "Name",
        "msg_no_logs": "No logs found.",
        "msg_loading_logs": "Loading logs...",
        // ALERTS & MESSAGES
        "msg_save_error": "Save Error: ",
        "msg_save_fail": "Failed to save (Server Error/Auth)",
        "conf_del_client": "Are you sure you want to delete this client?",
        "conf_del_router": "Delete this Branch Router? Managed clients will revert to Main Server.",
        "conf_del_node": "Delete this Node? WARNING: All devices below it will lose their parent!",
        "alert_server_del": "Main Server CANNOT be deleted!",
        "msg_restore_success": "RESTORE SUCCESS! Database updated successfully.",
        "msg_restore_fail_auth": "FAILED: Wrong Password/Session Expired. Please Logout & Login again.",
        "msg_restore_fail_size": "FAILED: File too large.",
        "msg_restore_fail_srv": "FAILED: Server Error ",
        "msg_conn_fail": "Connection failed: ",
        "msg_read_fail": "Failed to read backup file: ",
        "conf_send_telegram": "Send latest database to Telegram now?",
        "msg_tele_success": "Backup sent to Telegram!",
        "msg_tele_skipped": "Token/ChatID not set in app.py",
        "msg_tele_fail": "Failed: ",
        "alert_save_first": "Save new device first before editing path.",
        "alert_no_parent_coord": "Failed to detect parent coordinates! Ensure parent is selected.",
        "conf_overwrite": "WARNING: This will overwrite ALL topology data with the backup file! Continue?",
        "msg_restore_ok_reload": "Restore successful! Page will reload.",
        "msg_restore_fail_gen": "Restore Failed: ",
        "msg_del_fail": "Delete failed: ",
        "msg_del_err": "Error deleting photo",
        "msg_upload_fail": "Upload failed: ",
        "msg_upload_err": "Error upload",
        "conf_del_photo": "Delete this photo?",
        "alert_guest_dash": "Technician login cannot access dashboard",
        "lbl_no_photo": "No photo yet",
        "lbl_compressing": "Compressing...",
        "lbl_uploading": "Uploading...",
        "lbl_upload_fail": "Upload failed",
        "lbl_upload_err": "Error upload",
        "lbl_lic_active_badge": "LICENSE ACTIVE",
        "lbl_center": "(CENTER)",
        "lbl_branch": "(BRANCH)",
        // NEW FINANCE
        "fin_rep_title": "📁 Monthly Reports (Download)",
        "fin_txt_no_data": "No previous month reports available (will appear automatically next month).",
        "lbl_page": "Page",
        "lbl_of": "of",
        "lbl_clients": "Clients",
        // CLIENT ACTIONS
        "btn_activate": "✅ ACTIVATE",
        "btn_isolate": "🔴 ISOLATE",
        "btn_pay": "PAY",
        "btn_paid": "PAID",
        "btn_free": "FREE",
        "tt_bypass_on": "Bypass ON (Free)",
        "tt_bypass_off": "Evaluate Bypass",
        "leg_action": "ACTION LEGEND:",
        "leg_isolir": "= Disconnect (1kbps)",
        "leg_pay": "= Input Payment",
        "leg_paid": "= Paid This Month",
        "leg_free": "= Free of Charge",
        "map_btn_dash": "BACK TO DASHBOARD",
        "map_title_logout": "Logout",
        "map_title_outage": "Outage History",
        "map_title_backup": "Backup to Telegram",
        "map_title_anim": "Cable Animation",
        "map_type_dark": "DARK",
        "map_type_hybrid": "HYBRID",
        "map_type_clean": "CLEAN",
        // MISSING KEYS (ADDED)
        "lbl_fav": "Favicon",
        "lbl_custom_logo": "Custom Login Logo",
        "hint_logo": "Displayed on login page. Max: 500KB. Format: PNG, JPG, GIF, SVG",
        "btn_remove": "REMOVE",
        "btn_upload": "UPLOAD",
        "msg_upload_ok": "Upload Successful!",
        "coming_soon": "COMING SOON",
        "btn_billing_enable": "Enable Billing",
        "btn_billing_disable": "Disable Billing",
        "btn_billing_enable_all": "ENABLE ALL BILLING",
        "btn_billing_disable_all": "DISABLE ALL BILLING",
        "msg_billing_repair": "⚠️ This feature is under maintenance. Auto-Isolate is temporarily unavailable. Use manual isolate via client edit.",
        "ph_stock_name": "Example: Dropcore Cable 1 Roll",
        "alert_stock_name": "Please enter stock item name",
        "alert_stock_qty": "Quantity must be at least 1",
        "alert_stock_saved": "Stock Changes Saved",
        "confirm_del_stock": "Delete this stock item?",
        "fin_title_page": "FINANCIAL REPORT & CASH",
        "fin_income_label": "INCOME (THIS MONTH)",
        "fin_expense_label": "EXPENSE (THIS MONTH)",
        "fin_balance_label": "NET BALANCE",
        "fin_btn_filter": "FILTER",
        "fin_btn_reset": "RESET",
        "fin_btn_add_tx": "RECORD TRANSACTION",
        "fin_btn_excel": "EXPORT CSV",
        "fin_th_date": "DATE",
        "fin_th_type": "TYPE",
        "fin_th_category": "CATEGORY",
        "fin_th_notes": "DESCRIPTION",
        "fin_th_amount": "AMOUNT",
        "fin_th_action": "ACTION",
        "fin_txt_loading": "Loading data...",
        "fin_h_archive": "MONTHLY REPORT ARCHIVE",
        "fin_txt_no_archive": "No monthly report history found.",
        "modal_tx_title": "Record New Transaction",
        "modal_tx_edit_title": "Edit Transaction",
        "lbl_tx_type": "Transaction Type",
        "opt_income": "Income (+)",
        "opt_expense": "Expense (-)",
        "lbl_tx_client": "Client Name (Auto Wake-up)",
        "hint_tx_client": "Automatically opens isolate if client is selected. (PPPoE Only).",
        "lbl_tx_cat": "Category",
        "lbl_tx_amount": "Amount (Rp)",
        "lbl_tx_note": "Notes",
        "fin_modal_title": "Manual Transaction Input",
        "fin_label_type": "Transaction Type",
        "fin_opt_expense": "Expense (Money Out)",
        "fin_opt_income": "Income (Money In)",
        "fin_label_cat": "Category",
        "fin_label_amount": "Amount",
        "fin_label_note": "Note",
        "fin_ph_note": "Example: Buy 1 roll cable",
        "fin_btn_save": "SAVE TRANSACTION",
        // FINANCE CATEGORIES
        "cat_invest": "Investment",
        "cat_grant": "Grant",
        "cat_others": "Others",
        "cat_tools": "Equipment",
        "cat_maint": "Maintenance",
        "cat_ops": "Operational",
        "cat_salary": "Salary",
        "cat_wifi": "WiFi Payment",
        "cat_carryover": "Balance Carryover",
        "fin_no_data": "No data found",
        "fin_confirm_del": "Delete this transaction?",
        "fin_alert_nominal": "Amount required!",
        "fin_csv_header": "DATE,TYPE,CATEGORY,NOTE,AMOUNT,USER",
        "fin_report_btn": "Report ",
        "fin_export_empty": "No data to export",
        "fin_txt_loading": "Loading data...",
        "fin_err_save": "Failed to save: ",
        "fin_err_id": "ID Not Found",
        // HOTSPOT (EN)
        "hs_theme": "Voucher Theme",
        "hs_theme_modern": "Modern Dark (Blue)",
        "hs_theme_minimal": "Minimalist (Ink Saver)",
        "hs_theme_color": "Colorful (Vibrant)",
        "hs_gen_mode": "Voucher Mode",
        "hs_gen_mode_up": "User = Password",
        "hs_gen_mode_vc": "User & Password",
        "hs_char_type": "Characters",
        "hs_char_num": "Numbers",
        "hs_char_abc": "abc",
        "hs_char_ABC": "ABC",
        "hs_char_mix": "abc + 123",
        "hs_char_MIX": "AaBb + 123",
        "hs_char_len": "Length",
        "hs_server_prof": "Server Hotspot",
        "hs_dns_detected": "Login URL:",
        "hs_login_url": "Login Page URL",
        "hs_login_url_ph": "Enter manually if auto-detect fails...",
        "hs_btn_print": "PRINT VOUCHER",
        "hs_btn_print_result": "PRINT GENERATED RESULTS",
        "hs_generated_title": "Generated Vouchers",
        "hs_limit_uptime": "Duration (Time Limit)",
        "hs_limit_data": "Quota (Data Limit)",
        "hs_comment": "Comment / Batch",
        "hs_prefix": "Prefix Code",
        "hs_qty": "Quantity",
        "hs_profile": "User Profile",
        "hs_server": "Hotspot Server",
        "hs_u_list": "USER LIST",
        "hs_u_gen": "GENERATOR",
        "hs_u_act": "ACTIVE SESSIONS",
        "hs_u_prof": "PROFILES",
        "hs_desc_gen": "Generate bulk hotspot vouchers with custom configurations.",
        "hs_desc_list": "View, print, or delete vouchers already stored in the router.",
        "hs_desc_act": "Monitor users currently connected and using the internet.",
        "hs_desc_prof": "Manage speed profiles and uptime limits for hotspot packages.",
        "hs_copy_succ": "Username copied!",
        "hs_print_confirm": "Print selected vouchers?",
        "hs_btn_generate": "GENERATE VOUCHER",
        "hs_confirm_gen": "Generate {qty} vouchers?",
        "hs_confirm_del": "Delete {count} selected vouchers?",
        "hs_msg_success": "Successfully created {count} vouchers!",
        "hs_msg_del_success": "Successfully deleted {count} vouchers!",
        "hs_err_req": "Profile and Comment are required!",
        "hs_ph_time": "Example: 3h, 1d",
        "hs_ph_data": "e.g. 1G, 500M",
        "hs_ph_comment": "Required (e.g. Batch-01)",
        "hs_ph_login_url": "Fill manually if auto-detect fails...",
        "ph_filter_batch": "Filter Batch (Comment)...",
        "hs_create_prof": "Create New Profile",
        "hs_prof_name": "Profile Name",
        "hs_rate_limit": "Rate Limit (Rx/Tx)",
        "hs_shared_users": "Shared Users",
        "hs_session_timeout": "Session Timeout",
        "hs_btn_create_prof": "CREATE PROFILE",
        "hs_existing_profs": "Existing Profiles",
        "th_rate_limit": "Rate Limit",
        "th_shared": "Shared",
        "hsp_ph_name": "Required (e.g. 5Mbps)",
        "hsp_ph_rate": "e.g. 5M/5M",
        "hsp_ph_timeout": "e.g. 1d",
        "msg_sel_vouchers": "Select vouchers first!",
        "msg_wa_scan_qr": "Scan QR to connect WhatsApp:",
        "msg_wa_connected": "WhatsApp Connected!",
        "msg_wa_pairing": "Waiting for QR Scan...",
        "msg_wa_offline": "WhatsApp Disconnected",
        "hs_confirm_kick": "Kick this user session?",
        "alert_name_required": "Name is required!",
        "msg_vouchers_empty": "No vouchers to print.",
        "opt_select_server": "-- Select Server --",
        "lbl_main_server": "Main Server",
        "lbl_target_server": "Target Server:",
        "lbl_lang_prefix": "LANG: ",
        "th_bytes": "Traffic (In/Out)",
        "btn_add_profile": "CREATE PROFILE",
        "lbl_main": "(MAIN)",
        "lbl_branch": "(BRANCH)",

        "btn_add_arrears": "Add Arrears",
        "lbl_add_arrears": "Manual Arrears Adjustment",
        "lbl_edit_arrears": "Edit Arrears",
        "msg_loading_log": "Loading logs...",
        "msg_loading_logs": "Loading logs...",
        "msg_loading_schedule": "Loading schedule...",
        "th_bill": "Bill",
        "th_months": "Months",
        "th_date": "Date",
        "lbl_schedule_today": "Today's Notification Schedule",
        "lbl_unit_client": "Clients",
        "lbl_unit_schedule": "Schedules",
        "lbl_status_sent": "Sent",
        "lbl_status_isolated": "Isolated",
        "lbl_status_waiting": "Waiting",
        "lbl_status_done": "Paid / Done",
        "lbl_reason_h3": "3 Days Before Due",
        "lbl_reason_eom": "End of Month",
        "lbl_reason_pre_isolir": "Pre-Isolation",
        "lbl_reason_isolir": "Isolation",
        "msg_all_pd": "✅ All paid!",
        "msg_confirm_test_isolir": "Run manual billing check for ",
        "msg_auto_arrears_err": "Auto arrears cannot be deleted manually. Please process client payment.",
        "fin_desc_page": "Record and monitor operational income/expense.",
        "opt_loading": "Loading...",
        "fin_txt_no_data": "No transaction data yet.",
        "fin_report_btn": "Report",
        "fin_csv_header": "DATE,TYPE,CATEGORY,NOTES,AMOUNT,USER",
        "fin_csv_report_header": "NO,DATE,DESCRIPTION,INCOME,EXPENSE,BALANCE",
        "lbl_total": "TOTAL",
        "sb_balance": "Balance",
        "ph_item_manual": "Example: Switch Hub 8 Port",
        "ph_item_stock": "Example: Cable Dropcore 1 Roll",
        "msg_sync_data": "⏳ Syncing data...",
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "months": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        "cat_wifi": "WiFi Payment",
        "cat_invest": "Investment",
        "cat_grant": "Grants / Others",
        "cat_others": "Others",
        "cat_tools": "Tools & Materials",
        "cat_maint": "Maintenance",
        "cat_ops": "Operational",
        "cat_salary": "Salary / Fee",
        "cat_carryover": "Balance Carryover",
        "lbl_balance_badge": "BALANCE",
        "lbl_arrears_warning": "Arrears Detected",
        "lbl_arrears_suffix": "Months",
        "lbl_paid_until_short": "Paid until",
        "lbl_active_success": "Active Status",
        "fin_alert_nominal": "Amount must be greater than 0",
        "fin_err_save": "Save failed:",
        "fin_confirm_del": "Delete this transaction?",
        "fin_export_empty": "No data to export",
        "conf_del_item": "Delete this item from installed list?",
        "conf_del_stock": "Delete this item from warehouse?",
        "msg_set_not_loaded": "Settings not loaded.",
        "alert_save_failed": "Save Failed",
        "msg_saved_ok": "Saved successfully",
        "lbl_auto": "AUTO",
        "btn_reset_auto": "Reset to Auto",
        "msg_saving": "Saving...",
        "alert_saved": "Settings Saved",
        "msg_server_err": "Server Error or Connection Lost",
        "msg_all_clients": "all clients",
        "conf_mass_wa_billing": "Run mass WhatsApp notification for all clients in arrears?",
        "msg_processing": "Processing...",
        "err_no_phone": "Client {name} has no WhatsApp number.",
        "msg_no_arrears_rem": "Client {name} has no arrears.",
        "conf_send_bill": "Send bill reminder Rp {bill} to {name}?",
        "lbl_hal": "Page",
        "fin_in_pill": "INCOME",
        "fin_out_pill": "EXPENSE",
        "fin_no_data": "No data.",
        "lbl_today": "Today",
        "msg_notify_start": "Notification process started.",
        "msg_notify_fail": "Failed to start notification.",
        "msg_no_logs": "No logs yet.",
        "msg_loading_logs": "Loading logs...",
        "lbl_mode_auto": "Auto",
        "lbl_mode_manual": "Manual",
        "msg_confirm_notify": "Send notifications for today's schedule? Mode: ",
        "alert_conn_failed": "Failed to connect to server.",
        "lbl_tpl_auto": "Template: Auto",
        "lbl_tpl_manual": "Template: Manual",
        // AUTOMATION KEYS (EN)
        "sb_auto": "AUTOMATION & BACKUP",
        "tab_backup": "AUTO BACKUP",
        "tab_tele": "TELEGRAM BOT",
        "lbl_auto_backup": "Enable Auto Backup",
        "lbl_backup_time": "Backup Time (WIB)",
        "lbl_keep_days": "Keep Backup (Days)",
        "lbl_inc_files": "Select Backup Files",
        "lbl_bot_token": "Bot Token",
        "lbl_chat_id": "Chat ID",
        "btn_test_bot": "TEST CONNECTION",
        "lbl_notif_trigger": "Notification Triggers",
        "chk_offline": "Client OFFLINE",
        "chk_online": "Client ONLINE",
        "chk_daily": "Daily Report",
        "chk_backup": "Backup Report",
        "chk_startup": "System Startup",
        "lbl_trig_desc": "Select events to send to Telegram.",
        "msg_test_sent": "Test Message Sent! Check your Telegram.",
        "alert_bk_trig": "Backup started in background",
        "btn_bk_now": "BACKUP NOW",
        "lbl_paid_until_full": "PAID UNTIL (ACTIVE PERIOD)",
        "hint_paid_until_full": "*Client's last paid date (expiry)",
        "lbl_arrears_warning": "ARREARS",
        "lbl_active_success": "STILL ACTIVE",
        "lbl_arrears_suffix": "Months",
        "lbl_paid_until_short": "Paid until",
        "leg_action": "BILLING ACTION & STATUS GUIDE:",
        "leg_billing_on": "BILLING ON",
        "leg_billing_on_hint": "(System Active & Auto Isolated)",
        "leg_billing_off": "BILLING OFF",
        "leg_billing_off_hint": "(Client Will Not Be Isolated)",
        "leg_free": "FREE / BYPASS",
        "leg_free_hint": "(Stay Active - Promised to Pay)",
        "leg_isolir": "ISOLATED",
        "leg_isolir_hint": "(Connection Disconnected)",
        "leg_pay": "PAY (Input Payment)",
        "leg_pay_hint": "(Input Payment - Double payment allowed for auto-extend)",
        "leg_paid": "PAID",
        "leg_wa_rem": "WHATSAPP",
        "leg_wa_rem_hint": "(Manual Billing Notification)",
        "info_isolate_title": "🛡️ ISOLATE INFO (PPPoE & STATIC IP):",
        "info_isolate_desc": "ISOLATE status temporarily disconnects internet. PPPoE profile changes, Static IP / Radius joins 'ISOLIR' list.",
        "leg_terminal_hint": "Copy & Paste to MikroTik Terminal",
        "info_isolate_req": "Requirement: MikroTik Profile & Address List must be named ISOLIR.",
        "info_isolate_cmd": "FOR STATIC IP & RADIUS: Install this command in MikroTik Terminal for isolation to work:\n/ip firewall filter add chain=forward action=drop src-address-list=ISOLIR comment=\"ISOLIR IP STATIK atau PPPOE RADIUS by nms peycell\" place-before=0",
        "lbl_arrears_months": "Arrears (Mo)",
        "lbl_manual_arrears": "Manual Arrears (Adjustment)",
        "btn_add_manual_arrears": "ADD ARREARS",
        "th_arrears_amount": "Amount",
        "th_arrears_desc": "Description",
        "lbl_choose_client": "Choose Client",
        "lbl_arrears_note": "Note / Description",
        "ph_arrears_amount": "Example: 27000",
        "ph_arrears_desc": "Example: Last month balance / Cable change",
        "msg_confirm_del_arrears": "Delete manual arrears for ",
        "hint_arrears_title": "BILLING CALCULATION INFO:",
        "hint_arrears_calc": "Total Due: (Package Price x Months) + Adjustment. Month labels (Jan, Feb, etc.) help identify the billed period.",
        "hint_arrears_manual": "Manual Adjustment: Use the + ADD ARREARS button for non-subscription costs like cable/router replacements.",
        "hint_arrears_sync": "Synchronization: Updated automatically during system isolation checks.",
        "hint_arrears_negative": "Tips: Use <strong>Minus (-)</strong> for Balance / Overpayment.",
        // Settings Page Title
        "set_page_title": "APPLICATION SETTINGS",
        // HOTSPOT & DYNAMIC EN (MERGED)
        "lbl_online_pill": "ONLINE",
        "lbl_offline_pill": "OFFLINE",
        "lbl_ver_installed": "Installed Version",
        "lbl_ver_latest": "Latest",
        "lbl_isolir_pill": "ISOLATED",
        "msg_waiting_data": "Waiting for data...",
        "msg_saved_ok": "Saved successfully!",
        "alert_saved": "Changes saved!",
        "alert_save_failed": "Failed to save!",
        "msg_set_not_loaded": "Settings data not loaded.",
        "msg_pwd_wrong": "Incorrect Password!",
        "lbl_odp_critical": "CRITICAL ODP (0-1 LEFT)",
        "lbl_no_critical_odp": "No critical ODP found",
        "lbl_port_unit": "Ports",
        "conf_del_item": "Delete this item?",
        "conf_del_stock": "Delete from warehouse?",
        "map_odp_used_by": "This ODP is used by:",
        "map_odp_no_users": "No one is using this ODP yet",
        "err_reset_logs": "Failed to reset logs",
        "card_port": "PORT STATISTICS",
        "lbl_target_server": "Target Server:",
        "hs_ph_time": "Length (e.g. 30d or 12h)",
        "hs_ph_data": "e.g., 1G, 500M",
        "hs_ph_prefix": "e.g., VIP-",
        "hs_ph_comment": "Voucher Name/Note",
        "hs_ph_login_url": "Login template URL",
        "th_username": "Username",
        "th_password": "Password",
        "th_profile": "Profile",
        "th_limit": "Limit",
        "hs_no_users": "No hotspot users found.",
        "hs_no_profiles": "Profiles not found.",
        "hs_confirm_kick": "Kick this active session?",
        "tab_upd": "UPDATE & RESTORE",
        "lbl_on": "ON",
        "lbl_off": "OFF",
        "tab_bk": "BACKUP",
        "tab_tele": "TELEGRAM",
        "lbl_inc_files": "Included Files:",
        "lbl_inc_db": "Database & Config (Topology, Settings, Finance, Config, License)",
        "lbl_inc_web": "Web Interface (HTML Templates & Language Dict)",
        "hint_bk_safe": "Backup includes config.json, settings.json, finance.json and license.key (Full Data is safe).",
        "lbl_bk_hist": "Server Backup History",
        "btn_refresh_bk": "Refresh",
        "hint_tg_desc": "This bot sends notifications when client status changes or backup is complete.",
        "lbl_tg_enable": "Enable Telegram Bot",
        "lbl_tg_token": "Bot Token",
        "lbl_tg_chatid": "Chat ID",
        "lbl_tg_trig": "Notification Triggers",
        "lbl_opt_ind": "Indonesian",
        "lbl_opt_eng": "English (US)",
        "msg_cloud_connecting": "Connecting to Cloud...",
        "msg_fail": "Failed",
        "msg_cloud_fail": "Failed to download from Cloud",
        "msg_backend_fail": "Backend connection failed",
        "msg_pro_locked_menu": "🔒 PRO FEATURE\n\nThis menu is only available in the Licensed version.\nPlease upgrade your license.",
        "msg_wait": "Wait...",
        "tt_online_olt": "OLT (ACTIVE)",
        "tt_ping_local": "Local Ping",
        "msg_confirm_kick": "Warning: Connection will be disconnected (KICK). User will auto-reconnect if router is set to auto-dial. Continue?",
        "msg_confirm_prof": "Change user {user} profile to {prof}?",
        "msg_failed": "Failed",
        "lbl_input_core": "Input to Core:",
        "lbl_parent_src": "Parent Source",
        "lbl_from_port_short": "From Port",
        "ph_port_man": "Type Port Manually (e.g. LAN 1)...",
        "opt_sel_core": "-- Select Core --",
        "msg_sel_parent_first": "-- Select Parent First --",
        "msg_loading": "Loading...",
        "opt_change_prof": "-- Change Profile --",
        "map_btn_dash": "Back to Dashboard",
        "map_title_logout": "Logout",
        "map_title_outage": "Outage History",
        "map_title_backup": "Backup to Telegram",
        "map_title_autoref": "Auto Refresh",
        "map_title_anim": "Toggle Cable Animation",
        "map_type_dark": "DARK",
        "map_type_hybrid": "HYBRID",
        "map_type_clean": "CLEAN",
        "map_lbl_client_list": "CLIENT LIST",
        "map_lbl_on": "ONLINE:",
        "map_lbl_off": "OFFLINE:",
        "map_ph_search": "Search Name/IP...",
        "map_title_show_offline": "Show Offline Only",
        "lbl_db_tools": "DATABASE TOOLS",
        "btn_backup_top": "Backup Topology",
        "btn_restore_top": "Restore Topology",
        "map_title_label": "Label",
        "fab_add_mk": "Add MikroTik (Branch)",
        "fab_add_olt": "Add OLT (Active)",
        "fab_add_odp": "Add ODP",
        "fab_add_client": "Add Client",
        "modal_edit_title": "Edit Device",
        "lbl_choose_mk": "CHOOSE MANAGING MIKROTIK",
        "lbl_mk_login_conf": "MikroTik Login Config",
        "lbl_client_type": "CLIENT TYPE (CONNECTION)",
        "lbl_dev_name": "Device Name",
        "lbl_pos_status": "Position Status",
        "lbl_srv_lan": "LAN Port Count",
        "lbl_srv_sfp": "SFP Port Count",
        "lbl_man_wan": "MANUAL WAN INTERFACE",
        "lbl_ext_ping": "EXTERNAL PING TARGET",
        "lbl_det_status": "Current Detection Status",
        "btn_edit_path": "EDIT PATH (DRAG/PULL)",
        "lbl_odp_type": "ODP Type",
        "lbl_lan_count": "LAN Port Count",
        "lbl_fo_a": "FO A Count",
        "lbl_fo_b": "FO B Count",
        "lbl_tech": "Technology",
        "lbl_pon_out": "PON Output Ports",
        "lbl_uplink_in": "Uplink Input Ports",
        "lbl_slot_out": "Output Slot Count (Drop)",
        "lbl_dist_mode": "Distribution Mode:",
        "lbl_core_cap": "Core Capacity",
        "lbl_uplink_src": "UPLINK SOURCE CONNECTION",
        "lbl_parent": "Parent",
        "lbl_from_port": "From Parent Port (Output)",
        "lbl_cable_color": "Cable Color / Tube",
        "lbl_input_port": "Input to ODP Port",
        "chk_poe_in": "Input Carries PoE?",
        "lbl_ip_man": "IP Address (Manual)",
        "lbl_mon_mode": "MONITORING METHOD",
        "lbl_pppoe_user": "SELECT PPPoE USER",
        "lbl_client_detail": "CLIENT DETAILS (AUTO)",
        "lbl_prof_now": "CURRENT PROFILE",
        "lbl_change_prof": "CHANGE PROFILE",
        "btn_kick": "KICK USER",
        "chk_poe_src": "Client is POE Source?",
        "lbl_wifi_data": "Login & WiFi Data",
        "btn_chat_wa": "CHAT WHATSAPP",
        "btn_remote": "REMOTE ROUTER",
        "lbl_photo_loc": "LOCATION PHOTO / ODP POLE",
        "btn_take_photo": "TAKE / UPLOAD PHOTO",
        "btn_del_dev": "DELETE DEVICE",
        "modal_log_title": "HISTORY LOG",
        "lbl_cable_len": "CABLE LENGTH:",
        "btn_reset_straight": "RESET STRAIGHT",
        "btn_cancel_draw": "CANCEL",
        "btn_save_path": "SAVE PATH",
        "opt_select_server": "-- Select Server --",
        "lbl_main_server": "CENTRAL SERVER",
        "opt_sel_user": "-- Select User --",
        "ph_sel_user": "-- Select/Type User --",
        "msg_failed_save": "Save failed",
        "msg_sec_upd_restart": "Security updated. Restart required.",
        "msg_failed_upd": "Update failed",
        "msg_sel_file_first": "Please select a file first",
        "msg_upload_ok": "Upload Successful",
        "msg_error_upload": "Error during upload",
        "msg_attach_file_first": "Attach a file first before clicking upload.",
        "msg_confirm_restore_smart": "File {name} detected.\n\nClick OK to RESTORE DATABASE (Overwrite old data).\nClick CANCEL for NORMAL UPDATE (Only replace file).",
        "msg_confirm_update_smart": "Continue normal update for file {name}?",
        "msg_confirm_upload_file": "Continue update / upload file {name}?",
        "msg_conn_fail": "Connection Failed/Timeout",
        "conf_del_logo": "Delete logo?",
        "msg_logo_deleted": "Logo deleted",
        "conf_reset_logs": "Reset logs?",
        "msg_logs_cleared": "Logs cleared",
        "msg_sending": "Sending...",
        "msg_backup_sent": "Backup sent!",
        "msg_creating_zip": "Creating Zip...",
        "msg_backup_downloading": "Backup Created & Downloading...",
        "msg_done": "Done",
        "msg_req_error": "Request Error",
        "msg_tele_empty": "Token/Chat ID Empty",
        "lbl_active_tele": "Enable Telegram Bot",
        "msg_backend_fail": "Backend connection failed",
        "msg_load_log_fail": "Failed to load log.",
        "hint_manual_detect": "*Fill in manually if detection is wrong",
        "hint_multi_wan": "*Separate with comma for Multi-WAN. Leave empty for Auto.",
        "hint_ping_target": "*Public IP to check internet connection.",
        "hint_auto_label": "*Auto label: FO A-1, B-1...",
        "hint_ctrl_multi": "*Hold Ctrl to select multiple",
        "ph_search_name_ip": "Search Name / IP / Coordinates...",
        "ph_eg_wan": "Example: ether1,ether2,vlan10",
        "ph_eg_ip": "Example: 8.8.8.8",
        "lbl_dist_mode": "Distribution Mode:",
        "hint_multi_uplink": "Select more than one parent port (Uplink) - Multi-Select.",
        "confirm_logout": "Logout from system?",
        "msg_connecting_cloud": "Connecting to Cloud...",
        "msg_update_success": "Update Successful",
        "lbl_main": "(Main)",
        "msg_vouchers_empty": "No data found!",
        "hs_msg_creating": "⏳ Generating...",
        "hs_msg_success": "✅ Successfully Generated",
        "hs_msg_vouchers": "Vouchers!",
        "hs_confirm_gen": "Generate selected vouchers?",
        "alert_pro_locked": "🔒 PRO FEATURE\n\nUpgrade to Licensed version to access this feature.",
        "pg_lic_title": "License Activation - PEYCELL NMS",
        "lbl_lic_active": "License Active",
        "msg_lic_registered": "This application is officially registered.",
        "lbl_lic_type": "License Type",
        "lbl_lic_owner": "License Owner",
        "lbl_machine_id": "Machine ID",
        "btn_enter_dash": "GO TO DASHBOARD",
        "lbl_lic_activation": "License Activation",
        "msg_lic_locked": "This application is locked and requires an active license.",
        "lbl_your_mid": "Your Machine ID",
        "msg_copy_mid": "Copy the Machine ID above and send it to the Administrator to get a License:",
        "lbl_input_lic": "Enter License Key",
        "ph_lic_key": "Paste license code here...",
        "footer_nms": "PEYCELL NETWORK MANAGEMENT SYSTEM",
        "err_empty_lic": "Please enter license code!",
        "msg_processing": "Processing...",
        "msg_lic_success": "License Activated Successfully!",
        "err_lic_fail": "Invalid License!",
        "err_conn": "Connection failed: ",
        "err_mk_sync": "Failed to fetch MikroTik data",
        "err_invalid_nominal": "Invalid amount!",
        "msg_sync_done": "Sync Complete! {count} data updated.",
        "err_sync": "Sync Failed: ",
        "tt_type": "Type",
        "tt_cable": "Cable",
        "tt_cap": "Capacity",
        "tt_no_packet": "No Package Set",
        "tt_waiting": "Wait...",
        "tt_conn_arp": "Connected (ARP)",
        "tt_conn_netwatch": "Connected (Netwatch)",
        "tt_connected": "Connected",
        "tt_loading_traffic": "Loading Traffic...",
        "tt_ping_local": "Local Ping",
        "msg_no_data": "No data.",
        "msg_sel_prof": "Select profile first",
        "msg_sel_user": "Select PPPoE user first!",
        "msg_invalid_file": "Invalid file! Incorrect data structure.",
        "ph_search_name_ip": "Search Name / IP / Coordinates...",
        "opt_sel_core": "-- Select Core --",
        "opt_sel_parent": "-- Select Parent --",
        "msg_no_parent": "-- NO SUITABLE PARENT FOUND --",
        "msg_sel_parent_first": "-- Select Parent First --",
        "msg_ctrl_multi": "*Hold Ctrl to select multiple",
        "wa_log_err": "Failed to load WA logs.",
        "lbl_bypass_billing": "Free Forever (Bypass Billing)",
        "ph_client_name": "Type client name...",
        "ph_arrears_note": "Example: Last month's balance / Cable replacement",
        "th_purpose": "Purpose",
        "th_status": "Status",
        "lbl_schedule_today": "Notification & Isolation Schedule Today",
        "lbl_today": "Today",
        "lbl_status_sent": "Sent",
        "lbl_status_isolated": "Isolated",
        "lbl_status_waiting": "Waiting",
        "lbl_status_done": "Completed / Paid",
        "msg_loading_schedule": "Loading schedule...",
        "lbl_tpl_auto": "Template: Auto",
        "lbl_tpl_manual": "Template: Manual",
        "lbl_unit_client": "Clients",
        "lbl_unit_schedule": "Schedules",
        "err_no_phone": "WhatsApp number not found for {name}. Please complete it in client data.",
        "msg_no_arrears_rem": "Client {name} has no arrears (has Balance). No need to send reminder.",
        "conf_send_bill": "Send bill Rp {bill} to {name}?",
        "lbl_reason_h3": "Due H-3 Reminder",
        "lbl_reason_eom": "Due Date / Month End",
        "lbl_reason_pre_isolir": "Isolation Warning",
        "lbl_reason_isolir": "Auto Isolation",
        "lbl_reason_manual": "Manual Isolation",
        "conf_mass_wa_billing": "Send WhatsApp billing reminders (End of Month) to ALL clients with arrears? (No Isolation)",
        "lbl_balance_badge": "(BALANCE)",
        "btn_save_change": "SAVE CHANGES",
        "btn_send_now": "SEND NOW",
        "lbl_wa_log": "WhatsApp Logs",
        "lbl_edit_arrears": "Edit Arrears",
        "th_wa": "WhatsApp",
        "msg_client_required": "Client name is required!",
        "btn_edit": "Edit",
        "btn_delete": "Delete",
        "card_bill_conf": "Billing Configuration",
        "lbl_billing_system": "Billing System",
        "opt_billing_monthly": "Monthly (Global)",
        "opt_billing_cyclic": "30 Days (Personal)",
        "opt_billing_fixed": "Fixed Day (Hybrid)",
        "hint_billing_system": "Choose how due dates are calculated.",
        "lbl_fixed_day": "Fixed anniversary day",
        "lbl_due_date": "Due Day of Month",
        "hint_due_date": "The day of the month bills are generated. If the date is not available in that month (e.g. Feb 30th), it will automatically use the last day of that month.",
        "lbl_grace": "Grace Period (Days)",
        "hint_grace": "Extra days before isolation (0 = Instant).",
        "lbl_isolir_prof": "MikroTik Isolation Profile",
        "hint_isolir_prof": "Profile or Address-list name in the router. The system will automatically create it if it doesn't exist.",
        "lbl_enable_isolir": "Enable Auto Isolation",
        "hint_enable_isolir": "If ON, system automatically disconnects overdue users.",
        "lbl_wa_notif": "Send WA Notifications",
        "hint_wa_notif": "Send automatic reminders to client's WhatsApp.",
        "opt_1h": "Every 1 Hour",
        "opt_3h": "Every 3 Hours",
        "opt_6h": "Every 6 Hours",
        "opt_12h": "Every 12 Hours",
        "opt_24h": "Every 24 Hours",
        "lbl_wa_rem_end_month": "End of Month Reminder",
        "hint_wa_rem_end_month": "Send notifications to everyone at month end.",
        "lbl_wa_rem_pre_isolir": "Reminder H-",
        "lbl_days": "Days",
        "hint_wa_rem_pre_isolir": "Send warning X days before isolation.",
        "lbl_wa_notif_time": "Notification Time",
        "hint_wa_notif_time": "Time when system sends daily broadcasts.",
        "msg_server_err": "Server Error",
        "map_ph_search": "Search Name/IP...",
        "map_title_show_offline": "Show Offline Only",
        "lbl_rx": "RX",
        "btn_reset_auto": "Reset to Automatic",
        "lbl_auto": "AUTO",
        "lbl_tx": "TX",
        "lbl_cpu": "CPU",
        "lbl_ping": "PING",
        "lbl_uptime": "Uptime",
        "lbl_used": "Used",
        "lbl_cap": "Capacity",
        "lbl_perc": "Percent",
        "msg_sync_data": "Waiting for data synchronize...",
        "tab_pricing": "Price Master",
        "tab_arrears": "Arrears Report",
        "tab_set": "Configuration",
        "th_paket_name": "Packet Name",
        "th_price": "Price (Rp)",
        "th_name": "Client Name",
        "th_paket": "Packet",
        "th_due_date": "Due Date",
        "th_status": "Status",
        "th_action": "Action",
        "msg_no_price": "No pricing data yet.",
        "fin_title_page": "FINANCIAL & CASH REPORT",
        "fin_income_label": "INCOME (THIS MONTH)",
        "fin_expense_label": "EXPENSE (THIS MONTH)",
        "fin_balance_label": "NET BALANCE",
        "fin_btn_filter": "FILTER",
        "fin_btn_reset": "RESET",
        "fin_btn_add_tx": "RECORD TRANSACTION",
        "fin_btn_excel": "EXPORT CSV",
        "fin_th_date": "DATE",
        "fin_th_type": "TYPE",
        "fin_th_category": "CATEGORY",
        "fin_th_notes": "REMARKS",
        "fin_th_amount": "AMOUNT",
        "fin_th_action": "ACTION",
        "fin_txt_loading": "Loading data...",
        "fin_h_archive": "MONTHLY REPORT ARCHIVE",
        "fin_txt_no_archive": "No previous monthly reports found.",
        "modal_tx_title": "Record New Transaction",
        "lbl_tx_type": "Transaction Type",
        "opt_income": "Income (+)",
        "msg_no_mk_configured": "No MikroTik configured.",
        "lbl_detecting": "Detecting...",
        "btn_login": "LOGIN",
        "ph_password": "Password...",
        "ph_user_alphanumeric": "Username (alphanumeric)",
        "hs_time_hint": "Format: 1d (day), 1h (hour), 30m (minute).",
        "opt_expense": "Expense (-)",
        "lbl_tx_client": "Client Name (Auto Unlock)",
        "hint_tx_client": "Automatically unlock if client is selected. (PPPoE Only).",
        "lbl_tx_cat": "Category",
        "lbl_tx_amount": "Amount (Rp)",
        "lbl_tx_note": "Notes",
        "ph_date_range": "Date (1-31)",
        "btn_cancel": "CANCEL",
        "btn_save": "SAVE",
        "fin_alert_nominal": "Amount must be greater than 0",
        "fin_err_save": "Failed to save transaction:",
        "fin_in_pill": "INCOME",
        "fin_out_pill": "EXPENSE",
        "fin_report_btn": "Report",
        "fin_csv_header": "DATE,TYPE,CATEGORY,NOTES,AMOUNT,USER",
        "fin_confirm_del": "Delete this transaction?",
        "fin_export_empty": "No data to export",
        // ABOUT PAGE
        "pg_about_title": "ABOUT SYSTEM",
        "lbl_sys_info": "SYSTEM INFORMATION",
        "lbl_version": "App Version",
        "lbl_release_date": "Release Date",
        "lbl_copyright": "Copyright",
        "lbl_dev_support": "Developer Support",
        "lbl_dev_web": "Website",
        "lbl_license_to": "Contact",
        "lbl_system_desc": "This platform was specifically developed to facilitate monitoring of RT/RW Net networks. Equipped with live map features, financial and billing management, and real-time outage notifications.",
        "lbl_donate_title": "SUPPORT & DONATION",
        "lbl_donate_desc": "Scan the QRIS below for development donations or official license payments.",
        "msg_integrity_error": "CRITICAL WARNING: Original script components (QRIS/License) have been modified or deleted. Please restore the original source code to continue.",
        "lbl_smart_upd": "Smart Upload (Update / Restore)",
        "lbl_no_photo": "No photo yet",
        "lbl_compressing": "Compressing...",
        "lbl_uploading": "Uploading...",
        "lbl_upload_fail": "Upload failed",
        "lbl_upload_err": "Upload error",
        "hint_smart_upd": "Upload .zip, .js, .html, .json, .py, .ico files. System will auto-detect target.",
        "lbl_sys_ctrl": "System Control",
        "lbl_ota_cloud": "UPDATE FROM CLOUD",
        "hint_ota_cloud": "Click button below to check and install system updates directly from central server (Cloud).",
        "msg_upd_success": "UPDATE SUCCESSFUL!",
        "msg_upd_latest": "Your NMS system is already the latest version",
        "msg_upd_restart": "App is restarting, please wait 5-10 seconds.",
        "msg_upd_fail": "Update Failed: ",
        "msg_restore_success": "DATABASE RESTORED SUCCESSFULLY!",
        "warn_title": "IMPORTANT:",
        "warn_p1": "After a successful cloud update, it is mandatory to click the restart button.",
        "warn_p2": "If uploading a database file (.db/.json/.zip), old data will be overwritten. Ensure correct file format before clicking Upload.",
        "warn_p3": "Always perform data backups regularly or before making major changes to the system.",
        "warn_p4": "Please contact me directly if you encounter any issues or problems after the update.",
        "btn_bk_now": "BACKUP NOW (DOWNLOAD)",
        "fin_desc_page": "Monitor cash flow, income, expenses, and monthly report archives in real-time.",
        "btn_convert_now": "CONVERT NOW",
        "lbl_mig_title": "V2.9 MIGRATION TOOL (JSON TO SQLITE)",
        "hint_mig_desc": "Use this tool if you are upgrading from V2.9. Upload the old topology.json file to automatically convert it to an SQLite database.",
        "msg_sel_mig_file": "Please select the topology.json file first!",
        "msg_mig_confirm": "Conversion will overwrite current topology data. Continue?",
        "msg_mig_process": "Processing migration...",
        "err_wa_wake": "Failed to wake up the gateway.",
        "conf_wa_reset": "Delete WhatsApp session? You will need to re-scan later.",
        "conf_wa_clear_log": "Delete all WhatsApp activity logs?",
        "msg_wa_del_err": "Deletion failed: ",
        "lbl_tele_alert": "This bot sends notifications when client status changes or backup is complete.",
        "lbl_tele_trigger": "Notification Trigger",
        "hint_tele_chat": "IMPORTANT: Make sure you have started a conversation with the Bot (/start) so that notifications can be received.",
        "msg_bk_empty": "No backup history yet.",
        "ph_amount": "Example: 25000",
        "ph_test_user": "PPPoE Username",
        "ph_date_range": "Date (1-31)",
        "ph_zero": "Example: 0",
        "ph_isolir_prof": "Example: ISOLIR",
        "ph_web_title": "MAPS MONITORING WIFI",
        "ph_svc_name": "monitoring-wifi.service",
        "ph_port": "5002",
        "ph_bot_token": "123456:ABC...",
        "ph_chat_id": "-100123456789",
        "msg_no_data": "No data available.",
        "msg_wa_check": "Checking status...",
        "lbl_wa_status_offline": "DISCONNECTED",
        "lbl_wa_log": "WhatsApp Logs",
        "btn_wa_clear_log": "CLEAR LOGS",
        "lbl_wa_pair_title": "Or Link via Phone Number",
        "ph_wa_pair": "Example: 628123456789",
        "btn_wa_pair": "Get Code",
        "msg_wa_log_waiting": "Waiting for log data...",
        "lbl_tpl_vars": "Use {name}, {amount}, {month}, {expired}, {x} for dynamic variables.",
        "hs_ip_address": "IP Address",
        "th_user": "User",
        // LOGS (EN)
        "log_wa_start": "START: Mode={mode}",
        "log_wa_shutdown": "SHUTDOWN: Service stopped (Code: {code})",
        "log_wa_info_start": "INFO: Service started successfully (PID: {pid})",
        "log_wa_timeout": "[STATUS] Timeout: No pairing activity for 3 minutes. Shutting down service...",
        "log_wa_qr_scan": "[QR] Please scan the QR Code shown in the terminal or UI.",
        "log_wa_conn_fail": "[STATUS] Connection disconnected. Code: {code}",
        "log_wa_session_out": "[STATUS] Session terminated (Logged Out).",
        "log_wa_connected": "[STATUS] Connected to WhatsApp!",
        "log_wa_processing": "[STATUS] Processing {count} message queues...",
        "log_wa_waiting": "[WAIT] Waiting 30 seconds before next message...",
        "log_wa_queue_fail": "[ERROR] Failed to process queue file: {msg}",
        "log_wa_all_done": "[STATUS] All tasks completed. Shutting down service...",
        "log_wa_empty_req": "[ERROR] Destination number or message content is empty.",
        "log_wa_sending": "[SEND] Sending to {target}...",
        "log_wa_success_img": "[SUCCESS] Image + Message sent to {target}",
        "log_wa_success_txt": "[SUCCESS] Text message sent to {target}",
        "log_wa_failed": "[FAILED] Failed to send to {target}: {msg}",
        "log_wa_node_missing": "ERROR: Node.js not found on server. Please ensure Node.js is installed.",
        "log_wa_nm_missing": "ERROR: Folder 'node_modules' missing. Run 'npm install' in the app folder.",
        "log_wa_critical": "CRITICAL: Script crashed unexpectedly ({code}). Error: {msg}",
        "log_wa_exception": "EXCEPTION: {msg}",
        "lbl_pass_admin": "Administrator Password",
        "lbl_pass_view": "Viewer Password",
        "ph_pass_new": "New Password...",
        "lbl_svc_name": "Service Name (Systemd)",
        "lbl_port": "App Port",
        "hint_svc": "*Default: monitoring-wifi.service",
        "hint_port": "*Default: 5002. Requires restart to take effect.",
        "warn_sec": "Warning: Changing Port or Service will trigger an automatic server restart.",
        "btn_upd_sec": "UPDATE SECURITY & SYSTEM",
        "lbl_login_activity": "Login Activity",
        "hint_login_activity": "Brute-force protection active. IP auto-blocked after 5 failed login attempts.",
        "lbl_active_sessions": "active sessions now",
        "lbl_blocked_ips": "Blocked IPs",
        "lbl_min_remaining": "min remaining",
        "th_login_time": "Time",
        "th_login_ip": "IP Address",
        "th_login_device": "Device",
        "th_login_role": "Role",
        "th_login_status": "Status",
        "lbl_login_success": "Success",
        "lbl_login_failed": "Failed",
        "lbl_login_blocked": "Blocked",
        "msg_no_login_log": "No login history yet.",
        "btn_ota_drive": "CHECK CLOUD UPDATE",
        "lbl_mig_title": "Data Migration (V2.9 -> V3.0)",
        "hint_mig_desc": "Use this tool to migrate from V2.9. Upload your legacy topology.json file to automatically convert it to a SQLite database.",
        "btn_convert_now": "START MIGRATION",
        "btn_restart": "RESTART SERVICE",
        "hint_restart": "*Use if system feels slow or you manually updated .py files.",
        "btn_reprint": "Reprint Receipt",
        "conf_del_data": "Delete this data permanently?",
        "conf_irrevocable": "This action cannot be undone. Continue?",
        "conf_isolate": "Isolate this client?",
        "conf_system_restart": "Restart system?",
        "csv_client_name": "Client Name",
        "csv_id": "Customer ID",
        "csv_ip": "IP Address",
        "csv_packet": "Package",
        "csv_parent": "Parent",
        "csv_status": "Status",
        "csv_coords": "Coordinates",
        "csv_wa": "WhatsApp",
        "csv_paid_until": "Paid Until",
        "lbl_var_store_name_desc": "Store / Business Name",
        "lbl_var_header_desc": "Print Header Text",
        "lbl_var_footer_desc": "Print Footer Text",
        "lbl_var_date_desc": "Transaction Date",

        "lbl_print_info_title": "PRINT METHOD GUIDE",
        "lbl_wa_vars_title": "MESSAGE VARIABLE GUIDE",
        "err_bypass": "Failed to bypass billing.",
        "err_login": "Login failed. Check password.",
        "err_session": "Session expired.",
        "fin_balance_title": "Net Balance / Profit",
        "fin_expense_title": "Expense (This Month)",
        "fin_income_title": "Income (This Month)",
        "fin_th_user": "User",
        "hint_ext_ping": "External target to monitor internet health (e.g. 8.8.8.8).",
        "hint_manual_num": "Enter custom number if it doesn't match MikroTik.",
        "hint_tpl_pay_fmt": "Format: *Bold*, _Italic_, ~Strikethrough~, ```Monospace```",
        "lbl_api_pass": "API Password",
        "lbl_api_port": "API Port",
        "lbl_api_user": "API Username",
        "lbl_donate_lynk": "DONATE VIA LYNK.ID",
        "lbl_host": "Host / IP",
        "lbl_ip_addr": "IP Address",
        "lbl_mon_logs": "MONITORING & LOGS",
        "lbl_multi_uplink": "Multi-Uplink Source",
        "lbl_pkt_man": "Package Name (Manual)",
        "lbl_rtr_pass": "Router Password",
        "lbl_rtr_user": "Router Username",
        "lbl_tpl_reactivate": "Reactivation Message Template",
        "lbl_traffic_mon": "Traffic Monitor",
        "lbl_uptime_server": "SERVER UPTIME",
        "lbl_wa_num": "WhatsApp Number",
        "lbl_wifi_pass": "WiFi Password",
        "lbl_wifi_ssid": "WiFi SSID",
        "leg_billing_off_desc": "Billing Disabled",
        "leg_billing_on_desc": "Billing Active",
        "leg_free_desc": "Free / Bypassed",
        "login_title": "NETWORK MANAGEMENT SYSTEM",
        "modal_title_add_arrears": "Add Arrears Adjustment",
        "modal_title_edit_arrears": "Edit Arrears Adjustment",
        "msg_auto_activate": "Client re-activated automatically.",
        "msg_isolate_success": "Client isolated successfully.",
        "msg_nominal_required": "Amount must be filled!",
        "msg_ota_drive_confirm": "Start Cloud Update from server pusat?",
        "msg_select_client_first": "Select a client first!",
        "opt_odp_htb": "HTB / Converter",
        "opt_odp_jb": "Joint Box",
        "opt_odp_olt": "ODP / Splitter",
        "opt_pppoe": "PPPoE Mode",
        "opt_stat_ip": "Static IP Mode",
        "ph_pass": "Password...",
        "hs_confirm_gen": "Generate selected vouchers?",
        "hs_confirm_del": "Delete {count} selected vouchers?",
        "hs_confirm_del_user": "Delete voucher {name}?",
        "hs_confirm_del_prof": "Delete profile {name}?",
        "hs_msg_del_success": "✅ {count} vouchers deleted successfully.",
        "msg_sel_vouchers": "⚠️ Please select vouchers first!",

        // BROADCAST
        "bc_title": "WHATSAPP BROADCAST",
        "bc_subtitle": "Announce network maintenance, technical repairs, or other important info in bulk to clients.",
        "bc_msg_label": "Message Content",
        "bc_ph_msg": "Write your message here...",
        "bc_target_label": "Target Recipients",
        "bc_mode_all": "All Clients",
        "bc_mode_odp": "By ODP",
        "bc_mode_type": "By Service Type",
        "bc_mode_unpaid": "Unpaid (Arrears)",
        "bc_mode_custom": "Custom Input (Manual)",
        "bc_sel_odp": "Select ODP (Multi-select)",
        "bc_sel_type": "Select Service Type",
        "bc_custom_name": "Name (Optional)",
        "bc_custom_wa": "WhatsApp Number (628...)",
        "bc_btn_send": "START BROADCAST 🚀",
        "bc_btn_stop": "STOP QUEUE 🛑",
        "bc_btn_retry": "RETRY FAILED 🔄",
        "bc_label_est": "Target Estimate:",
        "bc_label_prog": "Sending Progress:",
        "bc_label_status": "Current Status",
        "bc_th_no": "No",
        "bc_th_name": "Client Name",
        "bc_th_wa": "WA Number",
        "bc_th_status": "Status",
        "bc_th_action": "Action",
        "bc_warn_title": "WARNING:",
        "bc_warn_reload": "Do not reload or close this page while the delivery process is in progress to avoid interruption.",
        "bc_warn_banned": "Broadcasting to many numbers at once poses a risk of your WhatsApp number being blocked (banned) by the WhatsApp system.",
        "bc_warn_not_resp": "We are not responsible for any number blocking that occurs due to the use of this feature.",
        "bc_warn_safety": "Use wisely, the system sends messages with a 30-second delay for each subsequent number for the safety of your account.",
        "bc_confirm_del": "Remove recipient from list?",
        "bc_status_wait": "Waiting",
        "bc_status_proc": "Processing...",
        "bc_status_sent": "Sent",
        "bc_status_fail": "Failed",
        "bc_log_title": "BROADCAST ACTIVITY LOG",
        "bc_excel_tpl": "DOWNLOAD EXCEL TEMPLATE",
        "bc_excel_upload": "UPLOAD EXCEL",
        "bc_img_label": "Image Attachment (Optional)",
        "bc_var_hint": "Click to insert variable:",
        "bc_conf_send": "Are you sure you want to start broadcast to {count} targets? 30s delay per message will be applied.",
        "bc_conf_stop": "Stop remaining broadcast queue?",
        "bc_msg_stopped": "Broadcast stopped.",
        "bc_msg_finished": "Broadcast finished!",
        "bc_msg_no_target": "No targets found.",
        "bc_img_hint": "JPG/PNG Max 2MB",
        "bc_btn_add_custom": "+ ADD TO LIST",
        "bc_btn_clear_list": "Clear List",
        "bc_log_ready": "[READY] Waiting for command...",
        "bc_no_odp": "No ODP found.",
        "bc_no_target_data": "No target data.",
        "bc_img_max_size": "Image size max 2MB!",
        "bc_err_no_target": "No target recipients!",
        "bc_err_no_msg": "Message cannot be empty!",
        "bc_conf_title": "Confirm Broadcast",
        "bc_conf_send_text": "Send message to {count} targets? 30s delay between messages will be applied.",
        "bc_btn_cancel": "Cancel",
        "bc_btn_confirm": "Yes, Start!",
        "bc_log_start": "[START] Sending to {count} targets...",
        "bc_err_start_fail": "Failed to start broadcast",
        "bc_err_conn": "Failed to connect to server.",
        "bc_conf_stop_title": "Stop Broadcast?",
        "bc_conf_stop_text": "Remaining queue will be cleared.",
        "bc_log_stopped": "[STOPPED] Broadcast stopped by user.",
        "bc_conf_clear": "Clear all recipient list and reset session?",
        "bc_log_cleared": "[READY] List and session cleared...",
        "bc_msg_cleared": "List and session have been cleared",
        "bc_err_server": "Failed to contact server",
        "bc_lbl_success": "Success",
        "bc_lbl_failed": "Failed",
        "bc_lbl_error": "Error",
        "bc_wa_status_connected": "WA: CONNECTED",
        "bc_wa_status_pairing": "WA: PAIRING...",
        "bc_wa_status_disconnected": "WA: DISCONNECTED",
        "bc_wa_status_checking": "WA: CHECKING...",
        "bc_wa_modal_title": "WhatsApp Gateway",
        "bc_wa_modal_checking": "Checking WhatsApp status...",
        "bc_wa_modal_hint_connected": "Your WhatsApp is active and ready to send messages.",
        "bc_wa_modal_hint_pairing": "Open WhatsApp on your phone > Linked Devices > Link a Device, then scan the QR code above.",
        "bc_wa_modal_hint_disconnected": "Click the \"Connect\" button below to activate the WhatsApp gateway.",
        "bc_wa_btn_connect": "Connect",
        "bc_wa_btn_retry": "Retry Failed",
        "bc_wa_retry_confirm_title": "Retry Failed?",
        "bc_wa_retry_confirm_text": "The system will resend messages to failed numbers in this session only.",
        "bc_wa_retry_success": "Resending started",
        "bc_wa_retry_error": "Failed to trigger retry",
        "bc_wa_retry_conn_error": "Connection error when triggering retry"
    }

};

// --- SIDEBAR MINIMIZER LOGIC ---
function toggleMiniSidebar() {
    var body = document.body;
    var isMini = body.classList.toggle('sidebar-minimized');
    localStorage.setItem('nms_sidebar_mini', isMini ? '1' : '0');

    // Update toggle icon state
    document.querySelectorAll('.btn-sidebar-toggle i, #btnToggle i').forEach(function (icon) {
        icon.className = isMini ? 'fas fa-book' : 'fas fa-bars';
    });
}

function restoreSidebarState() {
    var savedState = localStorage.getItem('nms_sidebar_mini');
    if (savedState === null) {
        if (window.innerWidth > 768 && window.innerWidth <= 1024) {
            savedState = '1';
        } else {
            savedState = '0';
        }
    }
    // Safety check for mobile: never minimize on mobile screens (width <= 768px)
    if (window.innerWidth <= 768) {
        document.body.classList.remove('sidebar-minimized');
        document.querySelectorAll('.btn-sidebar-toggle i, #btnToggle i').forEach(function (icon) {
            icon.className = 'fas fa-bars';
        });
        return;
    }
    if (savedState === '1' || savedState === 'true') {
        document.body.classList.add('sidebar-minimized');
        document.querySelectorAll('.btn-sidebar-toggle i, #btnToggle i').forEach(function (icon) {
            icon.className = 'fas fa-book';
        });
    } else {
        document.body.classList.remove('sidebar-minimized');
        document.querySelectorAll('.btn-sidebar-toggle i, #btnToggle i').forEach(function (icon) {
            icon.className = 'fas fa-bars';
        });
    }
}

// Restore state as early as possible
if (document.body) {
    restoreSidebarState();
} else {
    document.addEventListener('DOMContentLoaded', restoreSidebarState);
}


// Anti-flicker mechanism: Hide content until localization is ready
function initAntiFlicker() {
    if (!document.getElementById('anti-flicker-style')) {
        const style = document.createElement('style');
        style.id = 'anti-flicker-style';
        style.innerHTML = 'body { visibility: hidden !important; opacity: 0 !important; }';
        document.head.appendChild(style);
    }

    try {
        var role = localStorage.getItem('nms_role');
        var path = window.location.pathname;
        var perms = {};
        try {
            perms = JSON.parse(localStorage.getItem('nms_permissions') || '{}');
        } catch (e) { }

        // 1. Redirect if user accesses a page without permission
        if (role === 'viewer') {
            if (path === '/settings' || path === '/billing' || path === '/finance' || path === '/broadcast') {
                window.location.replace('/maps');
                return;
            }
        } else if (role === 'custom') {
            if (path === '/settings') {
                window.location.replace('/');
                return;
            }
            var page_permissions = {
                '/billing': 'billing',
                '/finance': 'finance',
                '/broadcast': 'broadcast',
                '/client': 'client',
                '/pppoe': 'pppoe',
                '/hotspot': 'hotspot',
                '/network': 'network',
                '/monitor': 'monitor',
                '/maps': 'maps'
            };
            if (page_permissions[path] && !perms[page_permissions[path]]) {
                window.location.replace('/');
                return;
            }
            if (path === '/' && !perms.dashboard) {
                // If dashboard is disabled, redirect to maps or first allowed page
                if (perms.maps) { window.location.replace('/maps'); return; }
                var allowed_pages = ['client', 'pppoe', 'hotspot', 'network', 'monitor'];
                for (var i = 0; i < allowed_pages.length; i++) {
                    var p = allowed_pages[i];
                    if (perms[p]) { window.location.replace('/' + p); return; }
                }
                window.location.replace('/maps'); // Fallback
                return;
            }
        }

        // 2. Dynamically inject CSS styles to hide sidebar items instantly without flicker
        if (role === 'viewer' || role === 'custom') {
            var css = '';

            // Helper function to solve CSS specificity conflicts for minimized sidebars
            function hideMenu(selector) {
                return selector.split(',').map(function (sel) {
                    var s = sel.trim();
                    return s + ', body.sidebar-minimized .sidebar ' + s;
                }).join(', ') + ' { display: none !important; } ';
            }

            if (role === 'viewer') {
                css += hideMenu('.menu-item[href="/billing"], .menu-item[href="/finance"], .menu-item[href="/settings"], .menu-item[href="/broadcast"]');
                css += '.menu-label:nth-of-type(2) { display: none !important; }'; // Hide Admin header
            } else {
                if (!perms.dashboard) css += hideMenu('.menu-item[href="/"], .menu-item[onclick*="reload"]');
                if (!perms.maps) css += hideMenu('.menu-item[href="/maps"]');
                if (!perms.client) css += hideMenu('.menu-item[href="/client"]');
                if (!perms.pppoe) css += hideMenu('.menu-item[href="/pppoe"]');
                if (!perms.hotspot) css += hideMenu('.menu-item[href="/hotspot"]');
                if (!perms.network) css += hideMenu('.menu-item[href="/network"], .menu-item[href*="infra"]');
                if (!perms.billing) css += hideMenu('.menu-item[href="/billing"]');
                if (!perms.finance) css += hideMenu('.menu-item[href="/finance"]');
                if (!perms.broadcast) css += hideMenu('.menu-item[href="/broadcast"]');
                if (!perms.monitor) css += hideMenu('.menu-item[href*="monitor"], .menu-item[href*="traffic"], .menu-item[href*="logs"]');
                css += hideMenu('.menu-item[href="/settings"]');
            }

            // Also hide "Back to Dashboard" or similar home button references if dashboard is disabled
            if (role === 'custom' && !perms.dashboard) {
                css += 'a[href="/"].btn, a[href="/"].btn-primary, .btn-home, a[href="/"] i.fa-home { display: none !important; }';
            }

            // Hide billing details in maps if the user does not have billing permission
            if (role === 'custom' && !perms.billing) {
                css += '.map-billing-info, .billing-info-box, .btn-billing-detail, .node-billing-status { display: none !important; }';
            }
            if (role === 'custom' && !perms.client) {
                css += '.btn-client-edit, .btn-edit-client { display: none !important; }';
            }

            var styleEl = document.getElementById('nms-sidebar-perm-style');
            if (!styleEl) {
                styleEl = document.createElement('style');
                styleEl.id = 'nms-sidebar-perm-style';
                document.head.appendChild(styleEl);
            }
            styleEl.innerHTML = css;
        }
    } catch (err) {
        console.error("[RBAC] Error enforcing permissions in head:", err);
    }
}

function removeAntiFlicker() {
    const style = document.getElementById('anti-flicker-style');
    if (style) {
        style.remove();
        // Optional: fade in effect
        document.body.style.transition = 'opacity 0.2s ease-in';
        document.body.style.opacity = '1';
        document.body.style.visibility = 'visible';
    }
}

// Global translation function
function t(key) {
    const lang = localStorage.getItem('nms_lang') || 'id';
    if (LANG_DICT[lang] && LANG_DICT[lang][key]) {
        return LANG_DICT[lang][key];
    }
    return LANG_DICT['id'][key] || key; // Fallback to ID or key itself
}

function modernizeSidebarIcons(container = document) {
    container.querySelectorAll('.sidebar .menu-item, .sidebar .menu-danger').forEach(el => {
        const href = el.getAttribute('href');
        const icon = el.querySelector('i');
        if (icon && href) {
            if (href === '/') {
                // Modernize Dashboard icon
                icon.className = 'fas fa-th-large me-2';
            } else if (href === '/network?tab=infra') {
                // Distinguish Infra icon from PPPoE
                icon.className = 'fas fa-sitemap me-2';
            }
        }
    });
}

function applyLanguage(container = document) {
    // Check if called as an event listener (where first arg is an Event object)
    if (container instanceof Event || !container || typeof container.querySelectorAll !== 'function') {
        container = document;
    }

    try {
        // Modernize icons on the fly
        modernizeSidebarIcons(container);

        const lang = localStorage.getItem('nms_lang') || 'id';
        const dict = LANG_DICT[lang] || LANG_DICT['id'];
        console.log('[LANG] Applying:', lang, 'to', container === document ? 'document' : 'container');

        // 1. Update all elements with data-lang attribute
        var count = 0;
        container.querySelectorAll('[data-lang]').forEach(el => {
            const key = el.getAttribute('data-lang');
            if (dict[key]) {
                count++;
                // Check if specific target attribute is requested
                var targetAttr = el.getAttribute('data-lang-target');
                if (targetAttr) {
                    if (targetAttr === 'innerHTML') el.innerHTML = dict[key];
                    else el.setAttribute(targetAttr, dict[key]);
                    return;
                }

                if (el.tagName === 'INPUT' && el.getAttribute('placeholder')) {
                    el.placeholder = dict[key];
                }
                else if (el.tagName === 'OPTION') {
                    el.textContent = dict[key];
                }
                else {
                    // ICON PRESERVATION LOGIC
                    // If element has an <i> or <span> icon, keep it.
                    var icon = el.querySelector('i, span.fas, span.far, span.fab');
                    if (icon) {
                        var iconHtml = icon.outerHTML;
                        // Use innerHTML to preserve the icon tag, then add the text
                        el.innerHTML = iconHtml + ' ' + dict[key];
                    } else {
                        el.innerText = dict[key];
                    }
                }
            }
        });
        console.log('[LANG] Done. Updated', count, 'elements.');

        // 2. Specialized replacements (Title & Brand)
        var customTitle = localStorage.getItem('nms_web_title');
        // Try to get from global APP.settings if available
        if (typeof APP !== 'undefined' && APP.settings && APP.settings.web_title) {
            customTitle = APP.settings.web_title;
            // Sync to localStorage for next load
            localStorage.setItem('nms_web_title', customTitle);
        }

        var brand = customTitle || dict['sb_brand'] || 'MAPS MONITORING WIFI';

        // Update Brand in Sidebar if exists
        if (customTitle) {
            // Target BOTH old .brand and new .brand-text / mobile-brand / map brand
            document.querySelectorAll('.brand, .brand-text, #brandText, .mobile-brand, #mobileBrandText, #sb-brand').forEach(brandEl => {
                brandEl.innerText = customTitle;
            });
        }

        // 3. Specialized replacements (License Badge)
        var isLicensed = localStorage.getItem('nms_is_licensed') === 'true';
        if (isLicensed) {
            var b = document.getElementById('licBadge');
            if (b) {
                b.innerHTML = '<i class="fas fa-check-circle me-1"></i> LICENSED (PRO)';
                b.style.background = 'rgba(16, 185, 129, 0.1)';
                b.style.color = '#10b981';
                b.style.borderColor = 'rgba(16, 185, 129, 0.2)';
                b.href = '/license';
                b.style.cursor = 'pointer';
            }
        }

        const disp = document.getElementById('currentLangDisplay');
        if (disp) disp.innerText = lang.toUpperCase();

        var pageKey = document.body.getAttribute('data-page-key');
        if (pageKey && dict[pageKey]) {
            // Format: [Page Name] - [Web Title]
            document.title = (dict[pageKey] + ' - ' + brand).toUpperCase();
        } else {
            document.title = brand.toUpperCase();
        }
    } catch (e) {
        console.error('[LANG] Error applying language:', e);
    } finally {
        // Always remove anti-flicker to prevent black screen
        removeAntiFlicker();
    }
}

console.log('LANG_DICT v5 loaded (RE-VERIFIED 13:25)');




// Auto-apply language on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyLanguage);
} else {
    // DOM already loaded, apply immediately
    applyLanguage();
}


/**
 * GLOBAL NOTIFICATION ENGINE (TOP-RIGHT TOASTS)
 * Polling /api/logs every 10 seconds to detect Online/Offline events.
 */
(function () {
    const NMS_CONFIG = {
        pollingInterval: 10000,
        toastDuration: 5000,
        batchThreshold: 3, // Summarize if > 3 events
        lastLogKey: 'nms_last_log_time'
    };

    function injectToastCSS() {
        if (document.getElementById('nms-global-toast-styles')) return;
        const style = document.createElement('style');
        style.id = 'nms-global-toast-styles';
        style.innerHTML = `
            .nms-toast-container {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 99999;
                display: flex;
                flex-direction: column;
                gap: 12px;
                pointer-events: none;
            }
            .nms-toast {
                min-width: 280px;
                max-width: 350px;
                padding: 16px 20px;
                border-radius: 12px;
                background: #1e293b;
                color: #f8fafc;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                border-left: 5px solid #3b82f6;
                display: flex;
                align-items: center;
                gap: 15px;
                pointer-events: auto;
                cursor: pointer;
                animation: nmsToastSlideIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
                transition: all 0.3s ease;
                font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            }
            .nms-toast:hover {
                transform: translateX(-5px);
            }
            .nms-toast.online, .nms-toast.mass-up { border-left-color: #22c55e; }
            .nms-toast.offline, .nms-toast.mass-down { border-left-color: #ef4444; }
            .nms-toast.mass-mixed { border-left-color: #f59e0b; }
            
            .nms-toast-icon {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                flex-shrink: 0;
            }
            .nms-toast.online .nms-toast-icon, .nms-toast.mass-up .nms-toast-icon { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
            .nms-toast.offline .nms-toast-icon, .nms-toast.mass-down .nms-toast-icon { background: rgba(239, 68, 68, 0.15); color: #ef4444; }
            .nms-toast.mass-mixed .nms-toast-icon { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
            
            .nms-toast-content { flex-grow: 1; }
            .nms-toast-title { font-weight: 700; font-size: 14px; margin-bottom: 2px; }
            .nms-toast-msg { font-size: 13px; color: #94a3b8; line-height: 1.4; }
            
            .nms-toast-closing {
                animation: nmsToastSlideOut 0.4s ease forwards;
            }
            
            @keyframes nmsToastSlideIn {
                from { opacity: 0; transform: translateX(100%) scale(0.9); }
                to { opacity: 1; transform: translateX(0) scale(1); }
            }
            @keyframes nmsToastSlideOut {
                from { opacity: 1; transform: translateX(0); }
                to { opacity: 0; transform: translateX(100%); }
            }
        `;
        document.head.appendChild(style);
    }

    function createToastContainer() {
        injectToastCSS();
        // UNIFICATION FIX: Use existing #toast-container if present (e.g. in client.html/settings.html)
        let container = document.getElementById('toast-container') || document.querySelector('.nms-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'nms-toast-container';
            document.body.appendChild(container);
        }
        return container;
    }

    function showToast(name, status, message) {
        const container = createToastContainer();
        const toast = document.createElement('div');
        toast.className = `nms-toast ${status}`;

        const isOnline = status === 'online';
        const iconClass = isOnline ? 'fa-circle-check' : 'fa-circle-exclamation';
        const titleText = isOnline ? (localStorage.getItem('nms_lang') === 'en' ? 'CLIENT ONLINE' : 'KLIEN ONLINE') :
            (localStorage.getItem('nms_lang') === 'en' ? 'CLIENT OFFLINE' : 'KLIEN OFFLINE');

        toast.innerHTML = `
            <div class="nms-toast-icon"><i class="fas ${iconClass}"></i></div>
            <div class="nms-toast-content">
                <div class="nms-toast-title">${titleText}</div>
                <div class="nms-toast-msg"><strong>${name}</strong>: ${message}</div>
            </div>
        `;

        toast.onclick = () => {
            toast.classList.add('nms-toast-closing');
            setTimeout(() => toast.remove(), 400);
        };

        container.appendChild(toast);

        // Auto remove
        setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('nms-toast-closing');
                setTimeout(() => toast.remove(), 400);
            }
        }, NMS_CONFIG.toastDuration);
    }

    function showMassToast(upCount, downCount) {
        const container = createToastContainer();
        const toast = document.createElement('div');

        let status = 'mass-mixed';
        let icon = 'fa-layer-group';
        let title = localStorage.getItem('nms_lang') === 'en' ? 'MASS STATUS CHANGE' : 'PERUBAHAN MASSAL';

        if (upCount > 0 && downCount === 0) {
            status = 'mass-up';
            icon = 'fa-circle-arrow-up';
            title = localStorage.getItem('nms_lang') === 'en' ? 'MASS RECONNECTION' : 'REAKTIVASI MASSAL';
        } else if (downCount > 0 && upCount === 0) {
            status = 'mass-down';
            icon = 'fa-circle-arrow-down';
            title = localStorage.getItem('nms_lang') === 'en' ? 'MASS OUTAGE' : 'GANGGUAN MASSAL';
        }

        toast.className = `nms-toast ${status}`;

        let msg = "";
        if (localStorage.getItem('nms_lang') === 'en') {
            if (upCount > 0) msg += `<strong>${upCount}</strong> Clients Online. `;
            if (downCount > 0) msg += `<strong>${downCount}</strong> Clients Offline.`;
        } else {
            if (upCount > 0) msg += `<strong>${upCount}</strong> Klien Online. `;
            if (downCount > 0) msg += `<strong>${downCount}</strong> Klien Terputus (Offline).`;
        }

        toast.innerHTML = `
            <div class="nms-toast-icon"><i class="fas ${icon}"></i></div>
            <div class="nms-toast-content">
                <div class="nms-toast-title">${title}</div>
                <div class="nms-toast-msg">${msg}</div>
            </div>
        `;

        toast.onclick = () => {
            toast.classList.add('nms-toast-closing');
            setTimeout(() => toast.remove(), 400);
        };

        container.appendChild(toast);
        setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('nms-toast-closing');
                setTimeout(() => toast.remove(), 400);
            }
        }, NMS_CONFIG.toastDuration + 2000); // Mass alerts last 2s longer
    }

    const seenMessages = new Map(); // Cache to prevent duplicate toasts in short time

    async function checkLogs() {
        try {
            const pass = localStorage.getItem('nms_auth_session');
            if (!pass) return;

            const response = await fetch('/api/logs', {
                headers: { 'X-Auth-Token': pass }
            });
            if (!response.ok) return;

            const logs = await response.json();
            if (!Array.isArray(logs) || logs.length === 0) return;

            const lastSeen = localStorage.getItem(NMS_CONFIG.lastLogKey);

            if (!lastSeen) {
                localStorage.setItem(NMS_CONFIG.lastLogKey, logs[0].time);
                return;
            }

            let newLastSeen = lastSeen;
            let pendingEvents = [];

            for (let i = 0; i < logs.length; i++) {
                const log = logs[i];
                if (log.time <= lastSeen) break;

                if (i === 0) newLastSeen = log.time;

                if (log.status === 'online' || log.status === 'offline') {
                    // De-duplication check: Don't show if exactly the same message was shown recently (< 30s)
                    const msgKey = `${log.name}|${log.status}|${log.msg}`;
                    const now = Date.now();
                    if (seenMessages.has(msgKey) && (now - seenMessages.get(msgKey)) < 30000) {
                        continue;
                    }
                    seenMessages.set(msgKey, now);
                    pendingEvents.push(log);
                }
            }

            if (pendingEvents.length > 0) {
                if (pendingEvents.length <= NMS_CONFIG.batchThreshold) {
                    // Show individual (Reverse to follow time flow)
                    for (let j = pendingEvents.length - 1; j >= 0; j--) {
                        const ev = pendingEvents[j];
                        showToast(ev.name, ev.status, ev.msg);
                    }
                } else {
                    // Summarize
                    let up = 0, down = 0;
                    pendingEvents.forEach(e => {
                        if (e.status === 'online') up++;
                        else down++;
                    });
                    showMassToast(up, down);
                }
            }

            localStorage.setItem(NMS_CONFIG.lastLogKey, newLastSeen);

            // Cleanup old items from seenMessages cache every poll
            const now = Date.now();
            for (let [key, time] of seenMessages.entries()) {
                if (now - time > 60000) seenMessages.delete(key);
            }

        } catch (e) {
            console.warn("NMS Global Notification Error:", e);
        }
    }

    // Initialize
    document.addEventListener('DOMContentLoaded', () => {
        injectToastCSS();
        // Initial check relative to current time to avoid flood of old logs
        // We set the benchmark immediately so we only see logs happening AFTER page load
        fetch('/api/logs', { headers: { 'X-Auth-Token': localStorage.getItem('nms_auth_session') } })
            .then(r => r.json())
            .then(logs => {
                if (logs && logs[0]) localStorage.setItem(NMS_CONFIG.lastLogKey, logs[0].time);
            }).catch(() => { });

        setInterval(checkLogs, NMS_CONFIG.pollingInterval);
    });
})();

// --- USER MANAGEMENT & LOGIN INTERCEPTORS ---
(function () {
    // 1. Intercept fetch for /api/login to inject custom username
    const originalFetch = window.fetch;
    let tempCustomToken = null;
    let tempCustomRole = null;
    let tempCustomPerms = null;

    window.fetch = function (url, options) {
        if (typeof url === 'string' && url.includes('/api/login') && options && options.method === 'POST') {
            try {
                const body = JSON.parse(options.body || '{}');
                const userInput = document.getElementById('userInput');
                if (userInput && userInput.value.trim() !== '') {
                    body.username = userInput.value.trim();
                    options.body = JSON.stringify(body);
                }

                return originalFetch(url, options).then(response => {
                    if (response.ok) {
                        return response.clone().json().then(data => {
                            if (data.token) {
                                tempCustomToken = data.token;
                                tempCustomRole = data.role;
                                tempCustomPerms = data.permissions || null;

                                // Direct sync to localStorage to make sure it is updated immediately
                                localStorage.setItem('nms_auth_session', data.token);
                                localStorage.setItem('nms_role', data.role);
                                if (data.permissions) {
                                    localStorage.setItem('nms_permissions', JSON.stringify(data.permissions));
                                } else {
                                    localStorage.removeItem('nms_permissions');
                                }

                                // Trigger page reload to clear DOM styling memory and enforce permissions
                                setTimeout(() => {
                                    window.location.reload();
                                }, 150);
                            }
                            return response;
                        }).catch(() => response);
                    }
                    return response;
                });
            } catch (e) {
                console.error("[LOGIN INTERCEPT] Error intercepting fetch login payload:", e);
            }
        }
        return originalFetch(url, options);
    };

    // 2. Intercept localStorage.setItem safely with context binding
    try {
        const originalSetItem = localStorage.setItem.bind(localStorage);
        localStorage.setItem = function (key, value) {
            if (key === 'nms_auth_session' && tempCustomToken && value !== tempCustomToken) {
                value = tempCustomToken;
                tempCustomToken = null; // consume it
            }
            if (key === 'nms_role' && tempCustomRole && value !== tempCustomRole) {
                value = tempCustomRole;
                tempCustomRole = null; // consume
            }
            originalSetItem(key, value);
        };
    } catch (e) {
        console.error("[STORAGE OVERRIDE] Error overriding setItem:", e);
    }

    // 2b. Intercept localStorage.removeItem safely with context binding
    try {
        const originalRemoveItem = localStorage.removeItem.bind(localStorage);
        localStorage.removeItem = function (key) {
            if (key === 'nms_auth_session') {
                originalRemoveItem('nms_role');
                originalRemoveItem('nms_permissions');
            }
            originalRemoveItem(key);
        };
    } catch (e) {
        console.error("[STORAGE OVERRIDE] Error overriding removeItem:", e);
    }

    // 3. Inject Username input field above Password in all login screens dynamically
    function injectUsernameField() {
        const passInput = document.getElementById('passInput');
        if (passInput && !document.getElementById('userInput')) {
            const userInput = document.createElement('input');
            userInput.type = 'text';
            userInput.id = 'userInput';
            userInput.placeholder = 'Username';
            userInput.className = 'input';
            userInput.autocomplete = 'username';

            // Matching styles for premium Cyber-Gold design
            userInput.style.width = '100%';
            userInput.style.boxSizing = 'border-box';
            userInput.style.marginBottom = '12px';
            userInput.style.padding = '12px';
            userInput.style.background = 'rgba(15, 23, 42, 0.6)';
            userInput.style.border = '1px solid rgba(243, 186, 47, 0.2)';
            userInput.style.borderRadius = '8px';
            userInput.style.color = '#fff';
            userInput.style.fontSize = '14px';
            userInput.style.transition = 'all 0.2s';

            userInput.onfocus = function () {
                userInput.style.borderColor = '#f3ba2f';
                userInput.style.boxShadow = '0 0 0 2px rgba(243, 186, 47, 0.2)';
            };
            userInput.onblur = function () {
                userInput.style.borderColor = 'rgba(243, 186, 47, 0.2)';
                userInput.style.boxShadow = 'none';
            };

            // Listen to enter key to trigger login
            userInput.addEventListener('keyup', function (event) {
                if (event.key === 'Enter') {
                    if (typeof window.doLogin === 'function') {
                        window.doLogin();
                    }
                }
            });

            // Insert it above the passInput
            passInput.parentNode.insertBefore(userInput, passInput);

            // Inject beautiful, high-quality notice text at the bottom of login-box
            if (!document.getElementById('loginNoteMsg')) {
                const noteDiv = document.createElement('div');
                noteDiv.id = 'loginNoteMsg';

                // Content with localizability support
                var currentLang = localStorage.getItem('nms_lang') || 'id';
                var noteText = '';
                if (currentLang === 'en') {
                    noteText = '💡 <b>Default Credentials:</b> The initial default usernames are <b>admin</b> (for Owner) and <b>viewer</b> (for Monitor).';
                } else {
                    noteText = '💡 <b>Kredensial Default:</b> Username bawaan awal adalah <b>admin</b> (untuk Pemilik) dan <b>viewer</b> (untuk Monitor).';
                }
                noteDiv.innerHTML = noteText;

                // Premium look & feel styles
                noteDiv.style.marginTop = '18px';
                noteDiv.style.padding = '10px 14px';
                noteDiv.style.fontSize = '11px';
                noteDiv.style.lineHeight = '1.5';
                noteDiv.style.color = '#94a3b8'; // text-muted slate
                noteDiv.style.background = 'rgba(243, 186, 47, 0.05)';
                noteDiv.style.border = '1px dashed rgba(243, 186, 47, 0.2)';
                noteDiv.style.borderRadius = '8px';
                noteDiv.style.textAlign = 'left';

                // Append to the login box
                const loginBox = passInput.parentNode;
                if (loginBox) {
                    loginBox.appendChild(noteDiv);
                }
            }
        }
    }

    // Monitor DOM changes to inject Username input if login overlay is rendered later
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectUsernameField);
    } else {
        injectUsernameField();
    }

    // MutationObserver to capture cases where elements are rendered dynamically
    const observer = new MutationObserver((mutations) => {
        if (document.getElementById('passInput') && !document.getElementById('userInput')) {
            injectUsernameField();
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
})();

// Append User Management translation keys
if (typeof LANG_DICT !== 'undefined') {
    if (LANG_DICT['id']) {
        LANG_DICT['id']['tab_users'] = "USER MANAGEMENT";
        LANG_DICT['id']['btn_add_user'] = "+ TAMBAH USER";
        LANG_DICT['id']['lbl_category'] = "Kategori / Role";
        LANG_DICT['id']['lbl_menu_access'] = "Hak Akses Menu (Checklist)";
        LANG_DICT['id']['role_pemilik'] = "👑 Pemilik (Admin)";
        LANG_DICT['id']['role_teknisi'] = "🔧 Teknisi Lapangan";
        LANG_DICT['id']['role_keuangan'] = "💵 Staff Keuangan";
        LANG_DICT['id']['role_viewer'] = "👁️ Tamu / Monitor";
        LANG_DICT['id']['role_kustom'] = "⚙️ Kustom / Manual";
        LANG_DICT['id']['msg_confirm_del_user'] = "Apakah Anda yakin ingin menghapus user {name}?";
        LANG_DICT['id']['hs_price_info_generate'] = "Harga per voucher akan otomatis tercatat ke Keuangan saat pelanggan login.";
        LANG_DICT['id']['hs_pricing_desc'] = "Harga profil digunakan untuk menghitung pemasukan otomatis saat voucher digunakan. Profil dengan harga Rp 0 dianggap TRIAL dan tidak tercatat ke Keuangan.";
        LANG_DICT['id']['lbl_hotspot_profile'] = "Profil Hotspot";
        LANG_DICT['id']['cat_voucher_payment'] = "Penjualan Voucher Hotspot";
        LANG_DICT['id']['lbl_total_voucher'] = "Total Voucher";
        LANG_DICT['id']['lbl_voucher_active'] = "Sudah Aktivasi";
        LANG_DICT['id']['lbl_voucher_inactive'] = "Belum Aktivasi";
        LANG_DICT['id']['hs_guide_title'] = "PANDUAN SINKRONISASI KEUANGAN HOTSPOT:";
        LANG_DICT['id']['hs_guide_step1'] = "Pemasukan dicatat otomatis ke Keuangan saat voucher pertama kali digunakan (login / uptime > 0) oleh pelanggan.";
        LANG_DICT['id']['hs_guide_step2'] = "Pastikan Anda mengisi harga untuk profil hotspot tersebut di menu Billing & Tagihan -> Master Harga.";
        LANG_DICT['id']['hs_guide_step3'] = "Jika harga profil diatur Rp 0, voucher dianggap sebagai TRIAL/Promo dan tidak dicatat ke Keuangan.";
        LANG_DICT['id']['hs_pricing_guide_hotspot'] = "Profil Hotspot terdeteksi otomatis dari Mikrotik (ditandai ikon WiFi & badge oranye). Anda tidak perlu menambahkannya secara manual, cukup edit harganya.";
        LANG_DICT['id']['hs_pricing_guide_mikhmon'] = "Jika profil dibuat di Mikhmon dengan comment berisi 'price=2000', NMS akan mendeteksi dan mengimpor harganya otomatis ke NMS sebagai default awal.";
        LANG_DICT['id']['lbl_hotspot_voucher_desc'] = "KHUSUS HOTSPOT VOUCHER";
        LANG_DICT['id']['hint_bill_fixed'] = "Tanggal penagihan tetap setiap bulan untuk pelanggan ini.";
        LANG_DICT['id']['lbl_import_guide'] = "PETUNJUK IMPORT (10 KOLOM):";
        LANG_DICT['id']['hint_import_1'] = "<b>Tipe Koneksi:</b> Isi <code>PPPoE</code>, <code>PPPoE Radius</code>, atau <code>Statik</code>.";
        LANG_DICT['id']['hint_import_2'] = "<b>Username PPPoE:</b> Wajib diisi jika tipe PPPoE/Radius.";
        LANG_DICT['id']['hint_import_3'] = "<b>IP Address:</b> Wajib diisi jika tipe Statik.";
        LANG_DICT['id']['hint_import_4'] = "<b>Nama Paket:</b> Isi profil kecepatan (manual).";
        LANG_DICT['id']['hint_import_5'] = "<b>Koordinat:</b> Format <code>lat, lng</code> (Wajib untuk Maps).";
        LANG_DICT['id']['desc_role_mgt'] = "Kelola akun administrator, viewer, dan teknisi lapangan dengan hak akses khusus.";
        LANG_DICT['id']['hint_rawbt_text'] = "Mode RawBT Text Only menggunakan format standar (bukan HTML) untuk kompatibilitas maksimal. Template di atas tidak berlaku untuk mode ini.";
        LANG_DICT['id']['lbl_tpl_hs_login'] = "Template Pesan Hotspot Login";
        LANG_DICT['id']['lbl_tpl_hs_logout'] = "Template Pesan Hotspot Logout";
        LANG_DICT['id']['hint_coord_comma'] = "Contoh: -6.123, 106.123 (Pisahkan Koma)";
        LANG_DICT['id']['opt_yes_one'] = "yes (Satu akun satu login)";
        LANG_DICT['id']['opt_no_multi'] = "no (Boleh multi login)";
        LANG_DICT['id']['hint_comma_sep'] = "Pisahkan dengan koma jika lebih dari satu";
        LANG_DICT['id']['ph_search'] = "Cari nama, profil, atau komentar...";
        LANG_DICT['id']['pp_ph_search_active'] = "Cari User Aktif...";
        LANG_DICT['id']['pp_ph_search_profile'] = "Cari Profil...";
        LANG_DICT['id']['pp_btn_kick_all'] = "PUTUS SEMUA";
        LANG_DICT['id']['pp_title_main_profile_info'] = "Informasi Profil Utama";
        LANG_DICT['id']['pp_title_queue_config'] = "Konfigurasi Queue (Advanced)";
        LANG_DICT['id']['pp_title_account_info'] = "Informasi Akun";
        LANG_DICT['id']['pp_title_network_config'] = "Konfigurasi Jaringan";
        LANG_DICT['id']['pp_title_additional_info'] = "Informasi Tambahan";
        LANG_DICT['id']['pp_addprof_hint_local'] = "IP Lokal Gateway router";
        LANG_DICT['id']['pp_addprof_hint_remote'] = "Pool / Alamat IP Client";
        LANG_DICT['id']['pp_addprof_hint_rate'] = "Format: 1M/2M atau 512k/1M";
        LANG_DICT['id']['pp_addprof_hint_parent'] = "Induk queue untuk limitasi global";
        LANG_DICT['id']['pp_addprof_hint_insert'] = "Urutan penempatan di simple queue";
        LANG_DICT['id']['pp_stat_total'] = "TOTAL SECRET";
        LANG_DICT['id']['pp_stat_online'] = "ONLINE";
        LANG_DICT['id']['pp_stat_offline'] = "OFFLINE";
        LANG_DICT['id']['pp_stat_disabled'] = "NONAKTIF";
        LANG_DICT['id']['pp_stat_expired'] = "EXPIRED";
        LANG_DICT['id']['pp_stat_active_sessions'] = "SESI AKTIF";
        LANG_DICT['id']['pp_stat_pppoe_active'] = "PPPOE AKTIF";
        LANG_DICT['id']['pp_stat_profiles'] = "TOTAL PROFIL";
        LANG_DICT['id']['pp_toast_pass_gen'] = "Password berhasil dibuat!";
        LANG_DICT['id']['pp_toast_req_user'] = "Masukkan username dahulu";
        LANG_DICT['id']['pp_toast_batch_no_check'] = "Check tidak tersedia untuk batch creation";
        LANG_DICT['id']['pp_toast_user_exists'] = "Username '{name}' SUDAH ADA di MikroTik ini!";
        LANG_DICT['id']['pp_toast_user_avail'] = "Username '{name}' TERSEDIA";
        LANG_DICT['id']['pp_toast_export_empty'] = "Daftar kosong, tidak ada yang bisa di-export";
        LANG_DICT['id']['pp_toast_users_created'] = "{count} User berhasil dibuat";
        LANG_DICT['id']['pp_err_load_data'] = "Gagal memuat data PPPoE";
        LANG_DICT['id']['pp_toast_select_del'] = "Pilih minimal satu user untuk dihapus";
        LANG_DICT['id']['pp_confirm_kick'] = "Putus sesi aktif ini?";
        LANG_DICT['id']['pp_toast_no_active_match'] = "Tidak ada sesi aktif yang cocok";
        LANG_DICT['id']['pp_toast_kicking_count'] = "Memutus sesi aktif ({count})...";
        LANG_DICT['id']['pp_toast_kick_result'] = "Selesai: {success} berhasil diputus, {fail} gagal.";
        LANG_DICT['id']['pp_confirm_kick_all'] = "PERINGATAN: Apakah Anda yakin ingin memutus SEMUA sesi aktif PPPoE ({count} sesi)?";
        LANG_DICT['id']['pp_confirm_kick_all_search'] = "PERINGATAN: Apakah Anda yakin ingin memutus SEMUA sesi aktif yang cocok dengan pencarian '{search}' ({count} sesi)?";
        LANG_DICT['id']['lbl_username'] = "Nama Pengguna";
        LANG_DICT['id']['lbl_password'] = "Kata Sandi";
        LANG_DICT['id']['btn_download_db_now'] = "UNDUH DB SEKARANG";
        LANG_DICT['id']['lbl_lic_lifetime'] = "(PRO) Lifetime";
        LANG_DICT['id']['msg_refresh_off'] = "Auto-refresh dimatikan";
        LANG_DICT['id']['msg_refresh_set'] = "Refresh diatur ke {rate} detik";
        LANG_DICT['id']['lbl_tab_general'] = "Umum";
        LANG_DICT['id']['lbl_tab_connection'] = "Koneksi";
        LANG_DICT['id']['lbl_tab_others'] = "Lainnya";
        LANG_DICT['id']['opt_mon_linux'] = "1. Ping dari Server (Linux Ping)";
        LANG_DICT['id']['opt_mon_python'] = "2. Ping dari Python (Library)";
        LANG_DICT['id']['opt_mon_api'] = "3. Status dari Router API (ARP/DHCP)";
        LANG_DICT['id']['opt_mon_mikrotik'] = "4. Ping dari Mikrotik (API)";
        LANG_DICT['id']['opt_mon_netwatch'] = "5. Netwatch (Status Up/Down)";
        
        LANG_DICT['id']['ph_search_arrears'] = "Cari nama atau paket client...";
        LANG_DICT['id']['btn_add_bank_acc'] = "Tambah Rekening";
        LANG_DICT['id']['ph_bank_acc_no'] = "Masukkan nomor rekening";
        LANG_DICT['id']['ph_bank_acc_name'] = "Nama pemilik";
        LANG_DICT['id']['ph_tg_msg_up'] = "Gunakan {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {packet}";
        LANG_DICT['id']['ph_tg_msg_down'] = "Gunakan {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['id']['ph_tg_msg_isolir'] = "Gunakan {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['id']['ph_tg_msg_reactivate'] = "Gunakan {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['id']['ph_tg_msg_odp_down'] = "Gunakan {name}, {parent_name}, {offline_count}, {total_count}, {dependent_desc}, {date}, {time}, {rca_info}";
        LANG_DICT['id']['ph_tg_msg_odp_up'] = "Gunakan {name}, {online_count}, {total_count}, {duration_desc}, {date}, {time}";
        LANG_DICT['id']['ph_tg_msg_hs_login'] = "Gunakan {name}, {ip}, {mac}, {host_name}, {server}, {profile}, {uptime}, {bytes_out}, {router_name}, {date}, {time}";
        LANG_DICT['id']['ph_tg_msg_hs_logout'] = "Gunakan {name}, {ip}, {mac}, {host_name}, {server}, {profile}, {uptime}, {bytes_out}, {router_name}, {date}, {time}";
        LANG_DICT['id']['msg_dash_reconnect'] = "Koneksi terputus. Menyambung ulang...";
        LANG_DICT['id']['msg_no_active_period'] = "Belum ada masa aktif (Instalasi Baru?)";
        LANG_DICT['id']['title_edit_active_period'] = "Edit Masa Aktif Manual";
        LANG_DICT['id']['title_set_initial_active_period'] = "Set Masa Aktif Pertama";
        LANG_DICT['id']['msg_prompt_expiry_normal'] = "Masukkan Tanggal Masa Aktif Baru (Format: DD-MM-YYYY):";
        LANG_DICT['id']['msg_prompt_expiry_fixed'] = "Ganti Masa Aktif (Mode Fixed).\nMasukkan Tanggal Lengkap (Format: DD-MM-YYYY).\n\nNOTE: Tanggal (DD) yang Anda masukkan akan menjadi 'Jatuh Tempo' bulanan klien ini.";
        LANG_DICT['id']['msg_date_format_error'] = "Format tanggal salah! Gunakan DD-MM-YYYY (Contoh: 28-04-2026)";
        LANG_DICT['id']['msg_confirm_expiry_change'] = "Ubah masa aktif {name} menjadi {date}?";
        LANG_DICT['id']['act_import_clients'] = "import data klien";
        LANG_DICT['id']['act_isolate_client'] = "isolir klien";
        LANG_DICT['id']['act_toggle_bypass'] = "mengubah status Bypass";
        LANG_DICT['id']['act_enable_billing'] = "mengaktifkan billing";
        LANG_DICT['id']['act_disable_billing'] = "menonaktifkan billing";
        LANG_DICT['id']['act_toggle_bulk_billing'] = "mengubah status billing masal";
        LANG_DICT['id']['act_payment_transaction'] = "transaksi pembayaran";
        LANG_DICT['id']['act_sync_mikrotik_profiles'] = "sinkronisasi profil MikroTik";
        LANG_DICT['id']['act_send_wa_reminder'] = "mengirim tagihan WhatsApp";
        LANG_DICT['id']['msg_permission_denied'] = "Akses Ditolak: Anda tidak memiliki izin untuk {action}.";
    }
    if (LANG_DICT['en']) {
        LANG_DICT['en']['tab_users'] = "USER MANAGEMENT";
        LANG_DICT['en']['btn_add_user'] = "+ ADD USER";
        LANG_DICT['en']['lbl_category'] = "Category / Role";
        LANG_DICT['en']['lbl_menu_access'] = "Menu Permissions (Checklist)";
        LANG_DICT['en']['role_pemilik'] = "👑 Owner (Admin)";
        LANG_DICT['en']['role_teknisi'] = "🔧 Field Technician";
        LANG_DICT['en']['role_keuangan'] = "💵 Finance Staff";
        LANG_DICT['en']['role_viewer'] = "👁️ Guest / Monitor";
        LANG_DICT['en']['role_kustom'] = "⚙️ Custom / Manual";
        LANG_DICT['en']['msg_confirm_del_user'] = "Are you sure you want to delete user {name}?";
        LANG_DICT['en']['hs_price_info_generate'] = "Price per voucher will be automatically recorded to Finance when the customer logs in.";
        LANG_DICT['en']['hs_pricing_desc'] = "Profile price is used to calculate automatic income when the voucher is used. Profiles with a price of Rp 0 are considered TRIAL and not recorded in Finance.";
        LANG_DICT['en']['th_uptime'] = "Uptime";
        LANG_DICT['en']['lbl_hotspot_profile'] = "Hotspot Profile";
        LANG_DICT['en']['cat_voucher_payment'] = "Hotspot Voucher Sales";
        LANG_DICT['en']['lbl_total_voucher'] = "Total Vouchers";
        LANG_DICT['en']['lbl_voucher_active'] = "Activated";
        LANG_DICT['en']['lbl_voucher_inactive'] = "Not Activated";
        LANG_DICT['en']['hs_guide_title'] = "HOTSPOT FINANCE SYNCHRONIZATION GUIDE:";
        LANG_DICT['en']['hs_guide_step1'] = "Income is automatically recorded to Finance when the voucher is first used (login / uptime > 0) by the customer.";
        LANG_DICT['en']['hs_guide_step2'] = "Make sure you set the price for the hotspot profile in the Billing & Tagihan -> Master Harga menu.";
        LANG_DICT['en']['hs_guide_step3'] = "If the profile price is set to Rp 0, the voucher is considered a TRIAL/Promo and will not be recorded to Finance.";
        LANG_DICT['en']['hs_pricing_guide_hotspot'] = "Hotspot profiles are auto-detected from Mikrotik (marked with a WiFi icon & orange badge). You don't need to add them manually, just edit their prices.";
        LANG_DICT['en']['hs_pricing_guide_mikhmon'] = "If the profile is created in Mikhmon with a comment containing 'price=2000', NMS will detect and import the price automatically as the initial default.";
        LANG_DICT['en']['lbl_hotspot_voucher_desc'] = "HOTSPOT VOUCHER SPECIAL INSTRUCTIONS";
        LANG_DICT['en']['hint_bill_fixed'] = "Fixed billing date every month for this customer.";
        LANG_DICT['en']['lbl_import_guide'] = "IMPORT GUIDE (10 COLUMNS):";
        LANG_DICT['en']['hint_import_1'] = "<b>Connection Type:</b> Fill in <code>PPPoE</code>, <code>PPPoE Radius</code>, or <code>Static</code>.";
        LANG_DICT['en']['hint_import_2'] = "<b>PPPoE Username:</b> Required if type is PPPoE/Radius.";
        LANG_DICT['en']['hint_import_3'] = "<b>IP Address:</b> Required if type is Static.";
        LANG_DICT['en']['hint_import_4'] = "<b>Package Name:</b> Fill in speed profile (manual).";
        LANG_DICT['en']['hint_import_5'] = "<b>Coordinates:</b> Format <code>lat, lng</code> (Required for Maps).";
        LANG_DICT['en']['desc_role_mgt'] = "Manage administrator, viewer, and field technician accounts with specific access rights.";
        LANG_DICT['en']['hint_rawbt_text'] = "RawBT Text Only mode uses standard format (not HTML) for maximum compatibility. The template above does not apply to this mode.";
        LANG_DICT['en']['lbl_tpl_hs_login'] = "Hotspot Login Message Template";
        LANG_DICT['en']['lbl_tpl_hs_logout'] = "Hotspot Logout Message Template";
        LANG_DICT['en']['hint_coord_comma'] = "Example: -6.123, 106.123 (Comma separated)";
        LANG_DICT['en']['opt_yes_one'] = "yes (One account one login)";
        LANG_DICT['en']['opt_no_multi'] = "no (Multi login allowed)";
        LANG_DICT['en']['hint_comma_sep'] = "Separate with commas if more than one";
        LANG_DICT['en']['ph_search'] = "Search name, profile, or comment...";
        LANG_DICT['en']['pp_ph_search_active'] = "Search Active User...";
        LANG_DICT['en']['pp_ph_search_profile'] = "Search Profile...";
        LANG_DICT['en']['pp_btn_kick_all'] = "DISCONNECT ALL";
        LANG_DICT['en']['pp_title_main_profile_info'] = "Main Profile Information";
        LANG_DICT['en']['pp_title_queue_config'] = "Queue Configuration (Advanced)";
        LANG_DICT['en']['pp_title_account_info'] = "Account Information";
        LANG_DICT['en']['pp_title_network_config'] = "Network Configuration";
        LANG_DICT['en']['pp_title_additional_info'] = "Additional Information";
        LANG_DICT['en']['pp_addprof_hint_local'] = "Router local gateway IP";
        LANG_DICT['en']['pp_addprof_hint_remote'] = "Client IP Pool / Address";
        LANG_DICT['en']['pp_addprof_hint_rate'] = "Format: 1M/2M or 512k/1M";
        LANG_DICT['en']['pp_addprof_hint_parent'] = "Parent queue for global limitation";
        LANG_DICT['en']['pp_addprof_hint_insert'] = "Placement order in simple queue";
        LANG_DICT['en']['pp_stat_total'] = "TOTAL SECRETS";
        LANG_DICT['en']['pp_stat_online'] = "ONLINE";
        LANG_DICT['en']['pp_stat_offline'] = "OFFLINE";
        LANG_DICT['en']['pp_stat_disabled'] = "DISABLED";
        LANG_DICT['en']['pp_stat_expired'] = "EXPIRED";
        LANG_DICT['en']['pp_stat_active_sessions'] = "ACTIVE SESSIONS";
        LANG_DICT['en']['pp_stat_pppoe_active'] = "PPPOE ACTIVE";
        LANG_DICT['en']['pp_stat_profiles'] = "TOTAL PROFILES";
        LANG_DICT['en']['pp_toast_pass_gen'] = "Password generated!";
        LANG_DICT['en']['pp_toast_req_user'] = "Please enter username first";
        LANG_DICT['en']['pp_toast_batch_no_check'] = "Check is not available for batch creation";
        LANG_DICT['en']['pp_toast_user_exists'] = "Username '{name}' ALREADY EXISTS on this MikroTik!";
        LANG_DICT['en']['pp_toast_user_avail'] = "Username '{name}' IS AVAILABLE";
        LANG_DICT['en']['pp_toast_export_empty'] = "Empty list, nothing to export";
        LANG_DICT['en']['pp_toast_users_created'] = "{count} Users successfully created";
        LANG_DICT['en']['pp_err_load_data'] = "Failed to load PPPoE data";
        LANG_DICT['en']['pp_toast_select_del'] = "Select at least one user to delete";
        LANG_DICT['en']['pp_confirm_kick'] = "Disconnect this active session?";
        LANG_DICT['en']['pp_toast_no_active_match'] = "No matching active sessions found";
        LANG_DICT['en']['pp_toast_kicking_count'] = "Disconnecting active sessions ({count})...";
        LANG_DICT['en']['pp_toast_kick_result'] = "Finished: {success} successfully disconnected, {fail} failed.";
        LANG_DICT['en']['pp_confirm_kick_all'] = "WARNING: Are you sure you want to disconnect ALL active PPPoE sessions ({count} sessions)?";
        LANG_DICT['en']['pp_confirm_kick_all_search'] = "WARNING: Are you sure you want to disconnect ALL active sessions matching search '{search}' ({count} sessions)?";
        LANG_DICT['en']['lbl_username'] = "Username";
        LANG_DICT['en']['lbl_password'] = "Password";
        LANG_DICT['en']['btn_download_db_now'] = "DOWNLOAD DB NOW";
        LANG_DICT['en']['lbl_lic_lifetime'] = "(PRO) Lifetime";
        LANG_DICT['en']['msg_refresh_off'] = "Auto-refresh turned off";
        LANG_DICT['en']['msg_refresh_set'] = "Refresh set to {rate} seconds";
        LANG_DICT['en']['lbl_tab_general'] = "General";
        LANG_DICT['en']['lbl_tab_connection'] = "Connection";
        LANG_DICT['en']['lbl_tab_others'] = "Others";
        LANG_DICT['en']['opt_mon_linux'] = "1. Ping from Server (Linux Ping)";
        LANG_DICT['en']['opt_mon_python'] = "2. Ping from Python (Library)";
        LANG_DICT['en']['opt_mon_api'] = "3. Status from Router API (ARP/DHCP)";
        LANG_DICT['en']['opt_mon_mikrotik'] = "4. Ping from MikroTik (API)";
        LANG_DICT['en']['opt_mon_netwatch'] = "5. Netwatch (Status Up/Down)";
        
        LANG_DICT['en']['btn_prune_prof'] = "Clean Obsolete Profiles";
        LANG_DICT['en']['msg_prune_no_orphans'] = "No obsolete MikroTik profiles found.";
        LANG_DICT['en']['msg_prune_confirm'] = "The following MikroTik profiles no longer exist on the router:\n\n{list}\n\n🚨 WARNING: These profiles might be used for STATIC IP or RADIUS clients.\nAre you sure you want to delete these profiles from Pricing?";
        LANG_DICT['en']['msg_prune_success'] = " obsolete profiles have been deleted.";
        LANG_DICT['en']['ph_search_arrears'] = "Search client name or package...";
        LANG_DICT['en']['btn_add_bank_acc'] = "Add Account";
        LANG_DICT['en']['ph_bank_acc_no'] = "Enter account number";
        LANG_DICT['en']['ph_bank_acc_name'] = "Owner name";
        LANG_DICT['en']['ph_tg_msg_up'] = "Use {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {packet}";
        LANG_DICT['en']['ph_tg_msg_down'] = "Use {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['en']['ph_tg_msg_isolir'] = "Use {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['en']['ph_tg_msg_reactivate'] = "Use {name}, {ip}, {status}, {date}, {time}, {total_online}, {total_offline}, {total_isolir}, {packet}";
        LANG_DICT['en']['ph_tg_msg_odp_down'] = "Use {name}, {parent_name}, {offline_count}, {total_count}, {dependent_desc}, {date}, {time}, {rca_info}";
        LANG_DICT['en']['ph_tg_msg_odp_up'] = "Use {name}, {online_count}, {total_count}, {duration_desc}, {date}, {time}";
        LANG_DICT['en']['ph_tg_msg_hs_login'] = "Use {name}, {ip}, {mac}, {host_name}, {server}, {profile}, {uptime}, {bytes_out}, {router_name}, {date}, {time}";
        LANG_DICT['en']['ph_tg_msg_hs_logout'] = "Use {name}, {ip}, {mac}, {host_name}, {server}, {profile}, {uptime}, {bytes_out}, {router_name}, {date}, {time}";
        LANG_DICT['en']['msg_dash_reconnect'] = "Connection lost. Reconnecting...";
        LANG_DICT['en']['msg_no_active_period'] = "No active period yet (New Installation?)";
        LANG_DICT['en']['title_edit_active_period'] = "Edit Active Period Manually";
        LANG_DICT['en']['title_set_initial_active_period'] = "Set Initial Active Period";
        LANG_DICT['en']['msg_prompt_expiry_normal'] = "Enter New Active Period Date (Format: DD-MM-YYYY):";
        LANG_DICT['en']['msg_prompt_expiry_fixed'] = "Change Active Period (Fixed Mode).\nEnter Full Date (Format: DD-MM-YYYY).\n\nNOTE: The Day (DD) you enter will become the monthly 'Due Date' for this client.";
        LANG_DICT['en']['msg_date_format_error'] = "Invalid date format! Use DD-MM-YYYY (Example: 28-04-2026)";
        LANG_DICT['en']['msg_confirm_expiry_change'] = "Change active period of {name} to {date}?";
        LANG_DICT['en']['act_import_clients'] = "import client data";
        LANG_DICT['en']['act_isolate_client'] = "isolate client";
        LANG_DICT['en']['act_toggle_bypass'] = "toggle Bypass status";
        LANG_DICT['en']['act_enable_billing'] = "enable billing";
        LANG_DICT['en']['act_disable_billing'] = "disable billing";
        LANG_DICT['en']['act_toggle_bulk_billing'] = "toggle bulk billing status";
        LANG_DICT['en']['act_payment_transaction'] = "payment transaction";
        LANG_DICT['en']['act_sync_mikrotik_profiles'] = "synchronize MikroTik profiles";
        LANG_DICT['en']['act_send_wa_reminder'] = "sending WhatsApp reminder";
        LANG_DICT['en']['msg_permission_denied'] = "Permission Denied: You do not have permission to {action}.";
    }
}
